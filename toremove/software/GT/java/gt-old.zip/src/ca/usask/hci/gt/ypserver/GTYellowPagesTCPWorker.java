/*
 * Created on Nov 13, 2003
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package ca.usask.hci.gt.ypserver;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.net.Socket;
import java.util.Iterator;

import ca.usask.hci.gt.GTChannel;
import ca.usask.hci.gt.GTEvent;
import ca.usask.hci.utils.Messenger;

/**
 * @author Chris Fedak
 *
 */
public class GTYellowPagesTCPWorker implements Runnable {
	private Socket sock;
	private GTYellowPagesServer server;
	ObjectOutputStream out;
	ObjectInputStream in;
	boolean run = true;
	
	public GTYellowPagesTCPWorker(GTYellowPagesServer server, Socket s) {
		sock = s;
		try {
			out = new ObjectOutputStream(sock.getOutputStream());
			in = new ObjectInputStream(sock.getInputStream());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		this.server = server;	
	}

	/* (non-Javadoc)
	 * @see java.lang.Runnable#run()
	 */
	public void run() {
		GTEvent gte;
		// TODO Auto-generated method stub
		while (run) {
			gte= null;
			try {
				Object o = in.readObject();
				Messenger.getInstance().message("object received", this);
				gte = (GTEvent) o;
				// distribute the event
				processEvent(gte);
			} catch (IOException e) {
				Messenger.getInstance().error(e.getMessage(), this);
				Messenger.getInstance().error("GTServerWorker I/O error reading from client", this);
				connectionBroken();
				//System.exit(-1);
			} catch (ClassNotFoundException e) {
				Messenger.getInstance().error("could not find class", this);
			} catch (ClassCastException cce) {
				Messenger.getInstance().error("Class cast Exception", this);
			}
			
		}
	}
	
	private void connectionBroken() {
		try {
			server.removeWorker(this);
			sock.close();
		} catch(Exception e) {
			
		}
		run = false;
	}
	
	private void processEvent(GTEvent gte) {
		GTServerProperties gtp;
		GTChannel gtc;
		GTEvent list;
		Iterator i;
		
		Messenger.getInstance().message(gte.getMessageName() + " message received", this);
		
		if(gte.getMessageName().equals("KEEP_ALIVE")) {
			server.keepAlive((String)gte.getData()[0]);
		} else if (gte.getMessageName().equals("GET_SERVER_LIST")) {
			i = server.servers.values().iterator();
			while(i.hasNext()) {
				list = new GTEvent();
				list.setMessageName("SERVER_LIST");
				list.setData(new Serializable[] {(Serializable)i.next()});
				send(list);
			}
			list = new GTEvent();
			list.setMessageName("END_LIST");
			send(list);
		} else if(gte.getMessageName().equals("ADD_SERVER")) {
			gtp = (GTServerProperties)gte.getData()[0];
			server.addServer(gtp);
		} else if(gte.getMessageName().equals("ADD_CHANNEL")) {
			gtc = (GTChannel)gte.getData()[0];
			server.addChannelToServer(gtc,sock.getRemoteSocketAddress().toString());
		} else if(gte.getMessageName().equals("REMOVE_CHANNEL")) {
			gtc = (GTChannel)gte.getData()[0];
			server.addChannelToServer(gtc,sock.getRemoteSocketAddress().toString());
		} else if(gte.getMessageName().equals("REMOVE_CHANNEL")) {
			server.removeServer((String)gte.getData()[0]);
		}
	}
	
	public void send (GTEvent gte) {
		try {
			out.writeObject(gte);
			out.flush();
		} catch (IOException e) {
			Messenger.getInstance().error("serverworker couldn't write to socket", this);
			connectionBroken();
		}
		Messenger.getInstance().message("worker writing object: " + gte.toString(), this);
	}
}
