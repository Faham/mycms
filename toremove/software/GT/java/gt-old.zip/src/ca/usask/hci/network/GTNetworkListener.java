/*
 * Created on Dec 2, 2003
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package ca.usask.hci.network;

import java.util.EventListener;

/**
 * @author Chris Fedak
 *
 */
public interface GTNetworkListener extends EventListener {
	public void objectReceived(GTNetworkEvent e);
	public void networkConnected(GTNetworkEvent e);
	public void networkDisconnected(GTNetworkEvent e);
	public void objectSent(GTNetworkEvent e);
	
	
}
