/*
 * Created on Dec 16, 2003
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package ca.usask.hci.gt.telepointers;

import java.awt.Point;
import java.io.Serializable;

/**
 * @author Chris Fedak
 *
 */
public class OrderedPoint implements Comparable, Serializable{
	int x, y, order;
	boolean certain = false;
	long timestamp;
	/**
	 * 
	 */
	public OrderedPoint(int order) {
		super();
		x = 0;
		y = 0;
		this.order = order;
		certain = false;
		// TODO Auto-generated constructor stub
	}

	public OrderedPoint(int x, int y, int order) {
		this(order);
		this.x = x;
		this.y = y;
	}
	
	public OrderedPoint(Point p, int order) {
		this(order);
		x = p.x;
		y = p.y;
	}

	/**
	 * @return
	 */
	public int getOrder() {
		return order;
	}

	/**
	 * @param order
	 */
	public void setOrder(int order) {
		this.order = order;
	}

	/**
	 * @return
	 */
	public int getX() {
		return x;
	}

	/**
	 * @param x
	 */
	public void setX(int x) {
		this.x = x;
	}

	/**
	 * @return
	 */
	public int getY() {
		return y;
	}

	/**
	 * @param y
	 */
	public void setY(int y) {
		this.y = y;
	}

	/* (non-Javadoc)
	 * @see java.lang.Comparable#compareTo(java.lang.Object)
	 */
	public int compareTo(Object arg0) {
		// TODO Auto-generated method stub
		OrderedPoint other;
		try {
			other = (OrderedPoint)arg0;
			if(other.order == this.order) return 0;
			if(other.order > this.order) return 1;
			if(other.order < this.order) return -1;
		} catch(Exception e) {
			return 0;
		}
		return 0;
	}
	/**
	 * @return
	 */
	public boolean isCertain() {
		return certain;
	}

	/**
	 * @param certain
	 */
	public void setCertain(boolean certain) {
		this.certain = certain;
	}

	/**
	 * @return
	 */
	public long getTimestamp() {
		return timestamp;
	}

	/**
	 * @param timestamp
	 */
	public void setTimestamp(long timestamp) {
		this.timestamp = timestamp;
	}
	
	public String toString() {
		String val;
		val = String.valueOf(order)+ " " + String.valueOf(timestamp) + " " + String.valueOf(getX()) + " " + String.valueOf(getY()) + " ";
		return val;
	}
}
