/*
 * Created on Oct 27, 2003
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package ca.usask.hci.gt.gui;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

import ca.usask.hci.utils.MessageEvent;
import ca.usask.hci.utils.MessageListener;
import ca.usask.hci.utils.Messenger;

public class GTMessageMonitor {
	JFrame frame;
	JTextArea output;
	JScrollPane outputScrollPane;
	/**
	 * 
	 */
	public GTMessageMonitor() {
		super();
		buildUI();
	}

	public void buildUI() {
			JButton shutdown;
			
		
			
			output = new JTextArea(10, 50);
			outputScrollPane = new JScrollPane(output);
			outputScrollPane.setAutoscrolls(true);
			output.append("Message Monitor started\n");
			
			shutdown = new JButton("Shutdown Application");
			shutdown.addActionListener( new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					System.exit(0);
				}		
			});
			
			Messenger.getInstance().addMessageListener(new MyMessageListener());
			
			
			frame = new JFrame("Message Monitor"); 
			frame.addWindowListener(new WindowAdapter() {
				public void windowClosing(WindowEvent e) {System.exit(0);}
			});
			
			frame.getContentPane().setLayout(new GridBagLayout());
			GridBagConstraints gbc = new GridBagConstraints();
		
			// constraints for outputScrollPane
			gbc.gridx = 0;
			gbc.gridy = 0;
			gbc.weightx = 1;
			gbc.weighty = 1;
			gbc.fill = GridBagConstraints.BOTH;
			frame.getContentPane().add(outputScrollPane, gbc);
		
			// constraints for shutdown
			gbc.gridy = 1;
			gbc.weighty = 0.0;
			gbc.fill = GridBagConstraints.HORIZONTAL;
			frame.getContentPane().add(shutdown, gbc);
    
			frame.pack();
			frame.show();
		}
		
	class MyMessageListener implements MessageListener {
		
		/* (non-Javadoc)
		 * @see ca.usask.hci.utils.MessageListener#messageSent(ca.usask.hci.utils.MessageEvent)
		 */
		public void messageSent(MessageEvent me) {
			// TODO Auto-generated method stub
			output.append(me.getMessage()+"\n");
			//		scroll the text as it gets more and more
			output.scrollRectToVisible(new Rectangle(0,output.getHeight()-2,1,1));

				
		}

		/* (non-Javadoc)
		 * @see ca.usask.hci.utils.MessageListener#errorSent(ca.usask.hci.utils.MessageEvent)
		 */
		public void errorSent(MessageEvent me) {
			// TODO Auto-generated method stub
			output.append(me.getMessage()+"\n");
//		scroll the text as it gets more and more
			output.scrollRectToVisible(new Rectangle(0,output.getHeight()-2,1,1));
		}
			
	}
}
