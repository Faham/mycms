/*
 * Created on Dec 1, 2003
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package ca.usask.hci.network.qos;

import java.io.Serializable;

/**
 * @author Chris Fedak
 *
 */
public class GTQoSProperties implements Serializable {

	double latency;  // from 0 (latency unimportant) to 1.0 (latency very important)
	double reliability; //from 0 (reliability unimportant) to 1.0 (very important)

	/**
	 * 
	 */
	public GTQoSProperties() {
		super();
		latency = 0;
		reliability = 1;
		// TODO Auto-generated constructor stub
	}

	/**
	 * @return
	 */
	public double getLatency() {
		return latency;
	}

	/**
	 * @param latency
	 */
	public void setLatency(double latency) {
		this.latency = latency;
	}

	/**
	 * @return
	 */
	public double getReliability() {
		return reliability;
	}

	/**
	 * @param reliability
	 */
	public void setReliability(double reliability) {
		this.reliability = reliability;
	}

}
