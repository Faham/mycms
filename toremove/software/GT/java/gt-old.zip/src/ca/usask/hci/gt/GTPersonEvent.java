package ca.usask.hci.gt;

/**
	PersonJoineEvent:  Event sent when a person joins the current GT application.
	
	@author Carl Gutwin
	@author Chris Fedak
	
	@see GTEvent
*/
public class GTPersonEvent {
  Person p;
  String pID;

  public GTPersonEvent (Person who, String id) {
    p = who;
    pID = id;
  }
	/**
	 * Default constructor
	 */
	public GTPersonEvent() {
		
		// TODO Auto-generated constructor stub
	}
	/**
	 * @return person associated with the event
	 */
	public Person getPerson() {
		return p;
	}

	/**
	 * @param p 
	 */
	protected void setPerson(Person p) {
		this.p = p;
	}

	/**
	 * @return the ID of the client this Person is associated with
	 */
	public String getPID() {
		return pID;
	}

	/**
	 * @param pid
	 */
	protected void setPID(String pid) {
		pID = pid;
	}
	
	/**
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		return p.getName()+p.getColor()+pID;
	}

}
