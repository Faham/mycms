package ca.usask.hci.gt.server;

import java.io.*;
import java.net.*;
import java.util.*;

import ca.usask.hci.gt.GTChannel;
import ca.usask.hci.gt.GTEvent;
import ca.usask.hci.gt.Person;
import ca.usask.hci.gt.ypserver.GTServerProperties;
import ca.usask.hci.gt.ypserver.GTYellowPagesClient;
import ca.usask.hci.network.GTNetwork;
import ca.usask.hci.utils.Messenger;

/**
	GTServer:  Server for GT applications.  Relays dispatched events appropriately.  
	
	@author Carl Gutwin
	@author Chris Fedak
	
	@see GTServerWorker
	
*/
public class GTServer {
	
	/**
	 * Sends and receives all GT generic UDP traffic
	 */
	private DatagramSocket udpServerSocket;
	/**
	 * Establishes TCP connections with clients
	 */
	private ServerSocket serverSock;
	/**
	 * maps identifiers (STring) keys to GTChannels currently hosted
	 */
	private Map channels;
	/**
	 * maps unique client ID's (Strings) to GTServerClients
	 */
	private Map clients;
	/**
	 * represents this servers connection to the yellowPages Server
	 */
	private GTYellowPagesClient ypClient;
	/**
	 * the set of available short ID's (0-15)
	 */
	private TreeSet availableClientIds;
	/**
	 * clients connected but not yet logged in
	 */
	private List pendingClients;
	/**
	 * controls wheter this server is listening for more connections.
	 */
	private boolean listening;
	/**
	 * 
	 */
	private int nextID;

	/**
	 * Yellowpages Info for this server
	 */
	private GTServerProperties serverProperties;

	// TODO Load this from a preference file
	private String ypHost = "localhost";
	
	private boolean fullDebugMessages = false;

	public static void main(String s[]) {
		new GTServer().listen();
	}

	/**
	 * Default Constructor
	 */
	public GTServer() {
		clients = new HashMap();
		pendingClients = new LinkedList();
		listening = true;
		nextID = 0;
		channels = new HashMap();
		serverProperties = new GTServerProperties();
		serverProperties.setName("GT Alpha Server");
		serverProperties.setDescription(
			"Setting Description not yet supported");
		serverProperties.setClients(0);
		serverProperties.setMaxClients(99);
		Messenger.getInstance().message("about to launch setup\n");
		this.setup();
	}

	private void setup() {
		GTEvent event;
		try {
			Messenger.getInstance().message("binding serverSocket...\n");
			serverSock = new ServerSocket(4444);
		} catch (IOException e) {
			Messenger.getInstance().error("Could not listen on port: 4444");
			System.exit(-1);
		}

		try {
			udpServerSocket = new DatagramSocket(4499);
		} catch (SocketException e2) {
			e2.printStackTrace();
			System.exit(-1);
		}

		// server socket created, so notify the YellowPages Server of the existance of this server
		InetAddress ia;

		try {
			ia = InetAddress.getLocalHost();
			serverProperties.setHostAddress(ia.getHostAddress());
			serverProperties.setHostPort(serverSock.getLocalPort());

		} catch (UnknownHostException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		ypClient = new GTYellowPagesClient();
		try {
			//gives the client Server->YpServerBehaviour
			ypClient.registerServer(serverProperties);
		} catch (IOException e3) {
			Messenger.getInstance().error("Could not connect to Yellow Pages server - continuing...\n");			
		}
		//create initialClientID list;
		this.availableClientIds = new TreeSet();
		Short id;
		for (short i = 0; i < 16; i++) {
			id = new Short(i);
			this.availableClientIds.add(id);
		}
	}
	/**
	 * Starts the Server.  Any subclass must call this.
	 *
	 */
	public void listen() {
		GTServerWorker worker;
		Socket clientSocket = null;
		//start HighPerformaceTelepointerWorker (on port 4446)
		new Thread(new HighPerformanceTelepointerWorker()).start();
		Messenger.getInstance().message("HPT on UDP ready and listening...");			
		//start UDPWorker (on 4499)
		new Thread(new UDPWorker()).start();
		Messenger.getInstance().message("General UDP ready and listening...");			
		Messenger.getInstance().message("TCP listener ready and listening...");			
		while (listening) {
			try {
				clientSocket = serverSock.accept();
				clientSocket.setTcpNoDelay(true);
			} catch (IOException e) {
				Messenger.getInstance().error("Accept failed on port 4444");
				return;
			}
			// got a connection so spawn a new worker to handle it
			Messenger.getInstance().message("got a connection");
			worker = new GTServerWorker(this, clientSocket);
			pendingClients.add(worker);
			//clients.add(worker);
			new Thread(worker).start();
		}
	}
	
	
	/**
	 * relays reveived evnts to apprpriate clients
	 * @param gte	The event to relay, contains relay information
	 */
	protected void relayEvent(GTEvent gte) {
		Iterator step;
		GTServerWorker worker;
		double reliability;
		double latency;
		DatagramPacket packet;
		byte[] buf;

		if (fullDebugMessages)
			Messenger.getInstance().message(
				"Relaying event " + gte.getMessageName());

		step = clients.values().iterator();
		while (step.hasNext()) {
			worker = ((GTServerClient) step.next()).getWorker();
			if ((gte.sendTarget == GTEvent.TO_OTHERS
				&& !gte.getSenderID().equals(worker.clientID))
				|| (gte.sendTarget == GTEvent.TO_USER
					&& gte.getToUserID().equals(worker.clientID))
				|| (gte.sendTarget == GTEvent.TO_ALL)) {
					//System.out.println("relaying on " + gte.getChannel().getIdentifier());
				if (worker.subscribedToChannel(gte.getChannel())) {
					latency = gte.getChannel().getQosProps().getLatency();
					reliability =
						gte.getChannel().getQosProps().getReliability();
					if (latency > 0.5 && reliability < 0.5) {
						//relay via udp	
						buf = GTNetwork.getBytes(gte);
						packet =
							new DatagramPacket(
								buf,
								nextID,
								worker.getRemoteAddress(),
								((GTServerClient) clients.get(worker.clientID))
									.getUdpPort());
						try {
							if (fullDebugMessages)
								Messenger.getInstance().message(
									"sending "
										+ gte.getMessageName()
										+ " via UDP");
							this.udpServerSocket.send(packet);
						} catch (IOException e) {
							e.printStackTrace();
						}
					} else {
						if (fullDebugMessages)
							Messenger.getInstance().message(
								"sending " + gte.getMessageName() + " via TCP");
						worker.send(gte);
					}
				}
			}
		}

	}

	protected void relayViaUDP(GTEvent gte) {
		// TODO finish this method
		Iterator step;
		GTServerWorker worker;
		step = clients.values().iterator();
		while (step.hasNext()) {
			//worker = (GTServerWorker) step.next();
		}
	}

	/**
	 * Shuts down the server socket
	 */
	public void close() {
		// TODO finish this method
		try {
			serverSock.close();
		} catch (IOException e) {
			Messenger.getInstance().error("could not close server socket");
		}
		// foreach client close sockets
	}

	/**
	 * Events on "GT_CHANNELS" are handled here.
	 * @param 	gte event to be handled
	 * 			worker	GTServerWorker that the event came in on.
	 */
	protected void handleChannelEvent(GTEvent gte, GTServerWorker worker) {
		GTChannel newChannel;
		//GTServerClient client;

		if (gte.getMessageName().equals("ADD_CHANNEL")) {
			newChannel = (GTChannel) gte.getData()[0];
			channels.put(newChannel.getIdentifier(), newChannel);
			//step = clients.values().iterator();
			//client = (GTServerClient)clients.get(gte.getSenderID());
			//if(client!=null) {
			//client.getWorker().addChannel(newChannel);
			worker.addChannel(newChannel);
			channels.put(newChannel.getIdentifier(), newChannel);
			Messenger.getInstance().message(
				"Channel " + newChannel.getIdentifier() + " added");
			//} else {
			//	Messenger.getInstance().error("Channel " + newChannel.getIdentifier()+ " not added");
			// Messenger.getInstance().error("Reason: No such clientID " + gte.getSenderID());

			//}
		}
		if (gte.getMessageName().equals("SUBSCRIBE_TO_CHANNEL")) {
			String channelID = (String) gte.getData()[0];
			if (channels.containsKey(channelID)) {
				worker.addChannel((GTChannel)channels.get(channelID));
				Messenger.getInstance().message("subscribing to " + channelID);					
			} else {
				Messenger.getInstance().message(
								"Requested channel " + channelID + " does not exist");
			}

		}
		// TODO inform the yellowpages server
	}

	/**
	 * Events on "GT_SESSION" are handled here.
	 * 
	 * @param 	gte	
	 * 			worker
	 */
	protected void handleSessionEvent(GTEvent gte, GTServerWorker worker) {
		Iterator step;
		GTServerClient client, notifyClient;
		GTEvent response;
		Person p;
		String id;
		Object[] pData;
		Short responseID;
		Serializable[] data;

		if (gte.getMessageName().equals("GT_LOGIN")) {
			//pending clients are in a seperate list until they have been logged in.
			step = pendingClients.iterator();
			//get the data describing the person and their login details
			pData = gte.getData();

			//create client structure
			client = new GTServerClient();
			//set the clients representation of "person"
			client.setPerson((Person) pData[0]);
			// set the clients udpPort
			client.setUdpPort(((Integer) pData[2]).intValue());

			//set the clients ID
			client.setClientID(gte.getSenderID());
			//set the clients worker
			client.setWorker(worker);

			//determine responseID
			responseID = null;
			if(availableClientIds.size()<= 0) {
			//if (clients.size() > 15) {
				//this will cause the login to fail
				responseID = new Short((short) - 1);
			} else {
				responseID = (Short)availableClientIds.first();
				//responseID = new Short((short) clients.size());
				availableClientIds.remove(responseID);
			}
			//set person's short ID for reference.
			client.setShortID(responseID.shortValue());

			response = new GTEvent();
			response.setMessageName("GT_LOGIN_RESPONSE");
			data = new Serializable[] { responseID };
			response.setSenderID(gte.getSenderID());
			response.setChannel((GTChannel) channels.get("GT_SESSION"));
			response.setData(data);
			worker.send(response);

			if (responseID.intValue() == -1) {
				pendingClients.remove(worker);
				worker.stop();
			} else {
				
//			place this client on the active client list
				pendingClients.remove(worker);
				worker.setLoggedIn(true);
				System.out.println("New Active client:" + client.getClientID());
				clients.put(client.getClientID(), client);
				//send all currently logged in people to the
				//new client
//			System.out.println("about to inform new clients about current clients");
				step = clients.values().iterator();
				
				while (step.hasNext()) {
					notifyClient = (GTServerClient) step.next();
					p = notifyClient.getPerson();
					id = notifyClient.getClientID();
					if (id == client.getClientID())
						continue;

					//creates virtual event
					response = new GTEvent();
					response.setMessageName("GT_LOGIN");
					data = new Serializable[] { p, id };
					response.setData(data);
					response.setSenderID(id);
					response.setChannel((GTChannel) channels.get("GT_SESSION"));
					//sends it
					worker.send(response);
				}

				
			}
		} else if(gte.getMessageName().equals("GT_LOGOUT")) {
			handleLogout((GTServerClient)clients.get(gte.getSenderID()));
		} else if(gte.getMessageName().equals("GT_MODIFY_LOGIN")) {
			handleModifyLogin(
				(GTServerClient) clients.get(gte.getSenderID()),
				(Person) gte.getData()[0]);
		} else if (gte.getMessageName().equals("GT_HP_PORT")) {
			pData = gte.getData();
			client = (GTServerClient) clients.get(gte.getSenderID());
			client.setHPUdpPort(((Integer) pData[0]).intValue());
		}

		//relays the event if not a server specific event
		if (gte.getSendTarget() != GTEvent.TO_SERVER) {
			relayEvent(gte);
		}
	}

	/**
	 * @param client
	 * @param person
	 */
	private void handleModifyLogin(GTServerClient client, Person person) {
		//if(client == null || person == null) {
		client.setPerson(person);
		//} else {
		//	Messenger.getInstance().error("Error on modifyLogin.  Reason: No such client" + client.toString() + person.toString());
		//}
	}

	/**
	 * @param worker
	 * @param clientID
	 */
	protected void handleBrokenConnection(GTServerWorker worker) {
		GTServerClient client;
		Iterator step;
		GTEvent gte;

		//get reference to client		
		client = (GTServerClient) clients.get(worker.clientID);

		//remove client from client map 
		clients.remove(worker.clientID);

		//	stop associated worker
		worker.stop();

		//put short id back in available Pool
		if (client == null)
			return;
		availableClientIds.add(new Short(client.getShortID()));
		Messenger.getInstance().message("New size of pool " + String.valueOf(availableClientIds.size()));

		//create logout event
		gte =
			new GTEvent(
				"GT_LOGOUT",
				new Serializable[] { client.getPerson(), client.getClientID()});

		gte.setMessageName("GT_LOGOUT");
		gte.setSender(client.getClientID());
		gte.sendTarget = GTEvent.TO_ALL;
		gte.setChannel((GTChannel) channels.get("GT_SESSION"));

		//notify all clients of logout
		relayEvent(gte);
	}
	/**
	 * Handles client logouts
	 * @param client
	 */
	protected void handleLogout(GTServerClient client) {
		if (client != null) {
			clients.remove(client.getClientID());
			client.getWorker().stop();
			//put short id back in available Pool
			this.availableClientIds.add(new Short(client.getShortID()));
			Messenger.getInstance().message(
				"Logout: " + client.getPerson().getName());
		} else {
			Messenger.getInstance().error(
				"Error on handleLogout.  Reason: No such client");
		}
	}
	/**
	 * Handles generic UDP events sent to this server.  Works for simple tasks, but not quite fully
	 * integrated as of Thursday feb19
	 * @author chris
	 *
	 * To change the template for this generated type comment go to
	 * Window - Preferences - Java - Code Generation - Code and Comments
	 */
	private class UDPWorker implements Runnable {
			DatagramPacket incomingPacket, tempPacket;
			byte[] buf;
			int buffersize = 1024;
			Object incomingObject;
			GTEvent gte;
			GTServerClient client;
			GTServerClient sendToClient;
			
			public UDPWorker() {
				buf = new byte[buffersize];	
			}
	
			public void run() {
				Iterator i;
				while(true) {
					buf = new byte[buffersize];
					incomingPacket = new DatagramPacket(buf, buf.length);
					//just unpacks packets to
					try {
						udpServerSocket.receive(incomingPacket);
						incomingObject = GTNetwork.getObject(incomingPacket.getData());
						gte = (GTEvent)incomingObject;
						client = (GTServerClient)clients.get(gte.getSenderID());
						buf = GTNetwork.getBytes(gte);
						i = clients.values().iterator();
						
						while (i.hasNext()) {
							sendToClient= (GTServerClient)i.next();
							tempPacket = new DatagramPacket(buf, incomingPacket.getLength(), InetAddress.getByName(sendToClient.getUdpAddress()), sendToClient.getUdpPort());
							udpServerSocket.send(tempPacket);
						
						//if(gte.getChannel().getIdentifier().equals("GT_CHANNELS")) {
						//	handleChannelEvent(gte, ((GTServerClient)clients.get(gte.getSenderID())).getWorker());	
						//} else if(gte.getChannel().getIdentifier().equals("GT_SESSION")) {
						//	handleSessionEvent(gte,((GTServerClient)clients.get(gte.getSenderID())).getWorker());
						//} else {
						//	relayEvent(gte);
						//}
						}
					} catch (IOException e) {
						e.printStackTrace();
					}	catch (ClassCastException cce) {
						cce.printStackTrace();	
					} catch (NullPointerException npe) {
						npe.printStackTrace();
					}
				}
			}
		}
	/**
	 * Handles HPT traffic
	 *
	 */
	private class HighPerformanceTelepointerWorker implements Runnable {
		DatagramSocket serverSocket;
		byte[] buf;
		DatagramPacket packet;
		Iterator i;
		GTServerClient client;

		/* (non-Javadoc)
		 * @see java.lang.Runnable#run()
		 */
		public HighPerformanceTelepointerWorker() {
			try {
				serverSocket = new DatagramSocket(4446);
			} catch (SocketException e) {
				Messenger.getInstance().error(
					"HPServerSocket not initialized.  Reason:"
						+ e.getMessage());
			}
		}

		public void run() {
			InetAddress outgoing;
			int outPort;
			buf = new byte[1024];
			while (true) {
				try {
					packet = new DatagramPacket(buf, buf.length);
					serverSocket.receive(packet);

					// TODO  Add lock code here					
					i = clients.values().iterator();

					while (i.hasNext()) {
						// TODO don't send back to originator (requires unpacking)
						client = (GTServerClient) i.next();
						outgoing =
							InetAddress.getByName(client.getUdpAddress());
						outPort = client.getHPUdpPort();
						//don't send back to originator
						if (outgoing.equals(packet.getAddress())
							&& outPort == packet.getPort())
							continue;
						packet.setAddress(
							InetAddress.getByName(client.getUdpAddress()));
						packet.setPort(client.getHPUdpPort());
						serverSocket.send(packet);
					}
				} catch (Exception e) {
					Messenger.getInstance().error(
						"Packet not received.  Reason:" + e.getMessage());
				}
			}
		}
	}
}
