/*
 * Created on Jan 21, 2004
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package ca.usask.hci.gt.telepointers;

import java.awt.Point;
import java.util.List;

/**
 * Predicts based on last known point
 * 
 * @author Chris Fedak
 *
 */
public class GTDefaultPredictor implements GTTelepointerPredictor {

	/**
	 * 
	 */
	public GTDefaultPredictor() {
		super();
		// TODO Auto-generated constructor stub
	}

	/* (non-Javadoc)
	 * @see ca.usask.hci.gt.telepointers.GTTelepointerPredictor#predict(ca.usask.hci.gt.telepointers.ClientTelepointerHistory, long)
	 */
	public PredictedPoint predict(ClientTelepointerHistory cth, long time) {
		OrderedPoint op2 = null;
		PredictedPoint val = null;
		long dtime;
		List history = cth.history();
		if(history.size() <1) return new PredictedPoint(0,0,0);
		
		op2 = (OrderedPoint)history.get(0);		
		dtime = time - op2.getTimestamp();
		
		val = new PredictedPoint(cth.getMostRecent(),dtime);
		//Messenger.getInstance().message("Predict: " + String.valueOf(val.getX()) + "," + String.valueOf(val.getY()) + ":"+ cth.id);
		return val;
	}

	/* (non-Javadoc)
	 * @see ca.usask.hci.gt.telepointers.GTTelepointerPredictor#latencyAdjustment()
	 */
	public int latencyAdjustment() {
		// TODO Auto-generated method stub
		return 0;
	}

	/* (non-Javadoc)
	 * @see ca.usask.hci.gt.telepointers.GTTelepointerPredictor#correct(java.awt.Point)
	 */
	public void correct(Point p) {
		// TODO Auto-generated method stub
		
	}

}
