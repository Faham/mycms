/*
 * Created on Oct 14, 2003
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package ca.usask.hci.gt.gui;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JRadioButton;
import javax.swing.JSpinner;
import javax.swing.JTextField;
import javax.swing.SpinnerNumberModel;

import javax.swing.JComboBox;

//import ca.usask.hci.gt.GTController;
import ca.usask.hci.gt.preferences.GTPreferenceManager;

import java.io.*;
import java.util.Vector;
import java.awt.Insets;

import javax.swing.ImageIcon;

/**
 * @author Chris Fedak
 * @author Carl Gutwin
 *
 * To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
public class GTConnectionDialog extends JDialog {
	public static final int QUIT = 0;
	public static final int LOCAL = 1;
	public static final int REMOTE = 2;
	public int action;
	public String outHost;
	public int outPort;
	
	private ButtonGroup choices;
	//private JRadioButton quit;
	private JRadioButton connectTo;
	private JRadioButton connectViaYPServer;
	private JRadioButton tryLocal;
	private JTextField host;
	private JSpinner port;
	private JButton ok,quit;

	private JComboBox serverCombo;
	private Vector servers;
	private File prefsFile;
	
	private GTPreferenceManager prefManager;

	/**
	 * @throws java.awt.HeadlessException
	 */
	public GTConnectionDialog() throws HeadlessException {
		super();
		//servers = new Vector();
		prefManager = GTPreferenceManager.getInstance();
		servers = new Vector(prefManager.getServers());
		//	loadPrefs();
		if (servers.size()==0) {
			servers.add(new String("127.0.0.1"));
		}
		buildUI();
	}
	
/*	public void loadPrefs() {
		String homeDir;
		FileReader fr = null;
		BufferedReader br;
		String line, allLines;

		allLines = new String();
		homeDir = System.getProperty("user.home");
		prefsFile = new File(homeDir + "\\.gtpreferences");
		System.out.println("looking for prefs file at: " + prefsFile.getPath());
		try {
			fr = new FileReader(prefsFile);
		} catch (FileNotFoundException fnfe) {
			System.err.println("Preferences file not found - continuing...");
		}
		if (fr != null) {
			br = new BufferedReader(fr);
			try {
				line = br.readLine();
			} catch (IOException ioe) {
				System.err.println(
				"I/O error reading preferences file - continuing...");
				try {
					fr.close();
				} catch (IOException ioee) {
					System.err.println(
					"I/O error closing preferences file - continuing...");
				}
				return;
			}
			while (line != null) {
				allLines += line;
				try {
					line = br.readLine();
				} catch (IOException ioe) {
					System.err.println(
					"I/O error reading preferences file - continuing...");
					try {
						fr.close();
					} catch (IOException ioee) {
						System.err.println(
						"I/O error closing preferences file - continuing...");
					}
					return;
				}
			}
			// parse allLines
			try {
				fr.close();
			} catch (IOException ioee) {
				System.err.println(
				"I/O error closing preferences file - continuing...");
			}
			parsePrefs(allLines);
		}
	} 
	
	public void parsePrefs(String lines) {
		String item;
		StringTokenizer st;
		
		System.out.println(lines);
		st = new StringTokenizer(lines,"<>");
		while (st.hasMoreTokens()) {
			item = st.nextToken();
			//System.out.println(item);
			parsePrefItem(item);
		}
	} 
	
	public void parsePrefItem(String item) {
		ArrayList pieces;
		String key,value;
		StringTokenizer st;

		pieces = new ArrayList();
		st = new StringTokenizer(item, " =");
		while (st.hasMoreTokens()) {
			pieces.add(st.nextToken());
		}
		if (pieces.size() <= 1) {
			System.out.println("\titem does not have at least two pieces: [" + item + "]");
			return;
		}
		key = (String) pieces.get(0);
		if (key.equals("supernode")) {
			System.out.println("supernode: " + (String)pieces.get(1));
		}
		if (key.equals("server")) {
			value = (String)pieces.get(1);
			//System.out.println("server: " + (String)pieces.get(1));
			servers.add(value);
		}
	}*/

	private void checkNewHost(String newHost) {
/*		PrintWriter out = null;

		if (!servers.contains(newHost)) {
			// add it to the prefs file
			try {
				out = new PrintWriter(new BufferedWriter(new FileWriter(prefsFile,true)));
			} catch (IOException ioe) {
				System.out.println("IOException: could not open prefs file for writing: "
						+ prefsFile.getPath());
			}
			if (out != null) {
				out.println("<server " + newHost + ">");
				out.flush();
			}
			out.close();
		}
		*/
		prefManager.addServer(newHost);
		
	}
	
	public void buildUI() {
		JLabel l1, l2;
		JLabel splash;
		ImageIcon splashPicture;
		
		this.setModal(true);
		this.setName("Connect to a GTServer:");
		
		tryLocal = new JRadioButton("Connect to local server");
		tryLocal.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				action = LOCAL;
				tryLocal.setSelected(true);
				host.setEnabled(false);
				serverCombo.setEnabled(false);
				port.setEnabled(false);
			}
		});
		connectViaYPServer = new JRadioButton("Connect using Directory");
		
		connectTo = new JRadioButton("Connect to remote server:");
		connectTo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				action = REMOTE;
				connectTo.setSelected(true);
				host.setEnabled(true);
				serverCombo.setEnabled(true);
				port.setEnabled(true);
			}
		});
		
		l1 = new JLabel("Host:");
		host = new JTextField("127.0.0.1");
		serverCombo = new JComboBox(servers);
		serverCombo.setSelectedIndex(servers.size()-1);
		serverCombo.setEditable(true);
		port = new JSpinner(new SpinnerNumberModel(4444,0,99999,1));
		l2 = new JLabel("Port:");
//		quit = new JRadioButton("Quit");
//		quit.addActionListener(new ActionListener() {
//			public void actionPerformed(ActionEvent arg0) {
//				action = QUIT;
//				quit.setSelected(true);
//				host.setEnabled(false);
//				serverCombo.setEnabled(false);
//				port.setEnabled(false);
//			}
//		});
		
		ok = new JButton("OK");
		ok.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				//outHost = host.getText();
				outHost = (String)(serverCombo.getSelectedItem());
				checkNewHost(outHost);
				outPort = ((SpinnerNumberModel)port.getModel()).getNumber().intValue();
				dispose();
			}
		});
		
		quit = new JButton("Quit");
		quit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				action = QUIT;
				dispose();
			}
		});
		
		choices = new ButtonGroup();
		choices.add(tryLocal);
		choices.add(connectTo);
//		choices.add(quit);
		
		action = LOCAL;
		tryLocal.setSelected(true);
		serverCombo.setEnabled(false);
		host.setEnabled(false);
		port.setEnabled(false);	
		
		// splash panel
		splashPicture = new ImageIcon("c:/gttrans.png");
		splash = new JLabel(splashPicture);
		
		getContentPane().setLayout(new GridBagLayout());
		GridBagConstraints gbc = new GridBagConstraints();
		gbc.ipadx = 5;
		gbc.ipady = 3;
		gbc.insets = new Insets(0,0,0,0);
		
		// constraints for splash
//		gbc.gridx = 0;
//		gbc.gridy = 0;
		gbc.gridwidth = GridBagConstraints.REMAINDER;
		gbc.anchor = GridBagConstraints.CENTER;
		getContentPane().add(splash, gbc);
		
		// constraints for tryLocal
		gbc.insets = new Insets(0,25,0,25);
//		gbc.gridx = 0;
//		gbc.gridy = 0;
//		gbc.gridwidth = 2;
		gbc.weightx = 1;
		gbc.weighty = 0;
		gbc.anchor = GridBagConstraints.WEST;
		gbc.fill = GridBagConstraints.HORIZONTAL;
		getContentPane().add(tryLocal, gbc);

		// constraints for connectTo
//		gbc.gridy = 1;
		getContentPane().add(connectTo, gbc);

		// constraints for l1
		gbc.insets = new Insets(0,50,10,0);
//		gbc.gridy = 2;
		gbc.gridwidth = 1;
		gbc.anchor = GridBagConstraints.EAST;
		gbc.fill = GridBagConstraints.NONE;
		getContentPane().add(l1, gbc);

		// constraints for host
		gbc.insets = new Insets(0,0,10,25);
//		gbc.gridx = 1;
		gbc.gridwidth = GridBagConstraints.REMAINDER;
		gbc.anchor = GridBagConstraints.WEST;
		gbc.fill = GridBagConstraints.HORIZONTAL;
		//getContentPane().add(host, gbc);
		getContentPane().add(serverCombo, gbc);

		// constraints for l2
		gbc.insets = new Insets(0,50,0,0);
//		gbc.gridx = 0;
//		gbc.gridy = 3;
		gbc.gridwidth = 1;
		gbc.anchor = GridBagConstraints.EAST;
		gbc.fill = GridBagConstraints.NONE;
		getContentPane().add(l2, gbc);

		// constraints for port
		gbc.insets = new Insets(0,0,0,25);
//		gbc.gridx = 1;
		gbc.gridwidth = GridBagConstraints.REMAINDER;
		gbc.anchor = GridBagConstraints.WEST;
		gbc.fill = GridBagConstraints.HORIZONTAL;
		getContentPane().add(port, gbc);

		// constraints for quit
//		gbc.gridx = 0;
//		gbc.gridy = 4;
//		gbc.gridwidth = 2;
//		getContentPane().add(quit, gbc);	
		gbc.insets = new Insets(25,25,10,25);
		gbc.gridwidth = 1;
//		gbc.gridx = 0;
//		gbc.gridy = 4;
		gbc.gridwidth = 2;
		gbc.anchor = GridBagConstraints.WEST;
		gbc.fill = GridBagConstraints.NONE;
		getContentPane().add(quit, gbc);
		
		// constraints for ok
//		gbc.gridx = 1;
//		gbc.gridy = 4;
		gbc.gridwidth = 2;
		gbc.anchor = GridBagConstraints.EAST;
		gbc.fill = GridBagConstraints.NONE;
		getContentPane().add(ok, gbc);
		
		pack();
	}

}
