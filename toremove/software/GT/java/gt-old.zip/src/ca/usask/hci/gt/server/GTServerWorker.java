package ca.usask.hci.gt.server;

import java.io.*;
import java.net.*;
import java.util.HashMap;

import ca.usask.hci.gt.GTChannel;
import ca.usask.hci.gt.GTEvent;
import ca.usask.hci.utils.Messenger;

/**
	GTServerWorker:  Server for GT applications.  Relays dispatched events appropriately.
	
	@author Carl Gutwin
	@author Chris Fedak
	
	@see GTServer
*/
public class GTServerWorker implements Runnable {
  private Socket sock;
  private GTServer server;
  ObjectOutputStream out;
  ObjectInputStream in;
  String clientID;
  private HashMap channels;
	boolean run;
	private boolean loggedIn;

  public GTServerWorker(GTServer gts, Socket s) {
  	server = gts;
    sock = s;
    Messenger.getInstance().message("worker socket connected to: " + sock.getInetAddress().toString());
    Messenger.getInstance().message("worker socket connected on: " + sock.getPort());
    try {
      out = new ObjectOutputStream(sock.getOutputStream());
      in = new ObjectInputStream(sock.getInputStream());
    } catch (IOException e) {
      Messenger.getInstance().error("Couldn't get I/O streams for the connection to the client");
      System.exit(1);
    }
    channels = new HashMap();
		run = true;
		loggedIn = false;
  }
  
  public InetAddress getRemoteAddress() {
  	InetAddress val = null;
  	val = sock.getInetAddress();
  	return val;
  }

  public void run () {
    GTEvent gte;
    
    getFirstEvent();
    while (run) {
    	gte= null;
      try {
      	Object o = in.readObject();
				gte = (GTEvent) o;
      } catch (IOException e) {
	      Messenger.getInstance().error(e.getMessage());
				Messenger.getInstance().error("GTServerWorker I/O error reading from client");
				connectionBroken();
				//System.exit(-1);
      } catch (ClassNotFoundException e) {
				Messenger.getInstance().error("could not find class");
      } catch (ClassCastException cce) {
      	Messenger.getInstance().error("Class cast Exception");
      }
      // distribute the event
      processEvent(gte);
    }
  }
  
  private void processEvent(GTEvent gte) {
		if (gte != null) {
			// grab the id before distributing
			clientID = gte.getSenderID();
			//System.out.println("Message received on "+ gte.getChannel().getIdentifier());
			if(gte.getChannel().getIdentifier().equals("GT_CHANNELS")) {
				server.handleChannelEvent(gte, this);	
			} else if(gte.getChannel().getIdentifier().equals("GT_SESSION")) {
				server.handleSessionEvent(gte, this);
			} else {
				if(loggedIn) //only allow other events if Login done.
					server.relayEvent(gte);
			}
		}
  }

  private void getFirstEvent () {
    GTEvent gte = null;
    try {

    	// JD: Error getting thrown here - not sure why - connection reset every 
    	// time a in.readObject() is attempted.
    	gte = (GTEvent) in.readObject();
    } catch (IOException e) {
    	
      Messenger.getInstance().error("GTServerWorker I/O error reading from client");
     	connectionBroken();
  		
    } catch (ClassNotFoundException e) {
      Messenger.getInstance().error("could not find class");
    }
    processEvent(gte);
  }
  
  private void connectionBroken() {
  	run = false;
  	Messenger.getInstance().error("Closing connection with "+ clientID);
  	server.handleBrokenConnection(this);
  }

  public synchronized void send (GTEvent gte) {
    try {  	
      out.writeObject(gte);
      out.flush();
      //Messenger.getInstance().message("SENT:" + gte.getMessageName());
    } catch (IOException e) {
      Messenger.getInstance().error("serverworker couldn't write to socket");
      connectionBroken();
    }
    //System.out.println("server worker writing object: " + obj.toString());
  }
  
  public void sendViaUDP(Object o) {
  	
  }

	/**
	 * @param channel
	 */
	public void addChannel(GTChannel channel) {
		channels.put(channel.getIdentifier(), channel);
	}

	/**
	 * @param channel
	 * @return
	 */
	public boolean subscribedToChannel(GTChannel channel) {
		if(channels.get(channel.getIdentifier())!=null 
			||channel.getIdentifier().equals("GTCHANNELS") ) {
			return true;
		} 
		return false;
	}

	/**
	 * 
	 */
	public void stop() {
		// TODO Auto-generated method stub
		run = false;
		try {
			sock.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			Messenger.getInstance().error("GtServerWorker error on stop Reason:" + e.getMessage());
		}
	}
	/**
	 * @return
	 */
	public boolean isLoggedIn() {
		return loggedIn;
	}

	/**
	 * @param loggedIn
	 */
	public void setLoggedIn(boolean loggedIn) {
		this.loggedIn = loggedIn;
	}

}
