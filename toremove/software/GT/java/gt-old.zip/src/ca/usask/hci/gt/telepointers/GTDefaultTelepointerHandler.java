/*
 * Created on Jan 17, 2004
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package ca.usask.hci.gt.telepointers;

/**
 * A class to create, track, and draw screen representations for
 * telepointers; can be used when the application programmer doesn't
 * want to bother doing their own telepointers
 * 
 * @author gutwin
 */

import java.awt.*;
import java.awt.event.*;
import java.util.Iterator;
import java.util.Map;
import java.util.HashMap;

import ca.usask.hci.gt.*;
import ca.usask.hci.utils.CircularQueue;

public class GTDefaultTelepointerHandler implements GTTelepointerListener {
	GTTelepointerController gtc;
	Map pointers, trails, confidences, colours;
	double scale;
	int[] xs = { 0, 14, 8, 12, 11, 9, 4, 0 };
	int[] ys = { 0, 14, 14, 23, 24, 24, 15, 19 };
	Component comp;
	int count = 0;
	int sendcount = 0;
	boolean trailOn, confidenceOn;
	int trailLength;
	double confidence;
	Color[] greys;
	
//	int rx,ry,sx,sy;
	/**
	 * 
	 */
	public GTDefaultTelepointerHandler() {
		int i;
		// basic GT telepointer setup
		gtc = GTController.getInstance().getTelepointerController();
		gtc.addTelepointerListener(this);
		gtc.setBroadcastDelay(50);
		gtc.startSendingTelepointers();
		
		// pointer representations
		pointers = new HashMap();
		trails = new HashMap();
		confidences = new HashMap();
		colours = new HashMap();
		scale = 1.0;
		trailOn = false;
		trailLength = 10;
		confidenceOn = false;
		confidence = 1.0;
		greys = new Color[256];
		for (i=0;i<256;i++) {
			greys[i] = new Color(0,0,0,i);
		}
	}
	
	public void showTrail (boolean setting) {
		trailOn = setting;
	}

	public void showConfidence (boolean setting) {
		confidenceOn = setting;
	}

//	public void setConfidence (double value) {
//		confidence = value;
//	}
//
	public void setComponent(Component c) {
		comp = c;
		// set up mouse motion listeners for this component
		comp.addMouseMotionListener(new MyMouseMotionAdapter());
	}

	public void setTelepointerScale(double s) {
		scale = s;
		// here should loop through all pointers, resetting their polygon
	}

	public void setBroadcastDelay(int period) {
		gtc.setBroadcastDelay(period);
	}
	
//	public void setReceivedLocation(GTTelepointerEvent gte) {
//		rx = gte.x;
//		ry = gte.y;
//		comp.repaint();
//	}
//
//	public void setSendLocation(int x, int y) {
//		sx = x;
//		sy = y;
//		comp.repaint();
//	}
//
	public void setSendLoop() {
		sendcount++;
		if (sendcount>500) sendcount = 0;
		comp.repaint();
	}

	public void drawTelepointers(Graphics g) {
		Polygon tele;
		Person p;
		int i;
		int transLevel, transStep;
		Point p1, p2;
		CircularQueue trail;
		int conf, cval;
		Color[] values;
		//ClientTelepointerHistory cth;

		// step through map and draw telepointers
		Iterator step = pointers.keySet().iterator();
		while (step.hasNext()) {
			p = (Person) step.next();
			values = (Color[]) colours.get(p);
			
			// telepointer trail
			if (trailOn) {
				trail = (CircularQueue) trails.get(p);
				transLevel = 50;
				transStep = 200/trailLength;
				p1 = trail.get(0);
				for (i = 1; i < trailLength; i++) {
					p2 = trail.get(i);
					g.setColor(values[transLevel]);
					g.drawLine(p1.x, p1.y, p2.x, p2.y);
					p1 = p2;
					transLevel+=transStep;
				}
			}
			// now pointer itself
			if (confidenceOn) {
				conf = ((ConfidenceValue) confidences.get(p)).getConfidence();
				//System.out.println("conf is: " + conf);
				cval = Math.min(255,(int)((double)conf/100 * 255));
				g.setColor(values[255-cval]);
			} else {
				g.setColor(p.getColor());
			}
			tele = (Polygon) pointers.get(p);
			g.fillPolygon(tele);
			g.setColor(Color.black);
			g.drawPolygon(tele);
			//g.drawString("dtime: "+conf,10,10);
		}

		//		g.setColor(Color.blue);
		//		g.fillRect(count,0,15,15);
		//		g.setColor(Color.red);
		//		g.fillRect(sendcount,15,15,15);
		//		g.setColor(Color.green);
		//		g.fillOval(rx,ry,25,25);
		//		g.setColor(Color.pink);
		//		g.fillOval(sx,sy,25,25);
		//		g.setColor(Color.black);
		//		g.drawString("telepointers: " + gtc.telepointers.size(), 10,30);
		//		g.drawString("listeners: " + gtc.telepointerListeners.size(),
		// 10,50);
	}

	public void addTelepointer(Person p) {
		if (p == null) {
			// TODO: proper GT exception handling
			System.err.println("Person p in addTelepointer is null");
			return;
		}
		/* 
		 * NOTE: we handle telepointers lazily, by adding representations
		 * anytime we see a new person in a telepointer event. This might
		 * be better handled by listening to session events. In particular, 
		 * we don't ever remove a telepointer this way...
		 */
		if (!p.equals(GTController.getInstance().getMe())) {
			// pointer representation
			int[] xs2 = { 0, 14, 8, 12, 11, 9, 4, 0 };
			int[] ys2 = { 0, 14, 14, 23, 24, 24, 15, 19 };
			pointers.put(p, (Object) new Polygon(xs2, ys2, 8));
			
			// trail list
			trails.put(p,new CircularQueue(trailLength));
			
			// confidences
			confidences.put(p, new ConfidenceValue(255));
			
			// colours
			Color c = p.getColor();
			int red = c.getRed();
			int green = c.getGreen();
			int blue = c.getBlue();
			int i;
			Color[] colourValues = new Color[256];
			for (i=0;i<256;i++) {
				colourValues [i] = new Color(red,green,blue,i);
			}
			colours.put(p,colourValues);
		}
	}

	public void removeTelepointer(Person p) {
		pointers.remove(p);
	}

	public void telepointerMoved(GTTelepointerEvent gte, long timeGap) {
		Polygon tele;
		boolean inMap;
		Person who;
		int x, y;

		who =
			GTController.getInstance().getPersonFromSenderId(gte.getSenderID());
		inMap = pointers.containsKey(who);
		if (!inMap && who != null) {
			addTelepointer(who);
		}
		if (inMap) {
			tele = (Polygon) pointers.get(who);
			x = gte.getX();
			y = gte.getY();
			if (tele != null) {
				// only change if telepointer has moved
				if (x != tele.xpoints[0] || y != tele.ypoints[0]) {
					tele.xpoints[0] = x;
					tele.xpoints[1] = (int) (x + xs[1] * scale);
					tele.xpoints[2] = (int) (x + xs[2] * scale);
					tele.xpoints[3] = (int) (x + xs[3] * scale);
					tele.xpoints[4] = (int) (x + xs[4] * scale);
					tele.xpoints[5] = (int) (x + xs[5] * scale);
					tele.xpoints[6] = (int) (x + xs[6] * scale);
					tele.xpoints[7] = x;

					tele.ypoints[0] = y;
					tele.ypoints[1] = (int) (y + ys[1] * scale);
					tele.ypoints[2] = (int) (y + ys[2] * scale);
					tele.ypoints[3] = (int) (y + ys[3] * scale);
					tele.ypoints[4] = (int) (y + ys[4] * scale);
					tele.ypoints[5] = (int) (y + ys[5] * scale);
					tele.ypoints[6] = (int) (y + ys[6] * scale);
					tele.ypoints[7] = (int) (y + ys[7] * scale);
					if (count++ > 500)
						count = 0;
					comp.repaint();
				}
			}
			// add to trail
			((CircularQueue) trails.get(who)).add(x,y);
			
			// update confidence
			((ConfidenceValue) confidences.get(who)).setConfidence((int)timeGap);
		}
	}

	class MyMouseMotionAdapter extends MouseMotionAdapter {
		public void mouseMoved(MouseEvent e) {
			gtc.setTelepointer(new Point(e.getX(), e.getY()));
		}
		public void mouseDragged(MouseEvent e) {
			gtc.setTelepointer(new Point(e.getX(), e.getY()));
		}
	}
	
	class ConfidenceValue {
		int value;
		
		public ConfidenceValue (int val) {
			value = val;
		}
		
		public void setConfidence(int val) {
			if (val < 0) {
				value = 0;
			} else if (val > 255) {
				value = 255;
			} else {
				value = val;
			}
		}
		
		public int getConfidence () {
			return value;
		}
	}
}