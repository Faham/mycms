/*
 * Created on Oct 9, 2003
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package ca.usask.hci.gt.telepointers;

import java.awt.Point;
import java.util.LinkedList;
import java.util.List;

import ca.usask.hci.gt.GTEvent;

/**
 * @author Chris Fedak
 *
 * Encapsulates Telepointer events, allowing them to be send as int's rather than a Point object
 */
public class GTTelepointerEvent extends GTEvent {
	int fec, x, y;
	
	LinkedList orderedPoints;
	LinkedList intermediatePoints;
	/**
	 * Constructor for a point x,y
	 */
	public GTTelepointerEvent(int x, int y) {
		this();
		this.x = x;
		this.y = y;
		orderedPoints.clear();
		orderedPoints.add(new OrderedPoint(x,y,0));
	}
	
	/**
	 * Default constructor
	 */
	public GTTelepointerEvent() {
		super();
		super.setMessageName("GT_TELEPOINTER");
		orderedPoints = new LinkedList();
		intermediatePoints = new LinkedList();
	}

	/**
	 * @param x x poition of the telepointer
	 * @param y y position of the same
	 */
	public void setPoint(int x, int y) {
		this.x = x;
		this.y = y;	
		orderedPoints.clear();
		orderedPoints.add(new OrderedPoint(x,y,0));
	}
	
	/**
	 * @param p point representing current telepointer position.  values truncated to integers.
	 */
	public void setPoint(Point p) {
		x = p.x;
		y = p.y;
		orderedPoints.clear();
		orderedPoints.add(new OrderedPoint(x,y,0));
	}
	
	public void addOrderedPoint(Point p, int order) {
		orderedPoints.add(new OrderedPoint(p, order));
		OrderedPoint op = (OrderedPoint)orderedPoints.getFirst();
		x = op.getX();
		y = op.getY();
	}
	
	protected void addIntermediatePoint(OrderedPoint p) {
		intermediatePoints.add(p);
	}
	
	protected OrderedPoint[] getIntermediatePoints() {
		return (OrderedPoint[])intermediatePoints.toArray();
	}
	
	public List getFECList() {
		return (List)orderedPoints;
	}
	
	/**
	 * @return x position of telepointer
	 */
	public int getX() {
		return x;
	}
	
	/**
	 * @return y position of telepointer
	 */
	public int getY() {
		return y;
	}

	/**
	 * @param o
	 */
	public void addOrderedPoint(OrderedPoint o) {
		// TODO Auto-generated method stub
		orderedPoints.add(o);
		OrderedPoint op = (OrderedPoint)orderedPoints.getFirst();
		x = op.getX();
		y = op.getY();
	}
}
