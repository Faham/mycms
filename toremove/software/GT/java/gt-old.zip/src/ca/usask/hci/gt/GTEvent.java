package ca.usask.hci.gt;

import java.io.Serializable;

/**
	GTEvent.java:  Generic class for groupware events
	
	@author Carl Gutwin
	@author Chris Fedak
	@see	GTController#sendToOthers(GTEvent)
	@see	GTController#sendToAll(GTEvent)
	@see 	GTListener

*/
public class GTEvent implements Serializable {
  public static int TO_ALL = 0;
  public static int TO_OTHERS = 1;
  public static int TO_USER = 2;
  public static int TO_SERVER = 3;
  private String messageName;
  
  
  public int sendTarget;
  protected String senderID;
  protected String toUserID; // only used when sendType is TO_USER
  GTChannel channel;
  Object[] data = null;
	
  /**
    * Default Constructor
    *
  */
  public GTEvent () {
    // default constructor
  }
  
  /**
   * @param messageName the name of this message
   * @param data the data to transmit
   */
  public GTEvent (String messageName, Serializable[] data) {
  	this.messageName = messageName;
  	this.data = data;	
  } 
  
  /**
    * Specifies the channel that this event will be posted to
    *
    * @param	channel	 A String representing the channel name
  */	
  protected void setChannel(String channel) {
		this.channel = new GTChannel(channel);
  }
  /**
   * Specifies the channel that this event will be posted to
   * 
   * @param channel the GTChannel
   */
  public void setChannel(GTChannel channel) {
		this.channel = channel;
  }
  
  /**
   * @return the GTChannel that this Event is to be sent on
   */
  public GTChannel getChannel() {
	 	return channel; 
  }
  
  /**
    * Sets the data object for this Event message.  This object should contain all
    * of the data that the remote client will be recieve.  Objects should be data
    * only objects where possible, and implement Serializable  (?) I need to test this.
    *
    * @param	data	 A Data Object
  */
  public void setData(Serializable[] data) {
	  this.data = data;
  }

  /**
    * Gets the data.
    *
    * @return	An array of Objects representing the data in this event
  */
  public Object[] getData() {
	 	return data; 
  }
  
  /**
    * Sets the send type of the event.  Possible Values:
    * <ul><li>GTEvent.TO_ALL</li>
    *			<li>GTEvent.TO_OTHERS</li>
    *			<li>GTEvent.TO_USER</li></ul>
    * If type is GTEvent.TO_USER you must set toUserID to the UserID of the 
    * 	event recipient.
    *
    * @param	type	see above.
  */	
  public void setSendTarget (int type) {
    sendTarget = type;
  }

  /**
    * Sets the sender of the event.  Usually this will be the ID of the local
    * application.
    *
    * @param	from	The Sender's ID.
  */	
  public void setSender (String from) {
    senderID = from;
  }
  
  /**
   * @return the Person object for the sender of this Event
   */
  public Person getSenderAsPerson() {
  	return GTController.getInstance().getPersonFromSenderId(senderID);
  }
  
	/**
	 * @return the name of this message, useful at the receiver
	 */
	public String getMessageName() {
		return messageName;
	}

	/**
	 * @param messageName sets the name of this message
	 */
	public void setMessageName(String messageName) {
		this.messageName = messageName;
	}
	/**
	 * @return the id of the message originator
	 */
	public String getSenderID() {
		return senderID;
	}

	/**
	 * @return ID of the user this is being sent to (or was sent to)
	 */
	public String getToUserID() {
		return toUserID;
	}

	/**
	 * @param toUserID
	 */
	public void setToUserID(String toUserID) {
		this.toUserID = toUserID;
	}

	/**
	 * @return an int representing the target group of this event (GTEvent.TO_ALL etc..)
	 */
	public int getSendTarget() {
		return sendTarget;
	}

	/**
	 * @param data an array of Serializable objects.
	 */
	public void setData(Object[] data) {
		this.data = data;
	}

	/**
	 * internal use: tags the event with the unique StrinID of the sender.
	 * 
	 * @param senderID 
	 */
	public void setSenderID(String senderID) {
		this.senderID = senderID;
	}

}
