package ca.usask.hci.gt;

/**
	GTListener:  Interface for listeners of GTEvents.
	
	@author Carl Gutwin
	@author Chris Fedak
	@see	GTController#sendToOthers(GTEvent)
	@see	GTController#sendToAll(GTEvent)
	@see	GTEvent
	@see	GTController#registerChannelListener(GTChannelListener)
*/
public interface GTChannelListener {
	  /**
    * Method to handle incoming GTEvents.
    *
    * @param	t	the incoming GTEvent
    * @see	GTEvent
  */	
  public void handleGTEvent(GTEvent t);
}
