/*
 * Created on Oct 8, 2003
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package ca.usask.hci.gt;

/**
 * @author Chris Fedak
 *
 * Interface for listening to session events.
 */
public interface GTSessionListener {
	/** 
	 * @param pje contains details about the person joining
	 */
	public void personJoined(GTPersonEvent pje);
  
	/**
	 * @param pje contains details about the person leaving
	 */
	public void personLeft(GTPersonEvent pje);
	
	/**
	 * @param pje contains details about the Change.
	 */
	public void personChanged(GTPersonEvent pje);
}
