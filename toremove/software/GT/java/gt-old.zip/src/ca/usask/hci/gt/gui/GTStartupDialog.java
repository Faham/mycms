/*
 * Created on Feb 13, 2004
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package ca.usask.hci.gt.gui;

import java.awt.GridBagConstraints;
import java.awt.HeadlessException;

import javax.swing.JDialog;
import javax.swing.JPanel;

/**
 * @author Chris Fedak
 *
 */
public class GTStartupDialog extends JDialog {

	/**
	 * @throws java.awt.HeadlessException
	 */
	public GTStartupDialog() throws HeadlessException {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public void buildUI() {
		JPanel logo;
		GridBagConstraints gbc;
		
	}

}
