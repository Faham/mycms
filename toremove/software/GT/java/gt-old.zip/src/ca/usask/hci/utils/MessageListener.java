/*
 * Created on Nov 19, 2003
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package ca.usask.hci.utils;

import java.util.EventListener;

/**
 * @author Chris Fedak
 *
 */
public interface MessageListener extends EventListener {
	public void messageSent(MessageEvent me);
	public void errorSent(MessageEvent me);
}
