/*
 * Created on Feb 4, 2004
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package ca.usask.hci.utils;

import java.awt.Point;

/**
 * @author gutwin
 *
 * To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
public class CircularQueue {
	Point[] queue;
	int front,rear;
	int size, capacity, lastIndex;
	
	/**
	 * 
	 */
	public CircularQueue(int cap) {
		queue = new Point[cap];
		capacity = cap;
		lastIndex = capacity - 1;
		size = 0;
		front = 0;
		rear = 0;
		
		// fill queue with reusable points
		for (int i=0;i<capacity;i++) {
			queue[i] = new Point();
		}
	}

	public void add (int x, int y) {
		// add to next slot
		rear++;
		if (rear > lastIndex) {
			rear = 0;
		}
		queue[rear].x = x;
		queue[rear].y = y;
		if (size < capacity) {
			size++;
		}
		
		if (size == capacity) {
			// move front forwards
			front++;
			if (front > lastIndex) {
				front = 0;
			}
		}
	}
	
	public Point get (int index) {
		if (index > lastIndex) {
			return null;
		} else {
			return queue[(front+index) % capacity];
		}
	}
}
