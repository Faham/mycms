package ca.usask.hci.gt;


/**
	GTSessionEvent:  Abstract class for all events related to Session activities. NOT CURRENTLY USED.
	
	@author Carl Gutwin
	@author Chris Fedak
	
	@see GTEvent
*/
public abstract class GTSessionEvent extends GTEvent {

  public GTSessionEvent () {
  }
}
