/*
 * Created on Jan 20, 2004
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package ca.usask.hci.gt.telepointers;

import ca.usask.hci.gt.GTChannel;
import ca.usask.hci.gt.GTChannelListener;
import ca.usask.hci.gt.GTController;
import ca.usask.hci.gt.GTEvent;

/**
 * @author Chris Fedak
 *
 */
public class GTTCPTelepointerController extends GTTelepointerController {

	/**
	 * 
	 */
	public GTTCPTelepointerController(GTChannel gtc) {
		super();
		// TODO Auto-generated constructor stub
		System.out.println("*********** TCP -- GTTCPTelepointerController being created ************");
		gtw = new GTTelepointerWorker(gtc, new TCPTelepointerSender());
		gtw.setDelay(50);
		GTController.getInstance().addChannelListener(new GTInternalTelepointerListener(), "GT_TELEPOINTERS");
	}

	private class GTInternalTelepointerListener implements GTChannelListener {
		/* (non-Javadoc)
		 * @see ca.usask.hci.gt.GTChannelListener#handleGTEvent(ca.usask.hci.gt.GTEvent)
		 */
		public void handleGTEvent(GTEvent t) {
			// TODO Auto-generated method stub
			if(t.getMessageName().equals("GT_TELEPOINTER")) {
				addToHistory((GTTelepointerEvent)t);
			}
		}
	}

}
