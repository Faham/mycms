/*
 * Created on Jan 26, 2004
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package ca.usask.hci.gt;

import java.io.Serializable;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import ca.usask.hci.network.qos.GTQoSProperties;
import ca.usask.hci.utils.GTLogger;

/**
 * @author Chris Fedak
 *
 */
public class GTPingManager {

	Map latencyMap;
	GTLogger pingLog;
	
	/**
	 * 
	 */
	private GTChannel pingChan;
	
	public GTPingManager() {
		super();
		// TODO Auto-generated constructor stub
		GTQoSProperties qprops = new GTQoSProperties();
		qprops.setLatency(1.0);
		qprops.setReliability(0.25);
		pingChan = new GTChannel("GT_PINGS");
		pingChan.setQosProps(qprops);
		pingLog = new GTLogger("pings.txt");
		latencyMap = new HashMap();
	}
	
	public void start() {
		GTController.getInstance().registerChannel(pingChan);
		GTController.getInstance().subscribeToChannel("GT_PINGS");
		GTController.getInstance().addChannelListener(new PingListener(), pingChan);
		new Thread(new PingSender()).start();
	}
	
	public long getLatestPing(String clientID) {
		Long l = null;
		List list;
		list = ((List)latencyMap.get(clientID));
		if (list !=null) l = (Long)list.get(0);
		if(l!=null) {
			return l.longValue();
		}
		return -1;
	}
	
	public List getPingHistory(String clientID) {
		return ((List)latencyMap.get(clientID));
	}
	
	private class PingListener implements GTChannelListener {
		/* (non-Javadoc)
		 * @see ca.usask.hci.gt.GTChannelListener#handleGTEvent(ca.usask.hci.gt.GTEvent)
		 */
		public void handleGTEvent(GTEvent t) {
			Long time;
			Serializable[] retData;
			List pings;
			String source;
			
			// TODO Auto-generated method stub
			if(t.getMessageName().equals("ping")) {
				if(t.getData().length >1) {
					long receiveTime = ((Long)t.getData()[0]).longValue();
					long currentTime = System.currentTimeMillis();
					source = ((String)t.getData()[2]);
					//System.err.println("Ping! "+ String.valueOf(((currentTime-receiveTime)/2.0))+ " " + source + " me =" + GTController.getInstance().getMyID());
					if(!latencyMap.containsKey(source)) {
						pings = new LinkedList();
						pings.add(new Long((long) ((currentTime-receiveTime)/2.0)))	;
						latencyMap.put(source,pings);
					} else {
						pings = (List)latencyMap.get(source);
						pings.add(0,new Long((long) ((currentTime-receiveTime)/2.0)));
						if(pings.size()>999)
							pings.remove(999);
					}
					pingLog.log(String.valueOf(pings.get(0).toString()));
				} else {
					time = ((Long)t.getData()[0]);
					retData = new Serializable[] {time, new Long(System.currentTimeMillis()), GTController.getInstance().getMyID()};  
					t.setData(retData);
					//System.err.println("Pong! "+ t.getSenderID()+ " me =" + GTController.getInstance().getMyID());
					//return the ping with the current time on this machine
					GTController.getInstance().sendToOthers(t,"GT_PINGS");
				}
			}
			
		}
		
	}

	private class PingSender implements Runnable {
		GTEvent pingEv;
		Serializable[] data;
		/* (non-Javadoc)
		 * @see java.lang.Runnable#run()
		 */
		public void run() {
			// TODO Auto-generated method stub
			while(true) {
				pingEv = new GTEvent();
				pingEv.setChannel(pingChan);
				pingEv.setMessageName("ping");
				data = new Serializable[] {new Long(System.currentTimeMillis())};
				pingEv.setData(data);
				GTController.getInstance().sendToOthers(pingEv, "GT_PINGS");
				
				try {
					Thread.sleep(2000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			
		}	
	}
}
