/*
 * Created on Oct 31, 2003
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package ca.usask.hci.gt.ypserver;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;

import ca.usask.hci.gt.GTChannel;
import ca.usask.hci.gt.gui.GTMessageMonitor;
import ca.usask.hci.utils.Messenger;

/**
 * @author Chris Fedak
 *
 */
public class GTYellowPagesServer {
	LinkedHashMap servers; // stored with the host address as a key
	//UDPServerThread server = new UDPServerThread();
	ArrayList clients;
	int pruneDelay = 10000;

	public static void main(String[] args) {

		new GTYellowPagesServer();
	}

	public GTYellowPagesServer() {
		servers = new LinkedHashMap();
		clients = new ArrayList();
		new GTMessageMonitor();
		new Thread(new TCPServerThread(this)).start();
		new Thread(new PruneWorker()).start();
	}
	
	public synchronized void addServer(GTServerProperties props) {
		props.setAlive(true);
		servers.put(props.getHostAddress(), props);
	}
	
	public void addChannelToServer(GTChannel gtc, String host) {
		GTServerProperties gtp = (GTServerProperties)servers.get(host);
		gtp.addChannel(gtc);
	}
	
	public void removeChannelFromServer(GTChannel gtc, String host) {
		GTServerProperties gtp = (GTServerProperties)servers.get(host);
		gtp.removeChannel(gtc.getIdentifier());
	}
	
	public GTServerProperties[] getServers() {
		GTServerProperties[] props = null;
		props = (GTServerProperties[])servers.values().toArray();
		return props;
	} 
	
	public void removeWorker(GTYellowPagesTCPWorker worker) {
		clients.remove(worker);
	}
	
	public void addWorker(GTYellowPagesTCPWorker worker) {
		clients.add(worker);
	}

	/**
	 * @param string
	 */
	public synchronized void removeServer(String string) {
		// TODO Auto-generated method stub
		servers.remove(string);
	}

	/**
	 * @param string
	 */
	public void keepAlive(String string) {
		// TODO Auto-generated method stub
		((GTServerProperties)servers.get(string)).setAlive(true);
	}
	
	//prunes servers that haven't set a keep alive signal since the last time
	//prune dead servers ran.
	public synchronized void pruneDeadServers() {
		Iterator i = servers.values().iterator();
		GTServerProperties gtp;
		while(i.hasNext()) {
			try {
				gtp = (GTServerProperties)i.next();
				
				if(gtp.isAlive()) {
					gtp.setAlive(false);
					Messenger.getInstance().message("Alive"+gtp.toString(), this);
				} else {
					Messenger.getInstance().message("Pruned: "+gtp.toString(), this);
					i.remove();
				}
			} catch (Exception e) {
				Messenger.getInstance().error("Error during pruning" + e.getMessage(), this);
				return;
			}
		}
	}
	
	class PruneWorker implements Runnable {

		/* (non-Javadoc)
		 * @see java.lang.Runnable#run()
		 */
		public void run() {
			// TODO Auto-generated method stub
			while(true) {
				try {
					Thread.sleep(pruneDelay);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				pruneDeadServers();
			}
		}	
	}
}
