/*
 * Created on Feb 4, 2004
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package ca.usask.hci.gt.telepointers;

import java.awt.Point;

/**
 * @author gutwin
 *
 * To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
public class PredictedPoint extends Point {
	long timeGap;
	long estimatedLatency;
	/**
	 * 
	 */
	public PredictedPoint() {
		super();
		timeGap = 0;
	}

	/**
	 * @param p
	 */
	public PredictedPoint(Point p) {
		super(p);
		timeGap = 0;
	}

	public PredictedPoint(Point p, long time) {
		super(p);
		timeGap = time;
	}

	/**
	 * @param x
	 * @param y
	 */
	public PredictedPoint(int x, int y) {
		super(x, y);
		timeGap = 0;
	}

	public PredictedPoint(int x, int y, long time) {
		super(x,y);
		timeGap = time;
	}
	/**
	 * @return
	 */
	public long getTimeGap() {
		return timeGap;
	}

	/**
	 * @param timeGap
	 */
	public void setTimeGap(long timeGap) {
		this.timeGap = timeGap;
	}

	/**
	 * @return
	 */
	public long getEstimatedLatency() {
		return estimatedLatency;
	}

	/**
	 * @param estimatedLatency
	 */
	public void setEstimatedLatency(long estimatedLatency) {
		this.estimatedLatency = estimatedLatency;
	}

}
