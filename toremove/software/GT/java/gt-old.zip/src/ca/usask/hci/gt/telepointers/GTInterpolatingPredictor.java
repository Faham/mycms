/*
 * Created on Feb 20, 2004
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package ca.usask.hci.gt.telepointers;

import java.awt.Point;
import java.util.List;

/**
 * @author Chris Fedak
 *
 */
public class GTInterpolatingPredictor implements GTTelepointerPredictor {
	private long bufferTime;
	PredictedPoint lastPredict;
	/**
	 * 
	 */
	public GTInterpolatingPredictor(long latencyAdd) {
		super();
		bufferTime = latencyAdd;
		// TODO Auto-generated constructor stub
	}

	/* (non-Javadoc)
	 * @see ca.usask.hci.gt.telepointers.GTTelepointerPredictor#predict(ca.usask.hci.gt.telepointers.ClientTelepointerHistory, long)
	 */
	public PredictedPoint predict(ClientTelepointerHistory cth, long time) {
		List history = cth.history();
		long targetTime = time - bufferTime;
		long tx;
		OrderedPoint candidate = null;
		OrderedPoint candidate2 = null;
		OrderedPoint op1, op2;
		int period;
		int index1, index2;
		int dx, dy;
		double fractionalong;
		
		op2 = (OrderedPoint)history.get(0);
		op1 = (OrderedPoint)history.get(history.size()-1);
			
		period = (int) ((op2.getTimestamp()-op1.getTimestamp())/history.size());
		if(period ==0) period = 1;
		tx = time - op2.getTimestamp();
		//System.out.println(String.valueOf(tx));
		if(tx > bufferTime) {
			if(lastPredict !=null )
				return lastPredict;
			else 
				return new PredictedPoint(0,0);
		}
		tx = bufferTime - tx;
		index1 = (int)tx/period;
		index2 = index1+1;
		//System.out.println(String.valueOf(index1));
		
		if(index1 >= history.size()-2 || index1 < 0) {
			if(lastPredict !=null )
				return lastPredict;
			else 
				return new PredictedPoint(0,0);
		}

		candidate = (OrderedPoint)history.get(index1);
		candidate2 = (OrderedPoint)history.get(index2);
		
		
		/*
		Iterator i = history.iterator();
		while(i.hasNext()) {
			candidate = (OrderedPoint)i.next();
			if(targetTime < candidate.getTimestamp()) {
				break;
			}
		}
		while(i.hasNext()) {
			candidate2 = (OrderedPoint)i.next();
			if(targetTime > candidate2.getTimestamp()) {
				break;
			} 
		}*/
		
		if(candidate == null)
			return new PredictedPoint(0,0);
	
		if(candidate2 == null) {
			if(lastPredict != null) 
				return lastPredict;
			else 
				return lastPredict;
		}
			/*
		if(targetTime < candidate2.getTimestamp()) {
			if(lastPredict != null) 
				return lastPredict;
			else 
				return new PredictedPoint(candidate2.getX(), candidate2.getY(), time*-1);
		} */
			
		dx = candidate.getX() - candidate2.getX();
		dy = candidate.getY() - candidate2.getY();
		//fractionalong = 0;//(double)(targetTime - candidate2.getTimestamp()) /(double)(candidate.getTimestamp()-candidate2.getTimestamp());
		fractionalong = Math.min(1, targetTime-(op2.getTimestamp()-period*index2)) / period;
		
		lastPredict = new PredictedPoint((int)(candidate2.getX()+dx*fractionalong), (int)(candidate2.getY()+dy*fractionalong), time*-1); 
		return lastPredict;
	}

	/* (non-Javadoc)
	 * @see ca.usask.hci.gt.telepointers.GTTelepointerPredictor#latencyAdjustment()
	 */
	public int latencyAdjustment() {
		// TODO Auto-generated method stub
		return (int)(-1*bufferTime);
	}

	/* (non-Javadoc)
	 * @see ca.usask.hci.gt.telepointers.GTTelepointerPredictor#correct(java.awt.Point)
	 */
	public void correct(Point p) {
		// TODO Auto-generated method stub
		
	}

}
