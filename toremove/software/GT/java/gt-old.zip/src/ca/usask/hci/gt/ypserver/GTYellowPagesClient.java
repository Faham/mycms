/*
 * Created on Nov 18, 2003
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package ca.usask.hci.gt.ypserver;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.net.Socket;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import ca.usask.hci.gt.GTChannel;
import ca.usask.hci.gt.GTEvent;
import ca.usask.hci.utils.Messenger;

/**
 * @author Chris Fedak
 *
 */
public class GTYellowPagesClient {
	private String ypHost = "localhost";
	private int ypPort = 4499;
	private boolean working = false;
	private KeepAliveRunnable keepAlive; 
	private int keepAliveDelay = 5000;
	
	GTServerProperties gtp;
	
	public GTYellowPagesClient() {
		ypHost = "localhost";
		ypPort = 4499;
	}
	
	public GTYellowPagesClient(String ypHost, int ypPort) {
		this.ypHost = ypHost;
		this.ypPort = ypPort;
	}
	
	//used for server to YP communication. All of the communication is encapsulated 
	//in GTP, no further use of the client is neccessary, except to remove the server
	//from the yp listing.  After this is se
	public void registerServer(GTServerProperties gtp) throws IOException {
		this.gtp = gtp;
		try {
			sendServerProperties(gtp);
			gtp.setYPClient(this);
			//start keepAlive
			keepAlive = new KeepAliveRunnable();
			new Thread(keepAlive).start();
			Messenger.getInstance().message("Server Registered", this);
		} catch(IOException e) {
			Messenger.getInstance().error("Server Not Registered: IOException", this);
			throw e;
		}
	}
	
	public void unregisterServer() {
		gtp.setYPClient(null);
		keepAlive.stopRunning();
		keepAlive = null;
		Messenger.getInstance().message("Server unegistered", this);
		
	}
	
	protected synchronized void sendServerProperties(GTServerProperties serverProperties) throws IOException {
		//while(working) { }
		working = true;
		Socket ypSock;
		ObjectOutputStream out;
		ObjectInputStream in;
		GTEvent event;  	
		try {
			ypSock = new Socket(ypHost, ypPort);
			out = new ObjectOutputStream(ypSock.getOutputStream());
			event = new GTEvent("ADD_SERVER", new Serializable[] {serverProperties});
			out.writeObject(event);
			out.flush();
			ypSock.close();
		} catch(IOException e) {
			//e.printStackTrace();
			throw e;
		}
		Messenger.getInstance().message("Server Properties Sent", this);
		
		working = false;
		
	}
	
	protected synchronized void sendRemoveServer(GTServerProperties serverProperties) {
			//while(working) { }
			working = true;
			Socket ypSock;
			ObjectOutputStream out;
			ObjectInputStream in;
			GTEvent event;  	
			try {
				ypSock = new Socket(ypHost, ypPort);
				out = new ObjectOutputStream(ypSock.getOutputStream());
				event = new GTEvent("REMOVE_SERVER", new Serializable[] {serverProperties.getHostAddress()});
				out.writeObject(event);
				out.flush();
				ypSock.close();
			} catch(Exception e) {
				e.printStackTrace();
			}
			Messenger.getInstance().message("Server Removal Request Sent", this);
			working = false;
		}
	
	protected synchronized void sendNewChannel(GTChannel gtc) {
		//while(working) { }
		Socket ypSock;
		ObjectOutputStream out;
		ObjectInputStream in;
		working = true;
		GTEvent event; 
		try {
			ypSock = new Socket(ypHost, ypPort);
			out = new ObjectOutputStream(ypSock.getOutputStream());
			event = new GTEvent("ADD_CHANNEL", new Serializable[] {gtc});
			out.writeObject(event);
			out.flush();
			ypSock.close();
		} catch(Exception e) {
			e.printStackTrace();
		}
		Messenger.getInstance().message("New channel sent", this);
		working = false;
	}
	
	public synchronized void sendRemoveChannel(GTChannel gtc) {
		//while(working) { }
		Socket ypSock;
		ObjectOutputStream out;
		ObjectInputStream in;
		working = true;
		GTEvent event; 
		try {
			ypSock = new Socket(ypHost, ypPort);
			out = new ObjectOutputStream(ypSock.getOutputStream());
			event = new GTEvent("REMOVE_SERVER", new Serializable[] {gtc});
			out.writeObject(event);
			out.flush();
			ypSock.close();
		} catch(Exception e) {
			e.printStackTrace();
		}
		Messenger.getInstance().message("Channel Remove Request Sent", this);
		working = false;
	}
		
	public synchronized List getServerList() {
		//while(working) { }
		Socket ypSock;
		ObjectOutputStream out;
		ObjectInputStream in;
		working = true;
		GTEvent event;
		LinkedList l = new LinkedList();
		boolean done = false; 
		try {
			ypSock = new Socket(ypHost, ypPort);
			out = new ObjectOutputStream(ypSock.getOutputStream());
			in = new ObjectInputStream(ypSock.getInputStream());
			event = new GTEvent("GET_SERVER_LIST", new Serializable[] {});
			out.writeObject(event);
			out.flush();

			while(!done) {
				event = (GTEvent)in.readObject();
				if(event.getMessageName().equals("END_LIST")) {
					done = true;
				} else if(event.getMessageName().equals("SERVER_LIST")) {
					l.add(event.getData()[0]);
				}
			}
			ypSock.close();
		} catch(Exception e) {
			e.printStackTrace();
		}
		Messenger.getInstance().message("Server List Retrieved Entries:" +String.valueOf(l.size()), this);
		working = false;
		return l;
	}

	/**
	 * 
	 */
	public synchronized void sendAllChannels() {
		// TODO Auto-generated method stub
		Iterator i = gtp.getChannels().values().iterator();
		while(i.hasNext()) {
			this.sendNewChannel((GTChannel)i.next());
		}
		Messenger.getInstance().message("Channel Update Sent", this);
	}	
	
	/**
	 * 
	 */
	private synchronized void sendKeepAlive() {
		// TODO Auto-generated method stub
		Socket ypSock;
		ObjectOutputStream out;
		ObjectInputStream in;
		working = true;
		GTEvent event;
		LinkedList l = new LinkedList();
		boolean done = false; 
		try {
			ypSock = new Socket(ypHost, ypPort);
			out = new ObjectOutputStream(ypSock.getOutputStream());
			in = new ObjectInputStream(ypSock.getInputStream());
			event = new GTEvent("KEEP_ALIVE", new Serializable[] {gtp.getHostAddress()});
			out.writeObject(event);
			out.flush();
			ypSock.close();
			Messenger.getInstance().message("Keep Alive Sent", this);
		} catch(Exception e) {
			e.printStackTrace();
		}			
	}
	
	class KeepAliveRunnable implements Runnable {
		boolean run = true;
		/* (non-Javadoc)
		 * @see java.lang.Runnable#run()
		 */
		public void run() {
			// TODO Auto-generated method stub
			while(run) {
				try {
					Thread.sleep(keepAliveDelay);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				sendKeepAlive();
			}
		}

		public void stopRunning() {
			run = false;
		}
		
	}
	
}