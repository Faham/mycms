package ca.usask.hci.gt;

import java.io.*;
import java.net.*;
import java.util.*;
import java.awt.Color;
import java.awt.Graphics;

import ca.usask.hci.gt.adaptive.GTAdaptiveHPTControl;
import ca.usask.hci.gt.gui.*;
//import ca.usask.hci.gt.preferences.GTPreferenceManager;
import ca.usask.hci.gt.telepointers.*;
import ca.usask.hci.network.GTNetwork;
import ca.usask.hci.network.GTNetworkEvent;
import ca.usask.hci.network.GTNetworkListener;
import ca.usask.hci.network.qos.*;
import ca.usask.hci.utils.Messenger;

/**
	GTController.java:  The singleton class through which all groupware events are handled.  All GT applications
		have a single instance of this object.
	
	@author Carl Gutwin
	@author Chris Fedak


*/
public class GTController {
	/**
	 * The singleton instance of GTControoler
	 */
  static private GTController instance = new GTController();
  /**
   * A mapping of listeners to their channels 
   */
  private HashMap channelListeners;
  /**
   * A mapping of channelID's to GTChannel instances
   */
  private HashMap knownChannels;
  /**
   * A mapping of id's to their Objects
   */
  private HashMap idsToObjects;
  /**
   * Reverse mapping connecting object instances to their id's
   */
  private HashMap	objectsToIDs;
  /**
   * the list of other clients on the server
   */
  private LinkedHashMap knownPeople;
  /**
   * a list of GTSessionListeners to publish GTSessionEvents to
   */
  private LinkedList sessionListeners;
  /**
   * a string uniquely identifying this GTController instance
   */
  private String myID;
	/**
	 * The nextID to assign to a registered object 		
	 */
  private int nextID;
  /**
   * The person object representing the user of this GTController
   */
  private Person me;
  /**
   * lock object
   */
  private boolean writing;
  /**
   * a pointer to the GTNetwork layer object
   */
  private GTNetwork network;
  /**
   * the short client id assinged by the server (part of HPT)
   */
  private short clientNumber = -1;
  
  /**
   * literal determining if this client will use HPT.  (needs to be a part of GTPreferenceManager)
   */
  private boolean highPerformanceTelepointers = true;
  /**
   * link to the object that determines and tracks latency to various clients 
   */
  private GTPingManager pingManager;
	/**
	 * link to the telepointer controller instance.
	 */
  private GTTelepointerController telepointerController;

  /**
   * link to the object that determines and tracks latency to various clients 
   */
  private GTAdaptiveHPTControl adaptiveHPTControl;

  /**
   * private constructor: use getInstance() to get access to an instance of this class.
   * 
   * Developer note: it takes a fair bit of time for this method to complete, so if you are
   * ending up with null pointers on getInstance() when working on constructors in GT internals, 
   * check to see if the constructor of GT controller has finished by the time your constructor has been called.
   *
   */
  private GTController() {
  	network = new GTNetwork();
  	network.addNetworkListener(new ControllerNetworkListener());
  	//interface for GTController setup here (Supernode, run dedicated server, client/server, or act as client)
  	connect();
  	myID = network.getLocalAddress().toString() + ":" + network.getLocalTCPPort() + ":";
  	nextID = 0;
  	
  	sessionListeners = new LinkedList();
  	knownPeople = new LinkedHashMap();
  	
  	idsToObjects = new HashMap();
  	objectsToIDs = new HashMap();
  	
  	//create known Channels list and add system Channels
  	knownChannels = new HashMap();
  	channelListeners = new HashMap();
  	
  	registerChannel(new GTChannel("GT_CHANNELS"));
  	registerChannel(new GTChannel("GT_DEFAULT"));
  	registerChannel(new GTChannel("GT_SESSION"));
  	GTChannel temp = new GTChannel("GT_TELEPOINTERS");
  	GTQoSProperties tempQos = new GTQoSProperties();
  	tempQos.setReliability(1.0);
  	tempQos.setLatency(0.0);
  	temp.setQosProps(tempQos);
  	temp.setQosProps(new GTHPTQOS());
  	registerChannel(temp);
  	
  	//create telepointerController
  	//telepointerController = new GTTelepointerController((GTChannel)knownChannels.get("GT_TELEPOINTERS"));
  	
  	//add internal listeners
  	addChannelListener(new GTInternalSessionListener(), "GT_SESSION");
  	login();
  	pingManager = new GTPingManager();
  	adaptiveHPTControl = new GTAdaptiveHPTControl();
  }

  /**
    * Returns the singleton instance of GTController.  Applications
    * must use this method rather than creating GTController directly.
    *
    * @return      The GTContoller instance
  */	
  public static GTController getInstance () {
    return instance;
  }
  
  public void setChannelQos(String channel, GTQoSProperties qp) {
  	GTChannel chan = (GTChannel)knownChannels.get(channel);
  	if(chan!=null) {
  		chan.setQosProps(qp);
  	}
  	
  }
  
  public void adaptiveNetworking(boolean on) {
  	GTHighPerformanceTelepointerController ghptc;
  	if(highPerformanceTelepointers && telepointerController != null) {
  		ghptc = (GTHighPerformanceTelepointerController)telepointerController;
  		ghptc.setAdaptToNetwork(on);
  	}
  }
  
  /**
   * @return a short between 0 and 15 representing the short ID assigned by the server,
   * 	-1 indicates that the server has not yet assigned a short ID
   */
  public short getClientNumber() {
  	return clientNumber;
  }
  
  /**
   * Changes the TelepointerController instance to suit the desired method.
   * 
   * @param performance true if high performance telepointers should be used
   */
  public void setHighPerformanceTelepointers(boolean performance) {
  	//new Throwable().printStackTrace();
  	highPerformanceTelepointers = performance;
  	if(performance) {
  		try {
  			if(telepointerController !=null) {
  				telepointerController.kill();
  			}
				telepointerController = new GTHighPerformanceTelepointerController((GTChannel)knownChannels.get("GT_TELEPOINTERS"));
			} catch (SocketException e) {
				// TODO Auto-generated catch block
				Messenger.getInstance().error("Exception while creating telepointer Controller");
				telepointerController = new GTTCPTelepointerController((GTChannel)knownChannels.get("GT_TELEPOINTERS"));
			}
  	} else {
			telepointerController = new GTTCPTelepointerController((GTChannel)knownChannels.get("GT_TELEPOINTERS"));
  	}
  } 

	/**
	 * routine for login to a GTserver
	 *
	 */
  private void login () {
      // uncomment the following when we have a GTLogin class
      GTLogin loginWindow = new GTLogin();
      loginWindow.show();
      Person p = new Person(loginWindow.getName(),loginWindow.getColor() );
			setPerson(p);
  }
  
  /**
   * Simply exits the system at the moment.  More sophisticated behaviour to come
   */
  public void logout() {
  	//System.exit(0);  	
  }

   /**
    * Sets the identity of the local user in GTController, and updates the
    * server, performing a login if this is the first time person has been set,
    * modifying the person details otherwise.  All other clients are notified.
    *
    * @param	p		the Person object representing the local user	 
    * @see Person
  */	
  public void setPerson (Person p) {
		Serializable[] data;
    if(me == null) {
			me = p;
			me.setClientID(myID);
	    // tell everyone else that I've arrived
    	registerObject(me,myID);
    	Integer i = new Integer(network.getLocalUDPPort());
			data = new Serializable[] {me,myID,i};
    	GTEvent gse = new GTEvent();
    	gse.setData(data);
    	gse.setMessageName("GT_LOGIN");
    	sendToOthers(gse, "GT_SESSION");
		} else {
			me = p;
			// tell everyone else that I've changed my name
    	registerObject(me,myID);
			Integer i = new Integer(network.getLocalUDPPort());
			data = new Serializable[] {me,myID, i};
    	GTEvent gse = new GTEvent();
    	gse.setData(data);
    	gse.setMessageName("GT_MODIFY_LOGIN");
    	sendToOthers(gse, "GT_SESSION");
		}		
  }

	/**
	 * There is only on Telepointer Controller per GT controller, get a reference to it with
	 * this method.
	 * 
	 * @return the TelepointerController for this client
	 */
	synchronized public GTTelepointerController getTelepointerController() {
		if(telepointerController == null) {
			//System.out.println(">>> this is GTController ("+this.toString()+"); about to create telepointercontroller ************");
			setHighPerformanceTelepointers(highPerformanceTelepointers);
		}
		return telepointerController;
	}

  /**
    * Sets the color of the local user in GTController
    * QUESTION: does this belong here?  or should we restrint the interface to 
    * 	getMe() and then set Color directly?
    *
    * @param	newColor		a string representing the hex code for the desired code	 
    * @see Person	Color
  */	
  public void setColor (String newColor) {
    me.color = Color.getColor(newColor);
    if (me.color == null) {
      me.color = Color.yellow;
    }
		Serializable[] data = new Serializable[] {me,myID};
		GTEvent gse = new GTEvent();
		gse.setData(data);
		gse.setMessageName("GT_MODIFY_LOGIN");
		sendToOthers(gse, "GT_SESSION");
  }

	/**
	 * this perforse the initial connection to a GTServer, always tries localhost
	 * first.  (Remove this on release)
	 *
	 */
  private void connect () {
    boolean connected = false;
//    connected = network.connect("localhost", 4444);
    connected = network.connect("192.168.123.101", 4444);
    while(!connected) {
    	GTConnectionDialog cdialog = new GTConnectionDialog();
    	cdialog.show();
    	switch(cdialog.action) {
    		case GTConnectionDialog.LOCAL:
    			connected = network.connect("localhost", 4444);	
    			break;
    		case GTConnectionDialog.REMOTE:
    			connected = network.connect(cdialog.outHost, cdialog.outPort);
    			break;
    		case GTConnectionDialog.QUIT:
    			System.exit(1);
    			break;
    	}
    }
  }
  
  /**
   * Supposed to perform a clean reconnect to the server:
   * It doesn't work at the moment, avoid the use of this method.
   *
   */
  public void reconnect() {
  	try {
			network.disconnect();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		connect();
		myID = network.getLocalAddress().toString() + ":" + network.getLocalTCPPort() + ":";
		nextID = 0;
  
		sessionListeners = new LinkedList();
		knownPeople = new LinkedHashMap();
  
		idsToObjects = new HashMap();
		objectsToIDs = new HashMap();
	
		//create known Channels list and add system Channels
		knownChannels = new HashMap();
		channelListeners = new HashMap();
	
		registerChannel(new GTChannel("GT_CHANNELS"));
		registerChannel(new GTChannel("GT_DEFAULT"));
		registerChannel(new GTChannel("GT_SESSION"));
		GTChannel temp = new GTChannel("GT_TELEPOINTERS");
		GTQoSProperties tempQos = new GTQoSProperties();
		tempQos.setReliability(1.0);
		tempQos.setLatency(0.0);
		temp.setQosProps(tempQos);
		temp.setQosProps(new GTHPTQOS());
		registerChannel(temp);
	
		//add internal listeners
		addChannelListener(new GTInternalSessionListener(), "GT_SESSION");
		login();
  }
	
  /**
    * sends an event to all other clients in the group
    *
    * @param	ge		the GTEvent to be sent.
    * 				channel String Identifier of channel to send on
    * @see GTEvent
  */	
  public void sendToOthers (GTEvent ge, String channel) {
    GTChannel gc;
    gc = (GTChannel)knownChannels.get(channel);
    if(gc != null) {
    	ge.setSendTarget(GTEvent.TO_OTHERS);
    	ge.setChannel(gc);
			send(ge);
    } else {
    	System.err.println("No such channel " + channel);
    }
  }
	
	/**
		* sends an event to all other clients in the group
		*
		* @param	ge		the GTEvent to be sent.
		* 				channel GTChannel channel to send on
		* @see GTEvent
	*/	
	public void sendToOthers (GTEvent ge, GTChannel channel) {
		GTChannel gc;
		gc = (GTChannel)knownChannels.get(channel.getIdentifier());
		if(gc != null) {
			ge.setSendTarget(GTEvent.TO_OTHERS);
			ge.setChannel(gc);
			send(ge);
		} else {
			System.err.println("No such channel " + channel);
		}
	}
  
	/**
		* sends an event to all other clients in the group (on default Channel)
		*
		* @param	ge		the GTEvent to be sent.
		* @see GTEvent
	*/	
	public void sendToOthers (GTEvent ge) {
		ge.setSendTarget(GTEvent.TO_OTHERS);
		ge.setChannel((GTChannel)knownChannels.get("GT_DEFAULT"));
		send(ge);
	}
	/**
		* sends an event to all other clients in the group
		*
		* @param	messageType		a message Identifier
		* 				data				  an array of data representing the event
		* 				channel String Identifier of channel to send on
		* @see GTEvent
	*/	
	public void sendToOthers (String messageType, Serializable[] data, String channel) {
		GTEvent ge = new GTEvent(messageType, data);
		GTChannel gc;
		gc = (GTChannel)knownChannels.get(channel);
		if(gc != null) {
			ge.setSendTarget(GTEvent.TO_OTHERS);
			ge.setChannel(gc);
			send(ge);
		} else {
			System.err.println("No such channel " + channel);
		}
	}
	
	/**
		* sends an event to all other clients in the group
		*
		* @param	messageType		a message Identifier
		* 				data				  an array of data representing the event
		* 				channel GTChannel channel to send on
		* @see GTEvent
	*/	
	public void sendToOthers (String messageType, Serializable[] data, GTChannel channel) {
		GTEvent ge = new GTEvent(messageType, data);
		GTChannel gc;
		gc = (GTChannel)knownChannels.get(channel);
		if(gc != null) {
			ge.setSendTarget(GTEvent.TO_OTHERS);
			ge.setChannel(gc);
			send(ge);
		} else {
			System.err.println("No such channel " + channel);
		}
	}
  
	/**
		* sends an event to all other clients in the group (on default Channel)
		*
		* @param	messageType		a message Identifier
		* 				data				  an array of data representing the event
		* @see GTEvent
	*/	
	public void sendToOthers (String messageType, Serializable[] data) {
		GTEvent ge = new GTEvent(messageType, data);
		ge.setSendTarget(GTEvent.TO_OTHERS);
		ge.setChannel((GTChannel)knownChannels.get("GT_DEFAULT"));
		send(ge);
	}
	
	/**
		* sends an event to all clients in the group.  Unlike sendToOthers, this will
    *	also send the event to the local client 
		*
		* @param	ge		the GTEvent to be sent.
		* 				channel GTChannel channel to send on
		* @see GTEvent
	*/	
	public void sendToAll (GTEvent ge, GTChannel channel) {
		GTChannel gc;
		gc = (GTChannel)knownChannels.get(channel);
		if(gc != null) {
			ge.setSendTarget(GTEvent.TO_ALL);
			ge.setChannel(gc);
			send(ge);
		} else {
			System.err.println("No such channel " + channel);
		}
	}

 	/**
    * sends an event to all clients in the group.  Unlike sendToOthers, this will
    *	also send the event to the local client
    *
    * @param	ge		the GTEvent to be sent.
    * @see GTEvent
  */	
  public void sendToAll (GTEvent ge, String channel) {
		GTChannel gc;
		gc = (GTChannel)knownChannels.get(channel);
		if(gc != null) {
			ge.setSendTarget(GTEvent.TO_ALL);
			ge.setChannel(gc);
			//System.out.println("sending on channel " + gc.getIdentifier());
			send(ge);
		} else {
			System.err.println("No such channel " + channel);
		}
  }
  
	/**
		* sends an event to all clients in the group.  Unlike sendToOthers, this will
		*	also send the event to the local client.  This version sends on the default channel.
		*
		* @param	ge		the GTEvent to be sent.
		* @see GTEvent
	*/	
	public void sendToAll (GTEvent ge) {
		ge.setSendTarget(GTEvent.TO_ALL);
		ge.setChannel((GTChannel)knownChannels.get("GT_DEFAULT"));
		send(ge);
	}
	
	/**
		* sends an event to all clients in the group.  Unlike sendToOthers, this will
		*	also send the event to the local client.
		*
		* @param	messageType		a message Identifier
		* 				data				  an array of data representing the event
		* 				channel String Identifier of channel to send on
		* @see GTEvent
	*/	
	public void sendToAll (String messageType, Serializable[] data, String channel) {
		GTEvent ge = new GTEvent(messageType, data);
		GTChannel gc;
		gc = (GTChannel)knownChannels.get(channel);
		if(gc != null) {
			ge.setSendTarget(GTEvent.TO_ALL);
			ge.setChannel(gc);
			send(ge);
		} else {
			System.err.println("No such channel " + channel);
		}
	}
	
	/**
		* sends an event to all clients in the group.  Unlike sendToOthers, this will
		*	also send the event to the local client.
		*
		* @param	messageType		a message Identifier
		* 				data				  an array of data representing the event
		* 				channel GTChannel channel to send on
		* @see GTEvent
	*/	
	public void sendToAll (String messageType, Serializable[] data, GTChannel channel) {
		GTEvent ge = new GTEvent(messageType, data);
		GTChannel gc;
		gc = (GTChannel)knownChannels.get(channel);
		if(gc != null) {
			ge.setSendTarget(GTEvent.TO_ALL);
			ge.setChannel(gc);
			send(ge);
		} else {
			System.err.println("No such channel " + channel);
		}
	}
  
	/**
		* sends an event to all clients in the group.  Unlike sendToOthers, this will
		*	also send the event to the local client.  This version sends on the default channel.
		*
		* @param	messageType		a message Identifier
		* 				data				  an array of data representing the event
		* @see GTEvent
	*/	
	public void sendToAll (String messageType, Serializable[] data) {
		GTEvent ge = new GTEvent(messageType, data);
		ge.setSendTarget(GTEvent.TO_ALL);
		ge.setChannel((GTChannel)knownChannels.get("GT_DEFAULT"));
		send(ge);
	}
	
	/**
	 * sends an event to the server only (without distributing it to other clients) used for a 
	 * few internal methods: may be neccessary when we start implementing an API for Server Side logic.
	 * 
	 * @param e event to send
	 * @param channel	a unique string representing the channel to send this message on
	 */
	public void sendToServer(GTEvent e, String channel) {
		// TODO Auto-generated method stub
		GTChannel gc;
		gc = (GTChannel)knownChannels.get(channel);
		if(gc != null) {
			e.setSendTarget(GTEvent.TO_SERVER);
			e.setChannel(gc);
			send(e);
		} else {
			System.err.println("No such channel " + channel);
		}
	}
	
	/**
	 * Sends a message to a single user only.
	 * 
	 * @param e event to send
	 * @param channel	a unique string representing the channel to send this message on
	 */
	public void sendToUser(GTEvent e, String channel) {
		// TODO Auto-generated method stub
		GTChannel gc;
		gc = (GTChannel)knownChannels.get(channel);
		if(gc != null) {
			e.setSendTarget(GTEvent.TO_USER);
			e.setChannel(gc);
			send(e);
		} else {
			System.err.println("No such channel " + channel);
		}
	}
	
   /**
    * Internal method, actually does the work of sending the GTEvent to the server
    * 
    * @param ge event to be sent
    */
  private synchronized void send (GTEvent ge) {
    ge.setSender(myID); //keep this.
		//	send to server
    try {
      	network.send(ge, ge.getChannel().getQosProps());
    } catch (IOException e) {
      Messenger.getInstance().error("GTNetwork failed to send message");
    }
  }

	/**
	 * In order to send or receive data on a Channel, you must first register the channel.
	 * 
	 * 
	 * @param channel the channel to register with the Server
	 */
	public void registerChannel(GTChannel channel) {
		if(knownChannels.get(channel.getIdentifier())==null) {
			knownChannels.put(channel.getIdentifier(), channel);
			channelListeners.put(channel, new LinkedList());
			if(channel.getQosProps() == null) {
				channel.setQosProps(new GTQoSProperties());
			}
			GTEvent gte;
			gte = new GTEvent("ADD_CHANNEL", new Serializable[] {channel});		
			sendToOthers(gte, (GTChannel)knownChannels.get("GT_CHANNELS"));
			System.out.println(channel.getIdentifier()+ " registered");
		}
	}

	/**
	 * 
	 * 
	 * @param channelID unique identifier of a channel
	 * @return true if a channel represented by channelID is known.
	 */
	public boolean channelExists (String channelID) {
		if(knownChannels.get(channelID)!=null) {
			return true;
		} else {
			return false;
		}
	}
	
	/**
	 * carls method:, subsribes toa channel as represented on the server?
	 * 
	 * @param channelID
	 */
	public void subscribeToChannel(String channelID) {
		if (knownChannels.get(channelID) != null) {
			GTEvent gte;
			gte = new GTEvent("SUBSCRIBE_TO_CHANNEL", new Serializable[] { channelID });
			sendToOthers(gte, (GTChannel) knownChannels.get("GT_CHANNELS"));
			System.out.println(channelID + " subscription requested");
		}
	} 
  /**
    * Registers a listener to receive GTEvents.
    *
    *
    * @param	gl		the GTListener to receive events.
    * 				channel	the string identifier of the GTChannel to listen to
    * @see GTListener
  */	
  public void addChannelListener (GTChannelListener gl, String channel) {
    List l;
    GTChannel gc = (GTChannel)knownChannels.get(channel);
    if(gc != null) {
			l = (List)channelListeners.get(gc);
			l.add(gl);	
    } else {
			System.err.println("No Such Channel:" + channel);	
		}
  }
	
	/**
		* Registers a listener to receive GTEvents.
		*
		*
		* @param	gl		the GTListener to receive events.
		* 				channel	the GTChannel to listen to
		* @see GTListener
	*/	
  public void addChannelListener(GTChannelListener gl, GTChannel channel) {
		List l;
		l = (List)channelListeners.get(channel);
		if(l != null){
			l.add(gl);
  	} else {
  		System.err.println("No Such Channel:" + channel.getIdentifier());	
  	}
  }
  
	/** Removes a GTListener from the the listener list.  It will no longer
	 * be notified of Channel events for the specified channel.
	 * @param gl	The listener to remove
	 * @param channel	The channel to remove it from.	
	 */
	public void removeChannelListener(GTChannelListener gl, GTChannel channel) {
		List l;
		l = (List)channelListeners.get(channel);
		if(l!=null) {
			l.remove(gl);
		}
	}
  
	/**
	* Registers a listener to receive GTEvents.  This version will add a listener 
	* to the default channel and is a equivalent to calling
	* addChannelListener(gl, "GT_DEFAULT");
	*
	*
	* @param	gl		the GTListener to receive events.
	* @see GTListener
*/	
  public void addChannelListener(GTChannelListener gl) {
  	LinkedList list = (LinkedList)channelListeners.get((GTChannel)knownChannels.get("GT_DEFAULT"));
  	list.add(gl);
  }
  
  /**Removes a GTListener from the the listener list.  It will no longer
	 * be notified of Channel events for the default channel. This is equvialent
	 * to calling removeChannelListener(gl, "GT_DEFAULT");
   * @param gl The listener to remove
   */
  public void removeChannelListener(GTChannelListener gl) {
		LinkedList list = (LinkedList)channelListeners.get((GTChannel)knownChannels.get("GT_DEFAULT"));
		list.remove(gl);
  }
  
  /**	adds a GTSessionListener to the listener list.  It will be notified of events concerning
   * the current session.
   * 
   * @param gsl the session listener to add
   * 
   * @see GTSessionListener
   */
  public void addSessionListener(GTSessionListener gsl) {
  	System.out.println("adding session listener: " + gsl.toString());
  	sessionListeners.add(gsl);
  } 
  
  /**
   * removes a GTSessionListener, it will no longer be notified of session events
   * @param gsl the GTSessionListener to remove
   */
  public void removeSessionListener(GTSessionListener gsl) {
  	sessionListeners.remove(gsl);
  }

  /**
    * Dispatches events to local listeners.
    *
    *
    * @param	gte		the GTEvent to Dispatch
    * @see GTEvent
  */	
	protected void dispatchEvent (GTEvent gte) {
		Iterator step;
		GTChannelListener gl;
		String className;
		GTChannel channel;
		List l;
    
    className = gte.getClass().getName();
    channel = gte.getChannel();
    if (className.equals("GTSessionEvent")) { 
      //System.out.println(className);
    } else {
    	channel = (GTChannel)knownChannels.get((String)channel.getIdentifier());
    	//gets the list of channel Listenerts for the channel assocaited with this event.
    	while((l = (List)channelListeners.get(channel))==null) { } 	
      step = l.iterator();
      while (step.hasNext()) {
	      gl = (GTChannelListener)step.next();
				gl.handleGTEvent(gte);
      }
    }
  }

  /**
    * Registers an object with the GTController, and associates it with a local unique id.
    *
    *
    * @param	obj		the Object to register
  */
  public void registerObject (Object obj) {
    String id;

    id = myID + nextID;
    nextID++;
    idsToObjects.put(id,obj);
    objectsToIDs.put(obj,id);
  }
  /**
    * Registers an object with the GTController, and associates it with a provided id.
    *
    *
    * @param	obj		the Object to register
    * @param 	id	the id to associate the object with
    * @see GTEvent
  */
  public void registerObject (Object obj, String id) {
    idsToObjects.put(id,obj);
    objectsToIDs.put(obj,id);
  }

  /**
    * Returns an object's ID if it has been registered.
    *
    *
    * @return	the objects ID String, if available, null if not.
    *	@param	obj		the Object to find an ID for
    * @see #registerObject()
  */
  public String getID (Object obj) {
    return (String)objectsToIDs.get(obj);
  }

  /**
    * Retrieves an Object by ID.
    *
    *
    * @return	the Object associated with id, if the id is valid.  null otherwise.
    * @param 	id	the id of the desired object.
    * @see #registerObject()
  */
  public Object getObject (String id) {
    return idsToObjects.get(id);
  }

  /**
    * Gets the next unassigned id.
    *
    *
    * @return	the next unassigned ID string.
    * @see #registerObject()
  */
  public String getNextID () {
    String id = myID + nextID;
    nextID++;
    return id;
  }
  
  /**
    * Draws telepointers to a Graphics context.  Not completely functional as of this version.
    *
    *
    * @param	g	The Graphics context to draw the telepointers to.
    * @see java.awt.Graphics
  */
  public void drawTelepointers (Graphics g) {
    if (me != null) {
      g.setColor(me.color);
      g.fillRect(10,10,40,40);
    }
  }
  
  /**
   * Useful for connecting evnts to people, and using their preferences for representing
   * their actions locally.  GTTelepointerController has methods that are more useful in
   * conjunction with this one.
   * 
   * @param id the client id of the person to look up
   * @return the Person linked with the client.  null on failure
   */
  public Person getPersonFromSenderId(String id) {
  	return (Person)knownPeople.get(id);
  }
  
  /**
   * @return returns the Person object representing the local user
   */
  public Person getMe() {
  	return me;
  }
  
  /**
   * @return returns an array of all known clients of the system, including the local
   * 	user
   */
  public Person[] getPeople() {
  	Collection c = knownPeople.values();
  	if(c != null) {
  		Object[] o = c.toArray();
			Person[] returnme = new Person[o.length];
			for(int i = 0; i<o.length;i++) {
				returnme[i] = (Person)o[i];
			}
			return returnme;
  	}
  	System.err.println("getPeople returned null");
  	return new Person[0];
  }
  
  private class GTInternalSessionListener implements GTChannelListener {
		GTPersonEvent pe;
		/** 
		 * @see ca.usask.hci.gt.GTChannelListener#handleGTEvent(ca.usask.hci.gt.GTEvent)
		 */
		public void handleGTEvent(GTEvent t) {
			if(t.getMessageName().equals("GT_LOGIN")) {
				//System.out.println("in handleGTEvent of GTInternalSessionListener");
				//System.out.println("There are " + sessionListeners.size() + "session listeners for this event");
				Iterator i = sessionListeners.iterator();
				
				//lazily create event
				if(pe == null) pe = new GTPersonEvent(); 
				
				//populate from data
				Object[] data = (Object[])t.getData();
				pe.setPerson((Person)data[0]);
				pe.setPID((String)data[1]);
				pe.getPerson().setClientID(t.getSenderID());
				
				//add to known People
				knownPeople.put(t.getSenderID(), pe.getPerson());
				
				Messenger.getInstance().message(pe.getPerson().toString());
				
				//fire listeners
				while(i.hasNext()){
					//System.out.println("calling personJoined from GTInternalSessionListener");
					((GTSessionListener)i.next()).personJoined(pe);
				}
			}	else if (t.getMessageName().equals("GT_LOGOUT")) {
				Iterator i = sessionListeners.iterator();
				
				//lazily create event
				if(pe == null) pe = new GTPersonEvent(); 
				
				//populate from data
				Object[] data = (Object[])t.getData();
				pe.setPerson((Person)data[0]);
				pe.setPID((String)data[1]);
				
				//remove from known People
				knownPeople.remove(t.getSenderID());
				
				//fire listeners
				while(i.hasNext()){
					((GTSessionListener)i.next()).personLeft(pe);
				}
			} else if(t.getMessageName().equals("GT_MODIFY_LOGIN")) {
				Iterator i = sessionListeners.iterator();
				
				//lazily create event
				if(pe == null) pe = new GTPersonEvent(); 
				
				//populate from data
				Object[] data = (Object[])t.getData();
				pe.setPerson((Person)data[0]);
				pe.setPID((String)data[1]);
					
				//modify known People
				knownPeople.remove(t.getSenderID());
				knownPeople.put(t.getSenderID(), pe.getPerson());
				
				Messenger.getInstance().message("ModifyLogin received: " + pe.getPerson().getShortID());
				
				//fire listeners
				while(i.hasNext()){
					((GTSessionListener)i.next()).personChanged(pe);
				} 
			} else if (t.getMessageName().equals("GT_LOGIN_RESPONSE")) {
				Object[] data = (Object[])t.getData();
				Short s = (Short)data[0];
				Messenger.getInstance().message("Response received Number = " + String.valueOf(s));
				clientNumber = s.shortValue();
				if(clientNumber == (short)-1) {
					Messenger.getInstance().error("Server refused login" + String.valueOf(clientNumber) ,this);
					System.exit(1);
				}
				Person me = getMe();
				me.shortID = clientNumber;
				setPerson(me);
				getTelepointerController();
				pingManager.start();
				adaptiveHPTControl.start();
			}
			Iterator i = (knownPeople.values().iterator());
			while(i.hasNext()) {
				System.out.println(((Person)i.next()).getName());
			}
		}
  }

  
  private class ControllerNetworkListener implements GTNetworkListener {

		/* (non-Javadoc)
		 * @see ca.usask.hci.network.GTNetworkListener#objectReceived(ca.usask.hci.network.GTNetworkEvent)
		 */
		public void objectReceived(GTNetworkEvent e) {
			GTEvent ev = null;
			try {
				ev = (GTEvent)e.getData();
			} catch (Exception ex) {
				Messenger.getInstance().error(ex.getClass().toString());
				Messenger.getInstance().error("Error casting to GTEvent " +e.getData().getClass().toString(), this);
			}
			if(ev!=null)
				dispatchEvent(ev);
			
		}

		/* (non-Javadoc)
		 * @see ca.usask.hci.network.GTNetworkListener#networkConnected(ca.usask.hci.network.GTNetworkEvent)
		 */
		public void networkConnected(GTNetworkEvent e) {
			// TODO Auto-generated method stub
			
		}

		/* (non-Javadoc)
		 * @see ca.usask.hci.network.GTNetworkListener#networkDisconnected(ca.usask.hci.network.GTNetworkEvent)
		 */
		public void networkDisconnected(GTNetworkEvent e) {
			// TODO Auto-generated method stub
			
		}

		/* (non-Javadoc)
		 * @see ca.usask.hci.network.GTNetworkListener#objectSent(ca.usask.hci.network.GTNetworkEvent)
		 */
		public void objectSent(GTNetworkEvent e) {
			// TODO Auto-generated method stub
			
		}
  	
  }

	/**
	 * @return the unique ID representing this GTController.
	 */
	public String getMyID() {
		while(myID == null) {
			myID = network.getLocalAddress().toString() + ":" + network.getLocalTCPPort() + ":";
		}
		return myID;
	}

	/**
	 * @return the instance of the GTNetwork layer
	 */
	public GTNetwork getNetwork() {
		return network;
	}
	/**
	 * part of the HPT
	 * 
	 * @param	shortID	the shortID for a client as assigned by the Server
	 * @return the unique string id for a client 
	 */
	public String getClientIdFromShortID(short shortID) {
		Person[] list = getPeople();
		String out = null;
		if(shortID == clientNumber) return me.getClientID();
		for(int i = 0;i<list.length;i++) {
			if(list[i].getShortID() == shortID) {
				//
				out = list[i].getClientID();
				break;
			}
		}	
		//System.err.println("Returned shortIDToClientID "+ out);
		return out;
	}
	/**
	 *
	 * 
	 * @return the instance of GTPingManager  
	 */
	public GTPingManager getPingManager() {
		// TODO Auto-generated method stub
		return pingManager;
	}

}
