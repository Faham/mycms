/*
 * Created on Jan 12, 2004
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package ca.usask.hci.gt.telepointers;

import java.io.IOException;

import ca.usask.hci.gt.GTController;

/**
 * @author Chris Fedak
 *
 */
public class TCPTelepointerSender implements GTTelepointerSender {

	/**
	 * 
	 */
	public TCPTelepointerSender() {
		super();
		// TODO Auto-generated constructor stub
	}

	/* (non-Javadoc)
	 * @see ca.usask.hci.gt.telepointers.GTTelepointerSender#send(ca.usask.hci.gt.telepointers.GTTelepointerEvent)
	 */
	public void send(GTTelepointerEvent e) throws IOException {
		// TODO Auto-generated method stub
		GTController.getInstance().sendToOthers(e, e.getChannel());
	}

}
