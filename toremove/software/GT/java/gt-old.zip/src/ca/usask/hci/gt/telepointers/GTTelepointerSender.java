/*
 * Created on Dec 13, 2003
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package ca.usask.hci.gt.telepointers;

import java.io.IOException;

/**
 * @author Chris Fedak
 *
 */
public interface GTTelepointerSender {
	public void send(GTTelepointerEvent e) throws IOException;
}
