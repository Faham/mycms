/*
 * Created on Nov 19, 2003
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package ca.usask.hci.utils;

import javax.swing.event.EventListenerList;

/**
 * Singleton class used to communicate status messages anywhere in 
 * an application.  Publishes messageSent(MessageEvent) and errorSent(MessageEvent) 
 * messages to any  class that subscribes.  Any class may send a message using the singleton;
 * if there are no listeners, messages are sent to stdout and sterr as applicable.
 * 
 * @author Chris Fedak
 *
 */
public class Messenger {
	static Messenger messenger = new Messenger();
	EventListenerList listeners;
	MessageEvent event;
	/**
	 * 
	 */
	public Messenger() {
		super();
		listeners = new EventListenerList();
		// TODO Auto-generated constructor stub
	}
	
	public static Messenger getInstance() {
		return messenger;
	}
	
	public void addMessageListener(MessageListener ml) {
		listeners.add(MessageListener.class, ml);
	}
	
	public void removeMessageListener(MessageListener ml) {
		listeners.remove(MessageListener.class, ml);
	}
	
	public void message(String message, Object sender) {
		Object[] list = listeners.getListenerList();

		//create event
		event = new MessageEvent(message, sender, false); 

		if(list.length <1)
			System.out.println(sender.getClass().toString()+ ":"+ message);		
		
		//fire listeners
		for(int i= list.length -2 ; i>=0 ; i-=2){ 
			if(list[i] == MessageListener.class) {
				((MessageListener)list[i+1]).messageSent(event);
			}
		}
		
	}
	
	public void message(String message) {
			Object[] list = listeners.getListenerList();

			//create event
			event = new MessageEvent(message, this, false); 

			if(list.length <1)
				System.out.println(message);		
		
			//fire listeners
			for(int i= list.length -2 ; i>=0 ; i-=2){ 
				if(list[i] == MessageListener.class) {
					((MessageListener)list[i+1]).messageSent(event);
				}
			}
		
		}
	
	public void error(String error, Object sender) {
		Object[] list = listeners.getListenerList();

		// create event
		event = new MessageEvent(error, sender, true);		 

		if(list.length <1)
			System.err.println(sender.getClass().toString()+ ":"+ error);
			
		//fire listeners
		for(int i= 0; i< list.length; i++){ 
			if(list[i] == MessageListener.class) {
				//Messenger.getInstance().message("relaying to "+ list[i+1].getClass().toString(), this);	
				((MessageListener)list[i+1]).messageSent(event);
			}
		}
	}
	
	public void error(String error) {
		Object[] list = listeners.getListenerList();

		// create event
		event = new MessageEvent(error, this, true);		 

		if(list.length <1)
			System.err.println(error);
			
		//fire listeners
		for(int i= 0; i< list.length; i++){ 
			if(list[i] == MessageListener.class) {
				//Messenger.getInstance().message("relaying to "+ list[i+1].getClass().toString(), this);	
				((MessageListener)list[i+1]).messageSent(event);
			}
		}
	}
	
	
	
}
