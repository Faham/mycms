/*
 * Created on Oct 22, 2003
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package ca.usask.hci.gt.gui;

import java.awt.Color;
import java.awt.Component;
import java.awt.Graphics;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JColorChooser;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JTextField;
import javax.swing.ListCellRenderer;

import ca.usask.hci.gt.preferences.GTPreferenceManager;

/**
 * @author Chris Fedak
 *
 * To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
public class GTLogin extends JDialog {
	Color color;
	String nameOut;
	private GTPreferenceManager prefManager;
	

	/**
	 * @throws java.awt.HeadlessException
	 */
	public GTLogin() throws HeadlessException {
		super();
		setModal(true);
		prefManager = GTPreferenceManager.getInstance();
		color = new Color((int)(Math.random()*255),(int)(Math.random()*255),(int)(Math.random()*255));
		buildUI();
	}
	
	public void buildUI() {
		JLabel request;
		JLabel name;
		JLabel colorLabel;
		final JButton loginButton;
		final JTextField nameField;
//		final JComboBox colorList;
		final JButton colorList;
		
		request = new JLabel("Please login:"); 
		name = new JLabel("Name:");
		colorLabel = new JLabel("Color:");
		

		nameField = new JTextField();
		if(prefManager.getPreference("username").equals("NO_SUCH_PREF")) {
			nameField.setText("Default"+(int)(Math.random()*9999));
		} else {
			nameField.setText(prefManager.getPreference("username"));
		}
		
		loginButton = new JButton("Login");
		loginButton.addActionListener( new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				nameOut = nameField.getText();
				dispose();
			}
		});
		
		
			
/*		Color[] colors = new Color[] {Color.red, Color.blue, Color.green, Color.orange, Color.black};
		colorList = new JComboBox(colors);
		colorList.setEditable(false);
		colorList.setRenderer(new ColorRenderer());
		colorList.setSelectedIndex(1);
		colorList.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				color = (Color)colorList.getSelectedItem();
			}
		}); */
		
		final Component dialogParent = this;
		
		colorList = new JButton("Choose Color...");
		colorList.addActionListener( new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Color newColor = JColorChooser.showDialog(dialogParent, "Choose a Color", color);
				if(newColor!=null) {
					color = newColor;
					colorList.setForeground(color);
				}
			}
		});
		
		//if(prefManager.getPreference("userforegroundcolour").equals("NO_SUCH_PREF")) {
		
		colorList.setForeground(color);

		
		
		getContentPane().setLayout(new GridBagLayout());
		GridBagConstraints gbc = new GridBagConstraints();

		// constraints for request
		gbc.gridx = 0;
		gbc.gridy = 0;
		gbc.gridwidth = 2;
		gbc.anchor = GridBagConstraints.WEST;
		gbc.fill = GridBagConstraints.HORIZONTAL;
		getContentPane().add(request, gbc);

		// constraints for name
		gbc.gridy = 1;
		gbc.gridwidth = 1;
		gbc.anchor = GridBagConstraints.EAST;
		gbc.fill = GridBagConstraints.NONE;
		getContentPane().add(name, gbc);

		// constraints for nameField
		gbc.gridx = 1;
		gbc.anchor = GridBagConstraints.WEST;
		gbc.fill = GridBagConstraints.HORIZONTAL;
		getContentPane().add(nameField, gbc);

		// constraints for colorLabel
		gbc.gridx = 0;
		gbc.gridy = 2;
		gbc.anchor = GridBagConstraints.EAST;
		gbc.fill = GridBagConstraints.NONE;
		getContentPane().add(colorLabel, gbc);

		// constraints for colorList
		gbc.gridx = 1;
		gbc.anchor = GridBagConstraints.WEST;
		gbc.fill = GridBagConstraints.HORIZONTAL;
		getContentPane().add(colorList, gbc);
		
		// constraints for loginButton
		gbc.gridx = 0;
		gbc.gridy = 3;
		gbc.gridwidth = 2;
		gbc.anchor = GridBagConstraints.EAST;
		gbc.fill = GridBagConstraints.NONE;
		getContentPane().add(loginButton, gbc);
		
		pack();
	}
	class ColorRenderer extends JLabel implements ListCellRenderer{
			
		public ColorRenderer() {
			super();
		}
		
		public Component getListCellRendererComponent(
			JList list,
			Object value,
			int index,
			boolean isSelected,
			boolean cellHasFocus) {
				setText(((Color)value).toString());
				setBackground((Color)value);
				setForeground((Color)value);
				return this;
		}
		
		public void paintComponent(Graphics g) {
			super.paintComponent(g);	
			g.setColor(this.getBackground());
			g.fillRect(0,0,getWidth(), getHeight());
		} 
	}
	/**
	 * @return Color chosen by the user logging in
	 */
	public Color getColor() {
		return color;
	}

	/**
	 * @return name chosen by the user
	 */
	public String getName() {
		return nameOut;
	}

}
