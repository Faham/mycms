/*
 * Created on Jan 21, 2004
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package ca.usask.hci.gt.telepointers;

import java.awt.Point;

/**
 * @author Chris Fedak
 *
 */
public interface GTTelepointerPredictor {
	public PredictedPoint predict(ClientTelepointerHistory cth, long time);
	/**
	 * must return a value corresponding to how far in the future (or the past) this
	 * predictor returns values for, independant of network latency.
	 * @author Chris Fedak
	 *
	 */
	public int latencyAdjustment();
	
	/**
	 * if predictor uses a kalman filter to reduce noise, do that here, otherwise implement a null method.
	 * 
	 * @param p
	 */
	public void correct(Point p);
}
