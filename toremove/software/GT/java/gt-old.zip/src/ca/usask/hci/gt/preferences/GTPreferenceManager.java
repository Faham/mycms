/*
 * Created on Feb 2, 2004
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package ca.usask.hci.gt.preferences;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.FactoryConfigurationError;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.xml.serialize.OutputFormat;
import org.apache.xml.serialize.XMLSerializer;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;


/**
 * Manages permanent preference information for a local client as
 * an XML file named .gtpreferences in a users home directory.
 * 
 * NOTE: uses the org.apache.xml.serialize pacakge for output and JAXP for parsing.
 * 
 * @author Chris Fedak
 *
 */
public class GTPreferenceManager {
	Map gtPrefs;
	List servers;
	List ypServers;
	
	static GTPreferenceManager instance = new GTPreferenceManager();
	
	Document preferenceDocument;
	static final String[] typeName = {
					"none",
					"Element",
					"Attr",
					"Text",
					"CDATA",
					"EntityRef",
					"Entity",
					"ProcInstr",
					"Comment",
					"Document",
					"DocType",
					"DocFragment",
					"Notation",
			};	
	/**
	 * 
	 */
	private GTPreferenceManager() {
		super();
		gtPrefs = new HashMap();
		servers = new LinkedList();
		ypServers = new LinkedList();
		readPreferenceFile();
	}
	
	public static GTPreferenceManager getInstance() {
		return instance;
	}

    private String getPrefsFileName() {
        return System.getProperty("user.home") + System.getProperty("file.separator") + ".gtpreferences";
    }
    
	public void readPreferenceFile() {
		//FileReader fr = null;
		//BufferedReader br;
		//String line, allLines;
		File prefsFile;

		//allLines = new String();
		prefsFile = new File(getPrefsFileName());
		System.out.println("looking for prefs file at: " + prefsFile.getPath());
		if(!prefsFile.exists()) {
			createNewPrefsFile(prefsFile);
		}
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		
		try {
			DocumentBuilder builder = factory.newDocumentBuilder();
			preferenceDocument = builder.parse( prefsFile );		
		} catch (SAXException sxe) {
			// Error generated during parsing
			Exception  x = sxe;
			if (sxe.getException() != null)
				x = sxe.getException();
				x.printStackTrace();
			} catch (ParserConfigurationException pce) {
			 // Parser with specified options can't be built
			 pce.printStackTrace();
			} catch (IOException ioe) {
			 // I/O error
			 ioe.printStackTrace();
			}
		//Element e = preferenceDocument.getDocumentElement();
		NodeList temp;// = e.getElementsByTagName("GTPreferences");
		temp = preferenceDocument.getElementsByTagName("GTPreferences");
		if(temp.getLength()<1)
			System.out.println("preferences empty");
		Node prefs = temp.item(0);
		
		temp = prefs.getChildNodes();
		
		Node check;
		for(int k = 0; k<temp.getLength();k++) {
			check = temp.item(k);
			switch(check.getNodeType()) {
				case 1://Element
					if(check.getNodeName().equals("servers")) {
						loadServers((Element)check);
					} else if(check.getNodeName().equals("servers")) {
						loadYpServers((Element)check);
					} else {
						addPrefFromElement((Element)check);
					}
					break;
				default://other
					//System.out.println(typeName[check.getNodeType()] + ":" +
						//check.getNodeName()+":"+check.getNodeValue());
			} 
		}
		
	}
	
	/**
	 * @param check
	 */
	private void loadYpServers(Element serverList) {
		NodeList all = serverList.getChildNodes();
		NodeList serverMember;
		Node check, serverText;
		String server;
		for(int k=0; k<all.getLength();k++) {
			server = null;
			check = all.item(k);
			switch (check.getNodeType()) {
				case 1: //Element
					if(check.getNodeName().equals("ypserver")) {
						serverMember = check.getChildNodes();
						for(int j =0;j<serverMember.getLength();j++) {
							serverText = serverMember.item(j);
							if(serverText.getNodeType() == 3) {
								server = serverText.getNodeValue();
							}
						}
					}
					break;
			}
			if(server!=null) {
				//if we found a server this iteration, add it
				ypServers.add(server);
			}
		}
	}

	/**
	 * @param check
	 */
	private void loadServers(Element serverList) {
		NodeList all = serverList.getChildNodes();
		NodeList serverMember;
		Node check, serverText;
		String server;
		for(int k=0; k<all.getLength();k++) {
			server = null;
			check = all.item(k);
			switch (check.getNodeType()) {
				case 1: //Element
					if(check.getNodeName().equals("server")) {
						serverMember = check.getChildNodes();
						for(int j =0;j<serverMember.getLength();j++) {
							serverText = serverMember.item(j);
							if(serverText.getNodeType() == 3) {
								server = serverText.getNodeValue();
							}
						}
					}
					break;
			}
			if(server!=null) {
				//if we found a server this iteration, add it
				servers.add(server);
			}
		}
	}

	/**
	 * @param prefsFile
	 */
	private void createNewPrefsFile(File prefsFile) {
		try {
			// TODO Auto-generated method stub
			preferenceDocument = DocumentBuilderFactory.newInstance().newDocumentBuilder().newDocument();
		} catch (ParserConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (FactoryConfigurationError e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Element e, f,g ;
		e = preferenceDocument.createElement("GTPreferences");
		preferenceDocument.appendChild(e);
		f = preferenceDocument.createElement("servers");
		e.appendChild(f);
		g = preferenceDocument.createElement("server");
		g.appendChild(preferenceDocument.createTextNode("localhost"));
		f.appendChild(g);
		
		f = preferenceDocument.createElement("ypservers");
		e.appendChild(f);
		g = preferenceDocument.createElement("ypserver");
		g.appendChild(preferenceDocument.createTextNode("localhost"));
		f.appendChild(g);
		
		writePreferenceFile(prefsFile);
	}

	private void addPrefFromElement(Element e) {
		String id = e.getNodeName();
		String value = null;
		
		NodeList contents = e.getChildNodes();
		Node check;
		for(int k = 0; k<contents.getLength();k++) {
			check = contents.item(k);
			switch(check.getNodeType()) {
				case 3://Text
					//System.out.println("Text: "+check.getNodeValue());
					value = check.getNodeValue();
					break;
				case 2://Attr
					//System.out.println("Attr: "+check.getNodeName()+ ":" +check.getNodeValue());
					break;
				default://other
					//System.out.println(typeName[check.getNodeType()] + ":" +
					//	check.getNodeName()+":"+check.getNodeValue());
			} 
		}
		
		if(value != null) {
			gtPrefs.put(id,value);
		}
	}
	
	public void writePreferenceFile() {
		File prefsFile = new File(getPrefsFileName());
		
		writePreferenceFile(prefsFile);
	}
	
	public void writePreferenceFile(File file) {
		PrintWriter out;
		try {
			out = new PrintWriter(new FileWriter(file));
			XMLSerializer output;
			OutputFormat format = new OutputFormat(preferenceDocument);
			output = new XMLSerializer(out,format);
			output.serialize(preferenceDocument);
			out.flush();
			out.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void setPreference(String prefID, String prefData) {
		Element prefs, newPref;
		NodeList allPrefs, contents;
		Node check;
		if( prefID != null && prefData != null) {
			gtPrefs.put(prefID, prefData);
			prefs = (Element) preferenceDocument.getElementsByTagName("GTPreferences").item(0);
			
			
			allPrefs = prefs.getElementsByTagName(prefID);
			//if the preference already exists in the Doc
			if(allPrefs.getLength()>0) {
				newPref = (Element)allPrefs.item(0);
				contents = newPref.getChildNodes();
				for(int k = 0; k<contents.getLength();k++) {
					//get the text node and change its value to current;
					check = contents.item(k);
					switch(check.getNodeType()) {
						case 3://Text
							//System.out.println("Text: "+check.getNodeValue());
							check.setNodeValue("prefData");
							break;
					}
				}
			} else {
				//add a new preference element with this id and data
				newPref = preferenceDocument.createElement(prefID);
				newPref.appendChild(preferenceDocument.createTextNode(prefData));
				prefs.appendChild(newPref);	
			}
		}
		writePreferenceFile();
	}
	
	public String getPreference(String prefID) {
		String prefData = null;
		if(prefID != null)
			prefData = (String)gtPrefs.get(prefID);
		if(prefData == null) {
			prefData = "NO_SUCH_PREF"; 
		}
		return prefData;
	}
	/**
	 * @return
	 */
	public List getServers() {
		List ret;
		ret = new LinkedList();
		ret.addAll(servers);
		return ret;
	}
	
	public synchronized void addServer(String host) {
		NodeList nl;
		Element e = null, 
						f, g;
		
		//already in set, return;
		if(servers.contains(host)) return;
						
		//step one, add to list if needed
		servers.add(host);
		
		//step two add to DOM if needed
		nl = preferenceDocument.getElementsByTagName("servers");
		if(nl.getLength() >0) {
			e = (Element)nl.item(0);
			f = preferenceDocument.createElement("server");
			f.appendChild(preferenceDocument.createTextNode(host));
			e.appendChild(f);
			writePreferenceFile();
		} else {
			System.err.println("Error adding server to preferences file: no such element in DOM");
		}
	}
	
	public synchronized void addYpServer(String host) {
		NodeList nl;
		Element e = null, 
						f;
		
		//already in set, return;
		if(ypServers.contains(host)) return;
						
		//step one, add to list if needed
		ypServers.add(host);
		
		//step two add to DOM if needed
		nl = preferenceDocument.getElementsByTagName("ypservers");
		if(nl.getLength() >0) {
			e = (Element)nl.item(0);
			f = preferenceDocument.createElement("ypserver");
			f.appendChild(preferenceDocument.createTextNode(host));
			e.appendChild(f);
			writePreferenceFile();
		} else {
			System.err.println("Error adding server to preferences file: no such element in DOM");
		}		
	}

	/**
	 * @return
	 */
	public List getYpServers() {
		List ret;
		ret = new LinkedList();
		ret.addAll(ypServers);
		return ret;
	}

}
