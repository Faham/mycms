/*
 * Created on Nov 19, 2003
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package ca.usask.hci.utils;

import java.util.EventObject;

/**
 * @author Chris Fedak
 *
 */
public class MessageEvent extends EventObject {
	String message;
	boolean error;
	/**
	 * @param arg0
	 */
	public MessageEvent(String message, Object arg0, boolean error) {
		super(arg0);
		// TODO Auto-generated constructor stub
		this.message = message;
		this.error = error;
	}

	/**
	 * @return
	 */
	public boolean isError() {
		return error;
	}

	/**
	 * @param error
	 */
	public void setError(boolean error) {
		this.error = error;
	}

	/**
	 * @return
	 */
	public String getMessage() {
		return message;
	}

	/**
	 * @param message
	 */
	public void setMessage(String message) {
		this.message = message;
	}

}
