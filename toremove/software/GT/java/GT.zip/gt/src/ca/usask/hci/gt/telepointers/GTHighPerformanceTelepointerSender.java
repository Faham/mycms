/*
 * Created on Dec 13, 2003
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package ca.usask.hci.gt.telepointers;

import java.awt.Point;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import javax.swing.JOptionPane;

import ca.usask.hci.gt.GTController;
import ca.usask.hci.utils.Messenger;

/**
 * @author Chris Fedak
 *
 */
public class GTHighPerformanceTelepointerSender
	implements GTTelepointerSender {
		int fecLevel = 0;
		boolean sendFull = true;
		short order = 0;
		private HPControlInfo hpci;
		DatagramSocket sock;
		static int bitsPerDiff = 8;
		static final boolean USE_MULTIPLEXING = false;
		static boolean pad;

	/**
	 * 
	 */
	public GTHighPerformanceTelepointerSender(HPControlInfo hpci, DatagramSocket sock) {
		this.hpci = hpci;
		this.sock = sock;
		if(sock == null) {
			System.out.println("Fatal error null datagram socket");
			System.exit(-1);
		}
		pad = false;
	}

	/** 
	 * @see ca.usask.hci.gt.telepointers.GTTelepointerSender#send()
	 */
	public synchronized void send(GTTelepointerEvent e) throws IOException {
		DatagramPacket packet = null;
		byte[] buf;
		//test array
		Point[] p;
		
		e.addOrderedPoint(new Point(e.getX(),e.getY()), order);
		List fecPoints = GTController.getInstance().getTelepointerController().getFecList(hpci.fec,
			GTController.getInstance().getMyID());
		p = new Point[fecPoints.size()+1];
		p[0] = new Point(e.getX(), e.getY());
		Iterator i;
		OrderedPoint o;
		i = fecPoints.iterator();
		for(int k = 1;i.hasNext();k++) {
			o = (OrderedPoint)i.next();
			e.addOrderedPoint(o);
			p[k] = new Point(o.getX(), o.getY());
			
		}
		
		int tries = 0;;
		
		byte[] bytes = null; 
		
		if(USE_MULTIPLEXING) 
			bytes = getTelepointerBytes(p, e.getIntermediatePoints());
		else
			bytes = getTelepointerBytes(p);
			
		while (bytes == null) {
			System.out.println("bytes == null; count is: " + tries);
			bytes = getTelepointerBytes(p);
			try {
				Thread.sleep(500);
			} catch (Exception te) {
				
			}
			tries++;
			if(tries >20) {
				JOptionPane.showMessageDialog(null, "Fatal Error", "Server failed to assign id please restart application", JOptionPane.ERROR_MESSAGE);
				System.exit(-1);
			}
		}
		
		// IS THE FOLLOWING NEEDED? SEEMS TO JUST SEND THE TELE BACK TO SELF
		// YES, keeping a local record is key to the HPT mechanism.
		GTController.getInstance().getTelepointerController().addHistoryPoint(new Point(e.getX(), e.getY()));
		
//	Messenger.getInstance().message("Sending packet via High Performance");
		
		if(bytes == null) {
			JOptionPane.showMessageDialog(null, "Fatal Error", "Server failed to assign id please restart application", JOptionPane.ERROR_MESSAGE);
			System.exit(-1);
			return;
		}
		
		try {
			packet = new DatagramPacket(bytes, bytes.length, 
				GTController.getInstance().getNetwork().getHostAddress(),
				4446);
			sock.send(packet);
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
			System.out.println("send issue:" + e1.getMessage());
			if(GTController.getInstance().getNetwork().getHostAddress() == null)
				System.out.println("one of GTNetwork/getHostAddress is null");
			if(GTController.getInstance().getNetwork() == null)
				System.out.println("GTNetwork is null");
			if(GTController.getInstance() == null) 
				System.out.println("GTController is null");
			if(packet == null)
				System.out.println("Packet is null");
			if(bytes == null)
				System.out.println("bytes are null");	

		}
		
	}
	
	private byte[] getTelepointerBytes(Point[] p, OrderedPoint[] inter) {
		byte[] buf = null,
		 			 nextPiece = null;
		int			startingBit;
		int 		feclevel;
		int			intermediates = inter.length;
		Point		reference;
		Sequence seq = null;
		short id = GTController.getInstance().getClientNumber();
		//Messenger.getInstance().message("Creating udp telepointer: "+ String.valueOf(p.length));
		
		//get the order for this sequence
		order = (short)GTController.getInstance().getTelepointerController().getNextTelepointerSequence();
		//order = 120;
		feclevel = p.length -1; 
		
		//id not yet obtained;
		if(id < 0 ) return null;
		ArrayList bytes = new ArrayList();
		//write first byte
		byte working = (byte)(id | order<<4);
		//byte temp;		byte temp2; 
		bytes.add(new Byte(working));
		working = (byte)((order>>4) & getMask(0,3));
		//
		working = (byte)(working | feclevel<<4);
		bytes.add(new Byte(working));
		working = (byte)((feclevel>>4) & getMask(0,3));
		
		//note number of intermediates
		working = (byte)(working | intermediates<<4);
		bytes.add(new Byte(working));
		working = (byte)(intermediates>>4 & getMask(0,3));
		
		//write remainder of sequence
		//bytes.add(new Byte(working));
		
		short x = (short)p[0].getX();
		short y = (short)p[0].getY();
		//start x
		working = (byte)(working | x<<4);
		bytes.add(new Byte(working));
		//finish x;
		working = (byte)((x>>4) & getMask(0,7));
		//working = (byte)(working & ~(15<<4));//clear last 4 bits;
		bytes.add(new Byte(working));
		//add first 8 bits of y
		working = (byte)(y);
		bytes.add(new Byte(working));
		//finish y
		working = (byte)((y>>8)& getMask(0,3));
		
		startingBit = 4;
		//bytes.add(new Byte(working));
		
		reference = p[0];
		
		//now add intermediates, using p[0] as the reference point
		for(int i = 0; i<intermediates;i++) {
			seq = null;
			if(i==0) {
				seq = getDifferenceSequence(working, startingBit, 
					(byte)(inter[i].x-reference.x),(byte)(inter[i].y-reference.y));  
			} else {
				seq = getDifferenceSequence(working, startingBit, 
					(byte)(inter[i].x-inter[i-1].x),(byte)(inter[i].y-inter[i-1].y));
			}
			nextPiece = seq.data;
			
			for(int j = 0;j<nextPiece.length-1;j++) {
				bytes.add(new Byte(nextPiece[j]));
			}
			working = nextPiece[nextPiece.length-1];
			startingBit = seq.startingBit;
		}
		
		//now add fec parts
		for(int i = 1; i<p.length;i++) {
		//Messenger.getInstance().message("dX[" + String.valueOf(i) + "] = " + String.valueOf(p[i].x-p[i-1].x));
		//Messenger.getInstance().message("dY[" + String.valueOf(i) + "] = " + String.valueOf(p[i].y-p[i-1].y));
		
		seq = getDifferenceSequence(working, startingBit, (byte)(p[i].x-p[i-1].x), (byte)(p[i].y - p[i-1].y));
		nextPiece = seq.data;
		
		for(int j = 0;j<nextPiece.length-1;j++) {
			bytes.add(new Byte(nextPiece[j]));
		}
		working = nextPiece[nextPiece.length-1];
		startingBit = seq.startingBit;
		//System.out.println("Exit starting value " + String.valueOf(startingBit));
		}	
		
		//add last partial to array
		if(startingBit != 0) {
		bytes.add(new Byte(working));
		}
		
		if(pad == true) {
			for(int i = 0; i<200;i++) {
				bytes.add(new Byte((byte)0));
			}
		}
		
		//dump bytes to buf;
		buf = new byte[bytes.size()];
		for(int i = 0; i<bytes.size();i++) {
			buf[i] = ((Byte)bytes.get(i)).byteValue();
		}		
		
		//increment order
		//order++;
		//if(order > 127) {
		//	order = 0;
		//}
		
		return buf;
	}
	
	private byte[] getTelepointerBytes(Point[] p) {
		byte[] buf = null,
					 nextPiece = null;
		int			startingBit;
		int 		feclevel;
		Point		reference;
		Sequence seq = null;
		short id = GTController.getInstance().getClientNumber();
//		Messenger.getInstance().message("Creating udp telepointer: "+ String.valueOf(p.length));

		//get the order for this sequence
		order = (short)GTController.getInstance().getTelepointerController().getNextTelepointerSequence();
		//order = 120;
		feclevel = p.length -1; 

		//id not yet obtained;
		if(id < 0 ) return null;
		ArrayList bytes = new ArrayList();
		//write first byte
		byte working = (byte)(id | order<<4);
		//byte temp;		byte temp2; 
		bytes.add(new Byte(working));
		working = (byte)((order>>4) & getMask(0,3));
		//
		working = (byte)(working | feclevel<<4);
		bytes.add(new Byte(working));
		working = (byte)((feclevel>>4) & getMask(0,3));
		

		//write remainder of sequence
		//bytes.add(new Byte(working));
		
		short x = (short)p[0].getX();
		short y = (short)p[0].getY();
		//start x
		working = (byte)(working | x<<4);
		bytes.add(new Byte(working));
		//finish x;
		working = (byte)((x>>4) & getMask(0,7));
		//working = (byte)(working & ~(15<<4));//clear last 4 bits;
		bytes.add(new Byte(working));
		//add first 8 bits of y
		working = (byte)(y);
		bytes.add(new Byte(working));
		//finish y
		working = (byte)((y>>8)& getMask(0,3));
		
		startingBit = 4;
		//bytes.add(new Byte(working));
	
		reference = p[0];
	
		//now add fec parts
		for(int i = 1; i<p.length;i++) {
			//Messenger.getInstance().message("dX[" + String.valueOf(i) + "] = " + String.valueOf(p[i].x-p[i-1].x));
			//Messenger.getInstance().message("dY[" + String.valueOf(i) + "] = " + String.valueOf(p[i].y-p[i-1].y));

			seq = getDifferenceSequence(working, startingBit, (byte)(p[i].x-p[i-1].x), (byte)(p[i].y - p[i-1].y));
			nextPiece = seq.data;
			
			for(int j = 0;j<nextPiece.length-1;j++) {
				bytes.add(new Byte(nextPiece[j]));
			}
			working = nextPiece[nextPiece.length-1];
			startingBit = seq.startingBit;
			//System.out.println("Exit starting value " + String.valueOf(startingBit));
		}	
		
		//add last partial to array
		if(startingBit != 0) {
			bytes.add(new Byte(working));
		}
		
		
		//dump bytes to buf;
		buf = new byte[bytes.size()];
		for(int i = 0; i<bytes.size();i++) {
				buf[i] = ((Byte)bytes.get(i)).byteValue();
		}		
		
		//increment order
		//order++;
		//if(order > 127) {
		//	order = 0;
		//}
		
		return buf;
	}
	
	private Sequence getDifferenceSequence(byte remainder, int startingBit, byte dX, byte dY) {
		// returns the byte sent in, plus the next sequence of bytes.  next Startingpos indicates 
		// the first bit available in the last byte returned.
		Sequence seq  = null;
		byte[] sequence = null;
		int used = 0; //how many bytes are used
		int nextBit = startingBit;
		int shift;
		int bitsLeftInValue = bitsPerDiff;
		byte working;
		byte value = dX;
		byte[] workingSequence = new byte[10];
		working = remainder;
		
		//System.out.println("Write: " +  byteToBinaryString(dX));
		//System.out.println("Write: " +  byteToBinaryString(dY));
		
		
		//System.out.println(String.valueOf(startingBit) + " initialPos");
		
		shift = startingBit;
		startingBit = startingBit+bitsLeftInValue;
		
		//System.out.println(String.valueOf(startingBit) + " next");
		
		//write
		working = (byte)(working | value<<shift);
		bitsLeftInValue = bitsLeftInValue - (7-shift +1);
		if(bitsLeftInValue<0) bitsLeftInValue = 0;
		
		
		//System.out.println("dX value = " + byteToBinaryString(value));
		//System.out.println("working = " + byteToBinaryString(working));
		
		//if finished with this byte start a new one
		if(startingBit>7) {
			startingBit = 0;
			//System.out.println(String.valueOf(startingBit) + " set to 0");
			shift = startingBit;
			workingSequence[used] = working;
			working = 0;
			used++;
		}
		
		
		if(bitsLeftInValue <= 0) {
			// case 1 point was completely written
			bitsLeftInValue = bitsPerDiff;
		} else {
			// case 2 point was not completely written
			shift = startingBit;
			startingBit = startingBit+bitsLeftInValue;
			
			//System.out.println(String.valueOf(startingBit) + " next");
			int miniShift = bitsPerDiff-bitsLeftInValue;
			//System.out.println("value before right shift: " + byteToBinaryString(value));
			value = (byte)(value>>(bitsPerDiff-bitsLeftInValue));
			//System.out.println("value after right shift: " + byteToBinaryString(value));
			//ones are shifted on right, this 0's them.
			value = (byte)(value & getMask(0,7-(8-bitsLeftInValue)));
			//System.out.println("value after mask " + byteToBinaryString(value));
			//System.out.println("working before or with value: " + byteToBinaryString(working));
			working = (byte)(working | value<<shift);			
			bitsLeftInValue = bitsLeftInValue - (7-shift +1);
			if(bitsLeftInValue<0) bitsLeftInValue = 0;	
		}
		
		//	if finished with this byte start a new one
		if(startingBit>7) {
			startingBit = 0;
			//System.out.println(String.valueOf(startingBit) + " set to 0");
			workingSequence[used] = working;
			working = 0;
			used++;
		}
		
		//now dX has certainly been written, write dY
		value = dY;
		bitsLeftInValue = bitsPerDiff;
		
		//System.out.println("dY value = " + byteToBinaryString(value));
		//System.out.println("startBit = " + String.valueOf(startingBit));
		
		shift = startingBit;
		startingBit = startingBit+bitsLeftInValue;
		
//		System.out.println(String.valueOf(startingBit) + " next");
		
		working = (byte)(working | value<<shift);
		bitsLeftInValue = bitsLeftInValue - (7-shift +1);
		if(bitsLeftInValue<0) bitsLeftInValue = 0;
		
		//if finished with this byte start a new one
		if(startingBit>7) {
			startingBit = 0;
			//System.out.println(String.valueOf(startingBit) + " set to 0, left " + String.valueOf(bitsLeftInValue));
			shift = startingBit;
			workingSequence[used] = working;
			working = 0;
			used++;
		}
		
		// case 1 point was completely written
		if(bitsLeftInValue <= 0) {
			bitsLeftInValue = bitsPerDiff;
		} else {
			// case 2 point was not completely written
			shift = startingBit;
			startingBit = startingBit+bitsLeftInValue;
			//System.out.println(String.valueOf(startingBit) + " next");
			
			//System.out.println("value before right shift: " + byteToBinaryString(value));
			value = (byte)(value>>(bitsPerDiff-bitsLeftInValue));
			//		ones are shifted on right, this 0's them.
			value = (byte)(value & getMask(0,7-(bitsPerDiff-bitsLeftInValue)));
			//System.out.println("value after right shift: " + byteToBinaryString(value));
			//System.out.println("working before or with value: " + byteToBinaryString(working));
			working = (byte)(working | value<<shift);
			bitsLeftInValue = bitsLeftInValue - (7-shift +1);
			if(bitsLeftInValue<0) bitsLeftInValue = 0;		
		}
		
		//	if finished with this byte start a new one
		if(startingBit>7) {
			startingBit = 0;
			//System.out.println(String.valueOf(startingBit) + " set to 0");
			shift = startingBit;
			workingSequence[used] = working;
			working = 0;
			used++;
		} 
		
		//always add last byte even if empty to sequence
		workingSequence[used] = working;
		used++;
		
		//transfer working sequence returned sequence; 
		sequence = new byte[used];
		for(int i = 0; i<used;i++) {
			sequence[i] = workingSequence[i];
			//System.out.println("returned sequence " + String.valueOf(i) + " " + byteToBinaryString(sequence[i])); 
		}
		
		seq = new Sequence(startingBit, 0);
		seq.data = sequence;

		for(int k = 0; k < seq.data.length; k++) {
			//Messenger.getInstance().message("Wrote: " +  byteToBinaryString(seq.data[k]));
		}


		//System.out.println("Exit starting value " + String.valueOf(startingBit));
	
		return seq;		
	}
	
	private static String byteToBinaryString(byte b) {
		String s = new String();
		byte working = b;
		for(int i = 0;i<8;i++) {
			if( (working %2) !=0 ) { //if working is not odd there is a 1 in the first position
				s = s+"1";
			}  else {
				s = s+"0";
			}
			working = (byte)(working>>1);
		}
		return s;
	}
	
	public void setHighPerformanceControlObject(HPControlInfo hpci) {
		this.hpci = hpci;
	} 
	
	public void writeTelepointer() {
		byte[] buf = null;
		Point[] p = new Point[5];
		p[0] = new Point(128,50);
		p[1] = new Point(178,60);
		p[2] = new Point(138,98);
		p[3] = new Point(145,98);
		p[4] = new Point(118,112);
		
		while (buf == null) {
			buf = getTelepointerBytes(p);
			try {
				Thread.sleep(100);
			} catch (InterruptedException e) {

			}
		}
		//for(int i=0;i<buf.length;i++) {
		//	System.out.println("Byte: " + byteToBinaryString( buf[i]) );	
		//}
		try {
			unpack(buf);
		} catch (Exception e) {
			Messenger.getInstance().error("bad packet" + e.getMessage());
		}
	}
	
	public static GTTelepointerEvent unpack(byte[] packet) throws IOException {
		GTTelepointerEvent e = new GTTelepointerEvent();
		//timestamp information;
		long receiveTime = System.currentTimeMillis();
		long delay;// = GTController.getInstance().getTelepointerController().getBroadcastDelay();
		
		short id;
		short sequenceNumber;
		Sequence seq;
		int x1;
		int y1;
		short twelveBitMask = (short) (Math.pow(2,12) -1);
		short eightBitMask = (short) (Math.pow(2,8)-1);
		int fec;
		int dx1 = 0;
		int dy1 = 0;
		byte [][] pairs = new byte[2][2];
		List points = new LinkedList();
				
		int startingBit, endingBit, remaining;
		int startingByte;
		int shift;
		byte working, temp, 
			mask,
			lowMask = (byte)15,
			hiMask = (byte)240;
		int temp2;
		
		//first byte
		working = packet[0];
		mask = lowMask;
		temp = (byte)(working & mask);
		//System.out.println("mask 15 " + byteToBinaryString(mask));
		//System.out.println("temp " + byteToBinaryString(temp));
		
		id = temp;
		//if(id == GTController.getInstance().getClientNumber()) return new GTTelepointerEvent();
		
		mask = hiMask;
		temp = (byte)(working &mask);
		
		//write low order bits to sequence;
		sequenceNumber = (short)((temp>>4)&lowMask);
		
		//second byte
		working = packet[1];
		mask = lowMask;
		temp =	(byte)(working & mask);
		sequenceNumber = (short)(sequenceNumber | (temp<<4));
		//System.out.println("Decoded sequence"+byteToBinaryString((byte)sequenceNumber));
		
		mask = hiMask;
		temp = (byte) (working &mask);
		//first 4 bits of fecLevel;
		fec = (temp>>4)&lowMask;
		
		//third byte
		working = packet[2];
		mask = lowMask;
		temp = (byte)(working&mask);
		fec = (fec | temp<<4);
		
		//for(int n = 0; n<Math.min(6+fec*2, packet.length);n++) {	
		//	System.out.println("Byte: "+ byteToBinaryString(packet[n]));
		//}
		
		
		mask = hiMask;
		temp =	(byte)(working &mask);
		//first 4 bits of x1;
		x1 = (temp>>4)&lowMask;	
		
		//fourth byte
		working = packet[3];
		//x1 is a 12 bit int, finish it
		temp2 = working;
		x1 = x1 | (temp2<<4);
		//System.out.println("x1 part2: "+ byteToBinaryString(working));
		
		//fifith byte
		working = packet[4];
		//first 8 bits of y1 (12 total)
		y1 = working&eightBitMask;
		
		//System.out.println("y part1: "+ byteToBinaryString(working)+" "+String.valueOf(y1));
		
		//sixth byte
		working = packet[5];
		mask = getMask(0,3);
		temp2 = (working&mask);
		//y1 is twelve bits, finish it
		y1 = (y1 | (temp2<<8))&twelveBitMask;
		
		//System.out.println("y part2: "+ byteToBinaryString((byte) (working&mask)));
		
		startingBit = 4;
		startingByte = 5;
		
		points.add(new Point(x1,y1));
		
		if(!pad) {
			
			//decode difference pairs
			while((seq = getDXPair(packet, startingBit, startingByte))!=null && points.size()<=fec+1) {
				startingBit = seq.startingBit;
				startingByte = seq.startingByte;
				points.add(new Point(seq.data[0], seq.data[1]));
			}
			
			//System.err.println(String.valueOf(points.size()));
		}
		Iterator iter;
		Point lastPoint;
		Point point;
		OrderedPoint op;
		
		e.fec = fec;
		e.setSenderID(GTController.getInstance().getClientIdFromShortID(id));
		if(e.getSenderID() == null) {
			throw new IOException("bad or unrecognized shortID "+ String.valueOf(id)+ " " +
				GTController.getInstance().getClientIdFromShortID(id));
		}
		
		ClientTelepointerHistory cth;
		cth = GTController.getInstance().getTelepointerController().getClientTelepointerHistory(e.getSenderID());
		delay = 50;
		if(cth != null) {
			delay = cth.getEstimatedReceivePeriod();
		}
		
		iter = points.iterator();
		lastPoint = (Point)iter.next();
		int currentSequence = sequenceNumber;
		op = new OrderedPoint(lastPoint,currentSequence);
		op.setTimestamp(receiveTime);
		//process the points into absolute values
		e.addOrderedPoint(op);
		while(iter.hasNext()) {
			point = (Point)iter.next();
			point.x = lastPoint.x +point.x;
			point.y=  lastPoint.y+point.y;
			lastPoint = point;
			currentSequence--;
			receiveTime-= delay;
			if(currentSequence<0) currentSequence = 128+currentSequence;
			op = new OrderedPoint(lastPoint,currentSequence);
			op.setTimestamp(receiveTime);
			e.addOrderedPoint(op);
		}		
		

		//System.err.println("returning unpacked packet from" + e.getSenderID());
		return e;
	}

	public static GTTelepointerEvent unpackWithIntermediates(byte[] packet) throws IOException {
		GTTelepointerEvent e = new GTTelepointerEvent();
		//timestamp information;
		long receiveTime = System.currentTimeMillis();
		long interTime = System.currentTimeMillis();
		long delay;
		short intermediates;
		short id;
		short sequenceNumber;
		Sequence seq;
		int x1;
		int y1;
		short twelveBitMask = (short) (Math.pow(2,12) -1);
		short eightBitMask = (short) (Math.pow(2,8)-1);
		int fec;
		int dx1 = 0;
		int dy1 = 0;
		byte [][] pairs = new byte[2][2];
		List points = new LinkedList();
		List inters = new LinkedList();
				
		int startingBit, endingBit, remaining;
		int startingByte;
		int shift;
		byte working, temp, 
			mask,
			lowMask = (byte)15,
			hiMask = (byte)240;
		int temp2;
		
		//first byte
		working = packet[0];
		mask = lowMask;
		temp = (byte)(working & mask);
		//System.out.println("mask 15 " + byteToBinaryString(mask));
		//System.out.println("temp " + byteToBinaryString(temp));
		
		id = temp;
		//if(id == GTController.getInstance().getClientNumber()) return new GTTelepointerEvent();
		
		mask = hiMask;
		temp = (byte)(working &mask);
		
		//write low order bits to sequence;
		sequenceNumber = (short)((temp>>4)&lowMask);
		
		//second byte
		working = packet[1];
		mask = lowMask;
		temp =	(byte)(working & mask);
		sequenceNumber = (short)(sequenceNumber | (temp<<4));
		//System.out.println("Decoded sequence"+byteToBinaryString((byte)sequenceNumber));
		
		mask = hiMask;
		temp = (byte) (working &mask);
		//first 4 bits of fecLevel;
		fec = (temp>>4)&lowMask;
		
		//third byte
		working = packet[2];
		mask = lowMask;
		temp = (byte)(working&mask);
		fec = (fec | temp<<4);
		
		//for(int n = 0; n<Math.min(6+fec*2, packet.length);n++) {	
		//	System.out.println("Byte: "+ byteToBinaryString(packet[n]));
		//}
		
		mask = hiMask;
		temp = (byte)(working &mask);
		//first four bits of intermediates;
		intermediates = (short) ((temp>>4) & lowMask);
		
		//fourth byte
		working = packet[3];
		mask = lowMask;
		temp = (byte)(working&mask);
		intermediates = (short)(intermediates | temp<<4);
		
		mask = hiMask;
		temp =	(byte)(working &mask);
		//first 4 bits of x1;
		x1 = (temp>>4)&lowMask;	
		
		//fifth byte
		working = packet[4];
		//x1 is a 12 bit int, finish it
		temp2 = working;
		x1 = x1 | (temp2<<4);
		//System.out.println("x1 part2: "+ byteToBinaryString(working));
		
		//sixth byte
		working = packet[5];
		//first 8 bits of y1 (12 total)
		y1 = working&eightBitMask;
		
		//System.out.println("y part1: "+ byteToBinaryString(working)+" "+String.valueOf(y1));
		
		//7th byte
		working = packet[6];
		mask = getMask(0,3);
		temp2 = (working&mask);
		//y1 is twelve bits, finish it
		y1 = (y1 | (temp2<<8))&twelveBitMask;
		
		//System.out.println("y part2: "+ byteToBinaryString((byte) (working&mask)));
		
		startingBit = 4;
		startingByte = 6;
		
		points.add(new Point(x1,y1));
		
		//decode difference pairs for intermed points
		while((seq = getDXPair(packet, startingBit, startingByte))!=null && inters.size()<=intermediates) {
			startingBit = seq.startingBit;
			startingByte = seq.startingByte;
			inters.add(new Point(seq.data[0], seq.data[1]));
		}
		
		//decode difference pairs for fec points
		while((seq = getDXPair(packet, startingBit, startingByte))!=null && points.size()<=fec+1) {
			startingBit = seq.startingBit;
			startingByte = seq.startingByte;
			points.add(new Point(seq.data[0], seq.data[1]));
		}
		
		//System.err.println(String.valueOf(points.size()));
		
		Iterator iter;
		Point lastPoint;
		Point point;
		OrderedPoint op;
		
		e.fec = fec;
		e.setSenderID(GTController.getInstance().getClientIdFromShortID(id));
		if(e.getSenderID() == null) {
			throw new IOException("bad or unrecognized shortID "+ String.valueOf(id)+ " " +
				GTController.getInstance().getClientIdFromShortID(id));
		}
		
		ClientTelepointerHistory cth;
		cth = GTController.getInstance().getTelepointerController().getClientTelepointerHistory(e.getSenderID());
		delay = 50;
		if(cth != null) {
			delay = cth.getEstimatedReceivePeriod();
		}
		
		iter = points.iterator();
		lastPoint = (Point)iter.next();
		int currentSequence = sequenceNumber;
		op = new OrderedPoint(lastPoint,currentSequence);
		op.setTimestamp(receiveTime);
		//process the points into absolute values
		e.addOrderedPoint(op);
		while(iter.hasNext()) {
			point = (Point)iter.next();
			point.x = lastPoint.x +point.x;
			point.y=  lastPoint.y+point.y;
			lastPoint = point;
			currentSequence--;
			receiveTime-= delay;
			if(currentSequence<0) currentSequence = 128+currentSequence;
			op = new OrderedPoint(lastPoint,currentSequence);
			op.setTimestamp(receiveTime);
			e.addOrderedPoint(op);
		}		
		
		iter = inters.iterator();
		lastPoint = (Point)points.get(0);
		while(iter.hasNext()) {
			point = (Point)iter.next();
			point.x += lastPoint.x;
			point.y += lastPoint.y;
			lastPoint = point;
			currentSequence = sequenceNumber;
			interTime -= delay/intermediates;
			op = new OrderedPoint(lastPoint,currentSequence);
			op.setTimestamp(interTime);
			e.addIntermediatePoint(op);
		}

		//System.err.println("returning unpacked packet from" + e.getSenderID());
		return e;
	}
	
	//data must be 3 bytes that two 5 bit signed ints will be extracted from
	//startingBit is the first bit that will be used in the first byte
	//returns byte[]  first byte is dX, second is dY
	//nextStartingBit is returned as the next bit to use in the nextStartingByte
	
	private static Sequence getDXPair(byte[] data, int startingBit, int startingByte) {
		byte[] pair = new byte[2];
		Sequence val = null;
		byte working;
		byte temp;
		byte mask;
		int start;
		int end;
		int remaining;
		int shift;
		int currentByte = startingByte;
		
		if(startingByte >= data.length) return null;
		working = data[startingByte];
		
		//System.out.println("first byte used: " + byteToBinaryString(working) + " Start: " + String.valueOf(startingBit));;
		
		//get dX
		remaining = bitsPerDiff;
		start = startingBit;
		//System.out.println(String.valueOf(start) + " initialPos");
		end = startingBit +(remaining-1);
		shift = start;
		if(end >7) end = 7;
		mask = getMask(start,end);
		temp = (byte)(mask & working);
		pair[0] = (byte)(temp>>shift);
		//	clear top bits (might be ones)
		pair[0] = (byte)(pair[0] & getMask(0, 7-shift));
		
		//System.out.println("initial pair[0]: " + byteToBinaryString(pair[0]));
		
		remaining = bitsPerDiff - (end-start+1);
		
		//System.out.println("remaining " + String.valueOf(remaining));
		
		//get the next Byte if neccessary
		if(end >= 7) { 
			currentByte++; 
			if(currentByte >= data.length) return null;
			working = data[currentByte];
			start = 0;
			//System.out.println(String.valueOf(start) + " nextA");
			shift = 0;
			//System.out.println("next byte used: " + byteToBinaryString(working) + " Start: " + String.valueOf(start));
		} else {
			start = end+1;
			shift = start;
			//System.out.println(String.valueOf(start) + " nextAA");
		}
		
		if(remaining !=0) {
			//finish x;
			end = start+remaining-1;
			mask = getMask(start,end);
			temp = (byte)(working & mask);
			temp = (byte)(temp>>shift);
			pair[0] = (byte)(pair[0] | temp<<(bitsPerDiff-remaining));
			//		clear top bits (might be ones)
			pair[0] = (byte)(pair[0] & getMask(0, 7-shift));
			
			
		}
		
		pair[0] = convertToSigned(pair[0]);
		
		//System.out.println("finished pair[0]: " + byteToBinaryString(pair[0]));
		
		//get the next Byte if neccessary
		if(end >= 7) { 
			currentByte++; 
			if(currentByte >= data.length) return null;
			working = data[currentByte];
			start = 0;
			shift = 0;
			//System.out.println(String.valueOf(start) + " nextB");
			//System.out.println("next byte used: " + byteToBinaryString(working) + " Start: " + String.valueOf(start));
		} else {
			start = end+1;
			shift = start;
			//System.out.println(String.valueOf(start) + " nextBB");
		}
		
		remaining = bitsPerDiff;
		//get y
		end = start +(remaining-1);
		shift = start;
		//System.out.println("dyStart " + String.valueOf(start));
		if(end >7) end = 7;
		mask = getMask(start,end);
		temp = (byte)(mask & working);
		//System.out.println("temp: " + byteToBinaryString(temp));
		
		pair[1] = (byte)(temp>>shift);
		//System.out.println("pair[1] step 1: " + byteToBinaryString(pair[1]));
		//clear top bits (might be ones)
		pair[1] = (byte)(pair[1] & getMask(0, 7-shift));
	
		//System.out.println("initial pair[1]: " + byteToBinaryString(pair[1]));
		
		remaining = bitsPerDiff - (end-start+1);
		
		//System.out.println("remaining " + String.valueOf(remaining));
	
		//get the next Byte if neccessary
		if(end >= 7) { 
			currentByte++; 
			if(currentByte >= data.length) return null;
			working = data[currentByte];
			start = 0;
			shift = 0;
			//System.out.println(String.valueOf(start) + " nextC");
			//System.out.println("next byte used: " + byteToBinaryString(working) + " Start: " + String.valueOf(start));
		} else {
			start = end+1;
			shift = start;
			//System.out.println(String.valueOf(start) + " nextCC");
		}
	
		if(remaining !=0) {
			//finish y;
			end = start+remaining-1;
			mask = getMask(start,end);
			temp = (byte)(working & mask);
			temp = (byte)(temp>>shift);
			pair[1] = (byte)(pair[1] | temp<<(bitsPerDiff-remaining));
			//		clear top bits (might be ones)
			pair[1] = (byte)(pair[1] & getMask(0, 7-shift));
			
			if(end >= 7) { 
						currentByte++; 
						start = 0;
			} else {
					start = end+1;
			}
		
		}
		
		//System.out.println("finished pair[1]: " + byteToBinaryString(pair[1]));
		
		pair[1] = convertToSigned(pair[1]);
		
		
		
		val = new Sequence(start, currentByte);
		val.data = pair;
		
		//System.out.println(String.valueOf(start) + " last");

		//System.out.println("xdiff " + byteToBinaryString(pair[0]));
		//System.out.println("ydiff " + byteToBinaryString(pair[1]));		
	
		//System.out.println("Read: " +  byteToBinaryString(pair[0]));
		//System.out.println("Read: " +  byteToBinaryString(pair[1]));

		return val;	
	}
	
	/**
	 * @param b
	 * @return
	 */
	private static byte convertToSigned(byte b) {
		byte val = 0;
		byte mask =0;
		byte working;
		if(bitsPerDiff ==8) return b;
		//System.out.println("b:" + byteToBinaryString(b));
		
		//get the sign bit (located at bitsperdifference -1)
		mask = getMask(bitsPerDiff-1, bitsPerDiff-1);
		
		working = (byte)((b & mask)>>(bitsPerDiff-1));
		if(working ==1) {
			working = b;
			for(int j = bitsPerDiff;j<8;j++) {
				working = (byte)(working | ((byte)Math.pow(2,j)));
			}
			val = working;
		} else {
			val = b;
		}
		//System.out.println("final:" + byteToBinaryString(val));
		return val;
	}

	private static byte getMask(int startBit, int endBit) {
		byte val = 0;
		byte next;
		for(int i=startBit; i<=endBit;i++) {
			next = (byte)(int)(Math.pow(2,i));
			val = (byte)(next | val);
		}
		return val;
	}

	public static void main(String[] args) {
		try {
			new GTHighPerformanceTelepointerSender(new HPControlInfo(), new DatagramSocket()).writeTelepointer();
			System.exit(0);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
		/**
		 * @return Returns the pad.
		 */
		public boolean isPad() {
			return pad;
		}
		/**
		 * @param pad The pad to set.
		 */
		public void setPad(boolean pad) {
			this.pad = pad;
		}
}

class Sequence {
		public byte[] data;
		public int startingByte;
		public int startingBit;
		public Sequence(int startBit, int startByte) {
			startingBit = startBit;
			startingByte = startByte;
			data = null;
		}
	}
