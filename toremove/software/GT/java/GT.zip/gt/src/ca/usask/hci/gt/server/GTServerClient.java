/*
 * Created on Jan 7, 2004
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package ca.usask.hci.gt.server;

import java.awt.Color;

import ca.usask.hci.gt.Person;

/**
 * @author Chris Fedak
 *
 */
public class GTServerClient {
	private int udpPort;
	private String udpAddress;
	private GTServerWorker worker;
	private Person person;
	private String clientID;
	private short shortID;
	private int HPUdpPort = -1;
	

	/**
	 * 
	 */
	public GTServerClient() {
		super();
		shortID = -1;
		person = new Person("Default", Color.black);
		// TODO Auto-generated constructor stub
	}

	/**
	 * @return
	 */
	public Person getPerson() {
		return person;
	}

	/**
	 * @param person
	 */
	public void setPerson(Person person) {
		this.person = person;
		if(shortID >=0) {
			person.setShortID(this.shortID);
		}
	}

	/**
	 * @return
	 */
	public String getUdpAddress() {
		return udpAddress;
	}

	/**
	 * @param udpAddress
	 */
	public void setUdpAddress(String udpAddress) {
		this.udpAddress = udpAddress;
	}

	/**
	 * @return
	 */
	public int getUdpPort() {
		return udpPort;
	}

	/**
	 * @param udpPort
	 */
	public void setUdpPort(int udpPort) {
		this.udpPort = udpPort;
	}

	/**
	 * @return
	 */
	public GTServerWorker getWorker() {
		return worker;
	}

	/**
	 * @param worker
	 */
	public void setWorker(GTServerWorker worker) {
		this.worker = worker;
		setUdpAddress(worker.getRemoteAddress().getHostName());
	}

	/**
	 * @return
	 */
	public String getClientID() {
		return clientID;
	}

	/**
	 * @param clientID
	 */
	public void setClientID(String clientID) {
		this.clientID = clientID;
	}

	/**
	 * @return
	 */
	public short getShortID() {
		return shortID;
	}

	/**
	 * @param shortID
	 */
	public void setShortID(short shortID) {
		if(person!=null) { 
			person.setShortID(shortID);
		}
		this.shortID = shortID;
	}

	/**
	 * @return
	 */
	public int getHPUdpPort() {
		// TODO Auto-generated method stub
		return HPUdpPort;
	}

	/**
	 * @param udpPort
	 */
	public void setHPUdpPort(int udpPort) {
		HPUdpPort = udpPort;
	}

}
