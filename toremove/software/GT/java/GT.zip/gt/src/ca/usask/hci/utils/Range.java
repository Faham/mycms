/*
 * Created on Mar 15, 2004
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package ca.usask.hci.utils;

/**
 * @author Chris Fedak
 *
 */
public class Range {
	double min;
	double max;
	/**
	 * 
	 */
	public Range(double min, double max) {
		super();
		this.min = min;
		this.max = max;
	}
	/**
	 * @return Returns the max.
	 */
	public double getMax() {
		return max;
	}
	/**
	 * @param max The max to set.
	 */
	public void setMax(double max) {
		this.max = max;
	}
	/**
	 * @return Returns the min.
	 */
	public double getMin() {
		return min;
	}
	/**
	 * @param min The min to set.
	 */
	public void setMin(double min) {
		this.min = min;
	}
}
