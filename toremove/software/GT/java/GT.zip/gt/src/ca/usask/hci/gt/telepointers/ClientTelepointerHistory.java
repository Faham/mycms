/*
 * Created on Dec 18, 2003
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package ca.usask.hci.gt.telepointers;

import java.awt.Point;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;

import ca.usask.hci.gt.GTController;
import ca.usask.hci.gt.Person;
import ca.usask.hci.utils.GTLogger;

/**
 * Encapsulates historical information about telepointers for a particular client, including
 * raw telepointers, predicted telepointers and errors in prediction for telepointers.
 * 
 * @author Chris Fedak
 *
 */
public class ClientTelepointerHistory {
		//LinkedList points; // most recent to least recent order
		String id;
		int lastSequence = -1;
		int lastFec = 0;
		int  mostRecentSequence = -1;
		int jumpAheadDistance;
		int jumpBackDistance;
		int extendedHistoryCapacity = 1000;
		
		int estProcessingTime;
		int estPredictionTime;
		
		int errorUpdatesPending =0;
		
		int readLocks = 0;
		boolean writeLock = true;
		
		int predictAhead = 0;
		
		int testI;
		
		String logname;
		GTLogger predictLog;
		GTLogger receiveLog;
				
		int lastJump = 0;
		
		short shortID = -1; //short ID of user whose telepointer this represents
		short capacity;  //how many points this history will store
		
		OrderedPoint[] history;
		List extendedHistory; //stored in most recent FIRST order;
		
		GTTelepointerPredictor predictor;
		
		HashMap predictedHistoryMap;
		LinkedList predictedHistoryList;
		HashMap revHistoryMap;
		boolean writeLogs;
		
		//accuracy estimator
		Point[] realPointsError;
		Point[] predictedPointsError;
		double[] differencePointsError;
		int diffIns = 0, diffSize = 0;
		double newRollingAvgError = 0;
		Point realPoint, predPoint;
		
		//smoothness Estimators
		double smoothnessEst=0;
		double[] smoothnessHist = new double[100];
		int smoothIns=0, smoothSize= 0;
		PredictedPoint lastPredict = null;
		
		double runningAverageError[] = new double[100];
		
		public ClientTelepointerHistory(String id, short capacity, GTTelepointerPredictor predictor) {
			extendedHistory = Collections.synchronizedList(new LinkedList());
			//shortID = GTController.getInstance().getPersonFromSenderId(id).getShortID();
			this.capacity = capacity;
			history = new OrderedPoint[capacity];
			jumpBackDistance = (short) (capacity/4);
			jumpAheadDistance = (short) (capacity-jumpBackDistance);	
			//predictor = new GTVelocityPredictor();
			//predictor = new GTDefaultPredictor();
			
			this.id = id;
			logname = "test";

			//only write logs if this is not a local history class
			writeLogs = !(id==GTController.getInstance().getMyID());
			String me;
			me = GTController.getInstance().getMyID();
			me = me.replaceAll(":","-");
			me = me.replaceAll("/","");
			
			String name = id;
			name = name.replaceAll(":","-");
			name = name.replaceAll("/","");
			
			if(writeLogs) {
				predictLog = new GTLogger("predictedfor-"+name+"on-"+me+".txt");
				receiveLog = new GTLogger("receivedFrom-"+name+"on-"+me+".txt");
				//predictor = new GTAccelerationPredictor(name);
				//predictor = new GTInterpolatingPredictor(150);
				//predictor = new GTDefaultPredictor();
			}
			this.predictor = predictor;

			predictedHistoryMap = new HashMap();
			predictedHistoryList = new LinkedList();
			revHistoryMap = new HashMap();
			
			
			//initialize new Error estimator
			realPointsError = new Point[100];
			predictedPointsError = new Point[100];
			differencePointsError = new double[100];
		}
		
		/**
		 * 
		 * @return -1 if no short ID assigned, otherwise a value between 0 and 15
		 * 		that was assigned by the server to the client that this history tracks.
		 */
		public short getShortID() {
			Person p = GTController.getInstance().getPersonFromSenderId(id);
			if(p == null) {
				shortID = -1;
			} else {
				shortID = p.getShortID();
			}
			return shortID;
		}
		/**
		 * @param time ms in the future (from last point known at time of prediction)
		 * @return long run error for the bin sepcified in time
		 */
		public double getError(long time) {
			/*I'll assume that there will be a method of cth that is something like getAccuracy(long time)
			which will give me the recorded accuracy when predicting a certain time into the future
			I mean the average accuracy
			*/
			double ret =-1;
			int bin;
			bin = (int)Math.floor(time/100);
			
			if(bin<runningAverageError.length) {
				ret = runningAverageError[bin];
			}
			return ret;
		}
		/**
		 * uses new method for determining error in system.  is 0 until primed (usually about a second
		 * of mouse movement
		 * 
		 * @return Higher is less accurate.  0 is perfect accuracy.  Measured ina verage pixels of 
		 * difference from real points.
		 */
		public double getAccuracy() {
			return newRollingAvgError;
		}
		
		/**
		 * uses new method for determining smoothness in system.  is 0 until primed (usually about a second
		 * of mouse movement
		 * 
		 * @return Higher is less smooth.  0 is a motionless cursor.  Measured in average pixels of 
		 * difference per display.
		 */
		public double getSmoothness() {
			return smoothnessEst;
		}
		/**
		 * Estimates timeliness using four components. 
		 * 1)Network time(ping)
		 * 2)ProcessingTime (to add a new point to the history)
		 * 3)Prediction Time (ms to predict a point from history
		 * 4)prediction adjustment (how far int he future or the past the predictor is attemtping to display info)
		 * 
		 * 
		 * @return estimated milliseconds between a point being sent, and its availablity to be displayed.
		 */
		public double getTimeliness() {
			return GTController.getInstance().getPingManager().getLatestPing(id)+estProcessingTime+estPredictionTime-predictor.latencyAdjustment()-predictAhead;
		}
		
		public int getEstimatedReceivePeriod() {
			OrderedPoint op1, op2;
			int seq2;
			int period;
			List hist = history();
			seq2 = lastSequence++;
			if(seq2>127) seq2 = 0;
			
			if(hist.size() >30) {
				op2 = (OrderedPoint)hist.get(0);
				op1 = (OrderedPoint)hist.get(hist.size()-1);
			
				period = (int) ((op2.getTimestamp()-op1.getTimestamp())/history.length);
				return period;
			} 
			
			return 50;
		}
		
		/**
		 * 
		 * @param c list must contain OrderedPoint objects, and be int most recent -> least recent order	
		 * @return true if successful, false otherwise
		 */
		public boolean addAll(List c) {
			long start = System.currentTimeMillis();
			boolean successful = true;
			ListIterator it = c.listIterator();
			OrderedPoint candidate;
			int highestPoint = -1, secondPt, period, thirdpt;
			long structureIndex = 0, adjustedTimestamp;
			while(it.hasNext()) {
				candidate = (OrderedPoint)it.next();
				if(candidate.getOrder() >= capacity) continue;
				if(candidate.getOrder() < 0 ) System.err.println("bad order");
				//if( (history[candidate.getOrder()] == null) ) {
					history[candidate.getOrder()] = candidate;
				//}
				if(candidate.getOrder()==capacity-1) {
					addToExtendedHistory((OrderedPoint[])history.clone());
				}
				
				if(highestPoint == -1) {
					if(predictor!=null) { 
						predictor.correct(new Point(candidate.x, candidate.y));
					}
					highestPoint = candidate.getOrder();
					//add to error calculating structure
					OrderedPoint op2 = (OrderedPoint)history[highestPoint];
					secondPt = highestPoint+1;
					if(secondPt>127) secondPt = 0;
					thirdpt = highestPoint-1;
					if(thirdpt<0) thirdpt = 127;
					OrderedPoint op1 = (OrderedPoint)history[secondPt];
					OrderedPoint op3 = (OrderedPoint)history[thirdpt];
			
					if(op1 != null && op2 !=null) {
						period = (int) ((op2.getTimestamp()-op1.getTimestamp())/128);
					} else {
						period = 0;
					}
					
					if(op3 != null) {
						adjustedTimestamp = op3.getTimestamp()+period;
					} else {
						adjustedTimestamp = candidate.getTimestamp();
					}

					structureIndex = adjustedTimestamp/10;
					structureIndex = structureIndex%100;
					if(realPointsError[(int)structureIndex]==null) {
						realPointsError[(int)structureIndex] = new Point(candidate.getX(), candidate.getY());
					} else {
						realPointsError[(int)structureIndex].x = candidate.getX();
						realPointsError[(int)structureIndex].y = candidate.getY();	
					} 	
					printPoint(candidate, true);
				}
			}
			
			//		calculate jump
			int jumpA, jumpB;
			jumpB = lastSequence - highestPoint;
			jumpA = highestPoint - lastSequence;
			if(jumpA >= 0) {
				if(jumpA <= jumpAheadDistance) {
					//normal moving ahead packet.
					setJump(jumpA);
				} else {
					//old packet, wrapped around backwards 
					//
					setJump( (-1*(lastSequence+(capacity-jumpA))));
				}
			} else {
				if(jumpB<=jumpBackDistance) {
					//backwards jump that doesn't wrap around
					setJump(jumpB);
				} else {
					//forward jump that wraps around
					setJump((capacity-lastSequence)+highestPoint);
				}
			}
			lastSequence = highestPoint;
			if(lastJump>0) {
				errorUpdatesPending += lastJump;
				//update accuracy measurer
				//updateError();
			}
			estProcessingTime = (int) (System.currentTimeMillis()-start);			
			return successful;
		}
		/**
		 * Internal: updates the long run error averages based on new points.
		 *
		 */
		private synchronized void updateError() {
			List hist = history();
			Iterator it = hist.iterator();
			PredictedPoint pred;
			OrderedPoint real, op2, op1;
			long last;
			long period;
			double dx, dy, diff;
			int bin;
			
			op2 = (OrderedPoint)hist.get(0);
			op1 = (OrderedPoint)hist.get(hist.size()-1);
			
			last = op2.getTimestamp();
			period = (int) ((op2.getTimestamp()-op1.getTimestamp())/hist.size());
			
			for(int i = 0; i< Math.min(errorUpdatesPending,hist.size());i++) {
				real = (OrderedPoint)it.next();
				pred = closestPredictedPoint(last-(i*period));
				if(pred!=null) {
					dx = Math.abs(real.getX()-pred.getX());
					dy = Math.abs(real.getY()-pred.getY());
					diff = Math.pow((Math.pow(dx,2)+ Math.pow(dy,2)),.5);//c^2 = a^2 + b^2;
					//now put the difference in the right bin based on dtime;
					bin = (int)(Math.min((double) Math.abs(Math.floor(pred.getTimeGap()/100)), Math.abs((double) runningAverageError.length-1)));
					if(bin<0) bin = 0;
					if(runningAverageError[bin]==0.0) {
						runningAverageError[bin]=diff;
					} else {
						runningAverageError[bin]=(diff+runningAverageError[bin])/2;
					}
				}
			}
			errorUpdatesPending = 0;
		}
				
		/**
		 * Used with errorUpdate, finds the closest predictedPoint to the time value passed in
		 * 
		 * O(n)
		 * 
		 * @param time the time you are searching for
		 * @return the closest PredictedPoint (in time) to time
		 */
		private PredictedPoint closestPredictedPoint(long time) {
			PredictedPoint ret=null, candidate, candidate2;
			
			int maxHistory = 200,
					searched =0;
			Long stime, stime2; 
			ListIterator li = predictedHistoryList.listIterator(predictedHistoryList.size());
			
			while(li.hasPrevious() && searched<=maxHistory) {
				candidate = (PredictedPoint)li.previous();
				stime = (Long)revHistoryMap.get(candidate);
				if(stime.longValue() < time ) {
					searched = 200;
					if(li.hasPrevious()) {
						candidate2 = (PredictedPoint)li.previous();
						stime2 = (Long)revHistoryMap.get(candidate2);
						if(Math.abs((double) (time-stime.longValue())) < Math.abs((double) (time-stime2.longValue()))) {
							//first candidate is closest
							ret = candidate;
						} else {
							//sencod candidate is closest
							ret = candidate;
						}
					}
				} else {
					searched++;
				}
			}
			return ret;
		}
			
		/**
		 * 
		 * 
		 * @param candidate point to print
		 * @param actual is this a received point (true) or a predicted one (false)
		 */
		private void printPoint(OrderedPoint candidate, boolean actual) {
			// TODO Auto-generated method stub
			String outString;
			
			outString = String.valueOf(candidate.getTimestamp());
			outString += " " + String.valueOf(candidate.getX());
			outString += " " + String.valueOf(candidate.getY());
			outString += " " + String.valueOf(GTController.getInstance().getTelepointerController().getBroadcastDelay());
			outString += " " + String.valueOf(GTController.getInstance().getPingManager().getLatestPing(id)+estProcessingTime+estPredictionTime);
 			
			try {
				GTHighPerformanceTelepointerController gthptc = (GTHighPerformanceTelepointerController) GTController.getInstance().getTelepointerController();
				outString+= " "+ String.valueOf(gthptc.getFECLevel());
			} catch (Exception e) {
				
			}
			if(!actual) {
				if(writeLogs) predictLog.logLine(outString);
			} else {
				if(writeLogs) receiveLog.logLine(outString);
			}
		}

		/**
		 * Internal : adds a list ot Ordered Points to the Extended History
		 * 
		 * @param newHistory
		 */
		private synchronized void addToExtendedHistory(OrderedPoint[] newHistory) {
			synchronized (extendedHistory) {
				for(int i = 0;i<newHistory.length;i++) {
					if(newHistory[i] !=null)
						extendedHistory.add(0,newHistory[i]);
					if(extendedHistory.size()>= extendedHistoryCapacity)
						extendedHistory.remove(extendedHistory.size()-1);
				}
			}
		}

		/**
		 * 
		 * @return the last 127 OrderedPoint objects received from this client
		 */

		public List history() {
			List l;
			int counter = 0;
			int end = lastSequence;
			int nulls = 0;
			l = new LinkedList();
			if(lastSequence >= capacity-2) counter = 0;
			else counter = lastSequence+1;
			
			while(counter != end) {
				if(history[counter]!=null)
					((LinkedList)l).addFirst(history[counter]);
				else {
					nulls++;
				}
				counter++;
				if(counter >= capacity) counter = 0;
			}
			if(history[counter]!=null) {
				((LinkedList)l).addFirst(history[counter]);
			} 
			if(testI == 50) {
					//Messenger.getInstance().message(String.valueOf(lastSequence) + " =lastSequence, nulls=" + String.valueOf(nulls));
				testI= 0;
			} else {
				testI++;
			}
			
			return l;
		}
		
		/**
		 * The last 1000 points received from this client
		 * 
		 * @return
		 */
		public synchronized List extendedHistory() {
			List val = new LinkedList();
			//readLocks++;
			synchronized (extendedHistory) {
				val.addAll(extendedHistory);
			}
			//readLocks--;
			for(int i = 0; i<lastSequence;i++){
				val.add(0,history[i]);
			}
			
			return val;
		}
		
		/**
		 * Used to get a list suitable for transforming into a fec packet
		 * 
		 * @param fec number of points
		 * @return the last (fec) points, 
		 */
		public List fecHistory(int fec) {
			List l;
			int counter = 0;
			int end = lastSequence-fec;
			if(end<0) {
				//fec group might wrap
				end = capacity+end;
			}
			l = new LinkedList();
			if(lastSequence >= capacity-1) counter = 0;
			else counter = lastSequence+1;
			
			for(int k = lastSequence; k!=end;k--) {
				if(k<0) {
					k=capacity-1;
					if(k==end) break;
				}
				if(k>=capacity-1) continue;
				if(history[k]!=null)
					l.add(history[k]);
			}
			
			return l;
		}
		
		/**
		 *  
		 * @return Most recent Point 
		 */
		public Point getMostRecent() {
			Point val;
			OrderedPoint o = null;
			//if(points.size() < 1) 
			if(lastSequence >=0)
				o = history[lastSequence];
			if(o == null) return new Point(0,0);
			val = new Point(o.getX(), o.getY());
			return val;
		}

		/**
		 * @param candidate	OrderedPoint to be added.
		 */
		public void addPoint(OrderedPoint candidate) {
			int jumpA, jumpB;
			if(candidate.getOrder() >= capacity) return;
			if( (history[candidate.getOrder()] == null) ||
				(history[candidate.getOrder()].isCertain()) == false  ) {
				history[candidate.getOrder()] = candidate;
			}	
					
			//calculate jump
			jumpB = lastJump - candidate.getOrder();
			jumpA = candidate.getOrder() - lastJump;
			if(jumpA >= 0) {
				if(jumpA <= jumpAheadDistance) {
					//normal moving ahead packet.
					setJump(jumpA);
				} else {
					//old packet, wrapped around backwards 
					//
					setJump( (-1*(lastJump+(capacity-jumpA))));
				}
			} else {
				if(jumpB<=jumpBackDistance) {
					//backwards jump that doesn't wrap around
					setJump(jumpA);
				} else {
					//forward jump that wraps around
					setJump((capacity-lastJump)+candidate.getOrder());
				}
			}
			
			//set order
			lastSequence = candidate.getOrder();
			
		}
		
		/**
		 * Internal: jump is the difference between the last two sequencenumbers
		 * 
		 * @param jumpA
		 */
		private void setJump(int jumpA) {
			int index;
			if(jumpA >lastFec+1) {
//				System.err.println("Large Jump detected: "+String.valueOf(jumpA));
				for(int i = lastFec+1; i<jumpA;i++) {
					index = lastSequence-i;
					if(index <0) index = 128+index;
					history[index] = null;
				}
			}
			lastJump = jumpA;
			//TODO handle Jump event publishing etc...
			
		}

		private int incrementSequence() {
			lastSequence++;
			lastJump = 1;
			if(lastSequence>=capacity) lastSequence = 0;
			return lastSequence;
		}

		/**
		 * Adds a point and gives it the next available sequence number.
		 * 
		 * @param p 
		 */
		public void addRecentPoint(Point p) {
			OrderedPoint o = new OrderedPoint(p, incrementSequence());
			o.setTimestamp(System.currentTimeMillis());
			List l = new LinkedList();
			l.add(o);
			addAll(l);
		}

		/**
		 * @param l
		 * @return
		 */
		public synchronized PredictedPoint getPredictedPoint(long time) {
			long start = System.currentTimeMillis();
			PredictedPoint ret = predictor.predict(this,time+predictAhead);
			estPredictionTime = (int) (System.currentTimeMillis()-start);
			Object remove, remove2;
			long structureIndex, adjIndex;
			Point old;
			double est;
			ret.setEstimatedLatency(GTController.getInstance().getPingManager().getLatestPing(id));
			
			//update accuracy estimator
			structureIndex = time/10;
			structureIndex = structureIndex%100;
			if(predictedPointsError[(int)structureIndex]==null) {
				predictedPointsError[(int)structureIndex] = new Point((int)ret.getX(), (int)ret.getY());
			} else {
				old = new Point(predictedPointsError[(int)structureIndex].x, predictedPointsError[(int)structureIndex].y);
				predictedPointsError[(int)structureIndex].x = (int)ret.getX();
				predictedPointsError[(int)structureIndex].y = (int)ret.getY();
				if(realPointsError[(int)structureIndex]!=null){
					adjIndex = structureIndex+((predictor.latencyAdjustment()/10)%100);
					if(adjIndex <0) adjIndex = 99+adjIndex;
					if(predictedPointsError[(int)adjIndex]!=null) {
						est = Math.sqrt(Math.pow(old.x - predictedPointsError[(int)structureIndex].x,2) + 
							Math.pow(old.y - predictedPointsError[(int)adjIndex].y, 2));
						//now add to differences estimate error
						if(diffSize < 100) {
							diffSize++;
							newRollingAvgError = (est + (newRollingAvgError*(diffSize-1)))/diffSize; 
							differencePointsError[diffIns] = est;
							diffIns++;
							if(diffIns>99) diffIns =0; 
						} else {
							newRollingAvgError += ((est - differencePointsError[diffIns])/diffSize);
							//System.out.println("New Avg Accuracy:" + String.valueOf(newRollingAvgError));
							differencePointsError[diffIns] = est;
							diffIns++;
							if(diffIns>99) diffIns=0;
						}
					}
				}	
			} 
			
			//update smoothness estimator
			if(lastPredict !=null) {
				est = Math.sqrt( Math.pow(ret.getX()-lastPredict.getX(),2)+
					Math.pow(ret.getY()-lastPredict.getY(),2));
				
				if(smoothSize >99) {
					smoothnessEst += (est-smoothnessHist[smoothIns])/smoothSize;
					smoothnessHist[smoothIns] = est;
					smoothIns++;
					if(smoothIns>99) smoothIns = 0;
				} else {
					smoothSize++;
					smoothnessEst = (est+(smoothnessEst*(smoothSize-1)))/smoothSize; 
					smoothnessHist[smoothIns] = est;
					smoothIns++;
					if(smoothIns>99) smoothIns = 0;
						
				}
				
			} 

			//add to predictedHistory
			Long objTime = new Long(time);
			predictedHistoryMap.put(objTime, ret);
			revHistoryMap.put(ret, objTime);
			predictedHistoryList.add(ret);
			
			//if over capcity, prune
			if(predictedHistoryList.size() > extendedHistoryCapacity) {
				remove = predictedHistoryList.get(0);
				predictedHistoryList.remove(remove);
				remove2 = predictedHistoryMap.get(remove);
				predictedHistoryMap.remove(remove);
				revHistoryMap.remove(remove2);				
			}
				
			OrderedPoint op = new OrderedPoint(ret, 0);
			op.setTimestamp(time);
			printPoint(op,false);
			lastPredict = ret;
			return ret;
		}
		/**
		 * @return
		 */
		public GTTelepointerPredictor getPredictor() {
			return predictor;
		}

		/**
		 * @param predictor
		 */
		public void setPredictor(GTTelepointerPredictor predictor) {
			this.predictor = predictor;
		}

		/**
		 * @param i
		 */
		public void setLastFec(int i) {
			lastFec=i;
		}
		/**
		 * @return Returns the predictAhead.
		 */
		public int getPredictAhead() {
			return predictAhead;
		}
		/**
		 * @param predictAhead The predictAhead to set.
		 */
		public void setPredictAhead(int predictAhead) {
			this.predictAhead = predictAhead;
			if(predictAhead <0) this.predictAhead = 0;
		}
	}
