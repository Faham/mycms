/*
 * Created on Jan 25, 2004
 */
package ca.usask.hci.gt.adaptive;

import java.io.Serializable;

import ca.usask.hci.gt.GTChannel;
import ca.usask.hci.gt.GTChannelListener;
import ca.usask.hci.gt.GTController;
import ca.usask.hci.gt.GTEvent;
import ca.usask.hci.gt.telepointers.GTHighPerformanceTelepointerController;
import ca.usask.hci.gt.telepointers.GTTelepointerController;
import ca.usask.hci.utils.GTLogger;

/**
 * @author Jeff Dyck
 *
 */
public class GTAdaptiveHPTControl {

	public static final long RATE_CHANGE = 5;
	public static final int FEC_LEVEL_CHANGE = 1;
	GTLogger adaptiveSenderLog;

	/**
	 * 
	 */
	public GTAdaptiveHPTControl() {
		super();
	}

	public void start() {
		GTChannel control = new GTChannel("GT_TELEPOINTER_CONTROL");
		GTController.getInstance().registerChannel(control);
		GTController.getInstance().subscribeToChannel("GT_TELEPOINTER_CONTROL");
		GTController.getInstance().addChannelListener(new Receiver(), "GT_TELEPOINTER_CONTROL");
		String me;
		me = GTController.getInstance().getMyID();
		me = me.replaceAll(":","-");
		me = me.replaceAll("/","");		
		adaptiveSenderLog = new GTLogger("adaptiveSenderLog.txt");
	}
	
	public class Receiver implements GTChannelListener {
		public void handleGTEvent(GTEvent t) {

			System.out.println("Received GT_TELEPOINTER_CONTROL channel message: " + t.getMessageName());	
			adaptiveSenderLog.logLine(System.currentTimeMillis() + "\tReceived GT_TELEPOINTER_CONTROL channel message: " + t.getMessageName());	

			if(Integer.parseInt(t.getMessageName()) == GTAdaptiveAction.INCREASE_FEC ) {
				GTHighPerformanceTelepointerController gtc = (GTHighPerformanceTelepointerController) GTController.getInstance().getTelepointerController();
				gtc.setFECLevel(gtc.getFECLevel() + FEC_LEVEL_CHANGE);
				System.out.println("Increased FEC by: " + FEC_LEVEL_CHANGE + " to: " + gtc.getFECLevel());	
				adaptiveSenderLog.logLine(System.currentTimeMillis() + "\tIncreased FEC by: " + FEC_LEVEL_CHANGE + " to: " + gtc.getFECLevel());	
			}
			
			else if (Integer.parseInt(t.getMessageName()) == GTAdaptiveAction.DECREASE_FEC) {
				GTHighPerformanceTelepointerController gtc = (GTHighPerformanceTelepointerController) GTController.getInstance().getTelepointerController();

				if (gtc.getFECLevel() > 0) {
					gtc.setFECLevel(gtc.getFECLevel() - FEC_LEVEL_CHANGE);
					System.out.println("Decreased FEC by: " + FEC_LEVEL_CHANGE+ " to: " + gtc.getFECLevel());	
					adaptiveSenderLog.logLine(System.currentTimeMillis() + "\tDecreased FEC by: " + FEC_LEVEL_CHANGE+ " to: " + gtc.getFECLevel());	
				}
				else {
					System.out.println("FEC is already at 0 - no decrease was made");	
					adaptiveSenderLog.logLine(System.currentTimeMillis() + "\tFEC is already at 0 - no decrease was made");	
				}
			}
			
			else if (Integer.parseInt(t.getMessageName()) == GTAdaptiveAction.INCREASE_RATE) {
				GTTelepointerController gtc = GTController.getInstance().getTelepointerController();

				// We'll set a minimum of 33. Going lower will flood the puters.
				if (gtc.getBroadcastDelay() - RATE_CHANGE > 33) {
					gtc.setBroadcastDelay(gtc.getBroadcastDelay() - RATE_CHANGE);				
					System.out.println("Decreased broadcast delay by: " + RATE_CHANGE + " to: " + gtc.getBroadcastDelay());
					adaptiveSenderLog.logLine(System.currentTimeMillis() + "\tDecreased broadcast delay by: " + RATE_CHANGE + " to: " + gtc.getBroadcastDelay());
				}
				else {
					System.out.println("Broadcast delay cannot be lowered any further");
					adaptiveSenderLog.logLine(System.currentTimeMillis() + "\tBroadcast delay cannot be lowered any further");
				}
			}
			
			else if (Integer.parseInt(t.getMessageName()) == GTAdaptiveAction.DECREASE_RATE) {
				GTTelepointerController gtc = GTController.getInstance().getTelepointerController();
				gtc.setBroadcastDelay(gtc.getBroadcastDelay() + RATE_CHANGE);
				System.out.println("Increased broadcast delay by: " + RATE_CHANGE + " to: " + gtc.getBroadcastDelay());	
				adaptiveSenderLog.logLine(System.currentTimeMillis() + "\tIncreased broadcast delay by: " + RATE_CHANGE + " to: " + gtc.getBroadcastDelay());	
			}
		}
	}	
}
