/*
 * Created on Feb 11, 2004
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package ca.usask.hci.utils;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

/**
 * @author Chris Fedak
 *
 */
public class GTLogger {
	PrintWriter out;
	List logFIFOQueue;
	boolean writing;
	Thread writingThread;
	/**
	 * 
	 */
	public GTLogger(String logname) {
		super();
		//logme="";
		logFIFOQueue = Collections.synchronizedList(new LinkedList());
		try {
			out = new PrintWriter(new FileWriter(logname));
			writing=true;
			writingThread = new Thread(new LogWritingThread());
			writingThread.start();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public synchronized void log(String log) {
		synchronized(logFIFOQueue){
			logFIFOQueue.add(log);
		}
	}
	
	public synchronized void logLine(String log) {
			synchronized(logFIFOQueue){
				logFIFOQueue.add(log+"\n");
			}
		}
	
	private class LogWritingThread implements Runnable {

		/* (non-Javadoc)
		 * @see java.lang.Runnable#run()
		 */
		public void run() {
			String writeme;
			// TODO Auto-generated method stub
			while(writing) {
					if(logFIFOQueue.size()>0){
						synchronized(logFIFOQueue) {
							writeme = (String)logFIFOQueue.get(0);
							logFIFOQueue.remove(0);
						}
						out.write(writeme);
						out.flush();
					} else {
						try {
							Thread.sleep(100);
						} catch (InterruptedException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
				}		
		}
	}
}
