package ca.usask.hci.gt.adaptive;

import java.util.*;

import ca.usask.hci.gt.GTController;
import ca.usask.hci.gt.telepointers.OrderedPoint;
import ca.usask.hci.network.qos.*;

import ca.usask.hci.utils.GTLogger;

/**
 * @author Jeff Dyck
 */
public class GTHighPerformanceTelepointerAdaptiveControl {
	String clientID;
	
	GTLogger adaptiveReceiverLog;
	
	/**
	 * The number of messages to consider when determining mer.
	 */
	private final int FEC_HISTORY_LENGTH = 500;
	
	/**
	 * The minimum number of new messages that must be received before we try to adapt again.
	 */
	private final int MINIMUM_NEW_MESSAGES_FOR_ADAPTATION = 1000;
	
	private int lastAdaptationMessageIndex = 0;
	
	public GTHighPerformanceTelepointerAdaptiveControl(String clientID) {
		this.clientID = clientID;
		
		adaptiveReceiverLog = new GTLogger("adaptiveReceiverLog.txt");
	}
	
	//latency is stored as a long
	public void adaptiveUpdate(List history, List latencies, boolean useAFEC) {

		// get the most recent message index
//		OrderedPoint p1 = (OrderedPoint)history.get(0);
//		int mostRecentMessageIndex = p1.getOrder();

//		long t1 = p1.getTimestamp();
		
		if (history.size() < FEC_HISTORY_LENGTH) {
			// don't bother adapting til we have a sufficient amount of messages
			// to make good decisions on
			System.out.println("History too short to adapt to...");
			adaptiveReceiverLog.logLine("History too short to adapt to...");
		}
//		else if (mostRecentMessageIndex-lastAdaptationMessageIndex < MINIMUM_NEW_MESSAGES_FOR_ADAPTATION) {
			// don't adapt if we don't receive enough new messages to measure change
//			System.out.println("Not enough new messages received (" + (mostRecentMessageIndex-lastAdaptationMessageIndex) + ") to evaluate last adaptive action. Waiting for more messages.");
			
			// TODO: This doesn't currently work - the OrderedPoint doesn't keep an index.
//		}	
		else {
			// lastAdaptationMessageIndex = mostRecentMessageIndex;
			
			GTHPTQOS qosProperties = new GTHPTQOS();
			
			// calculate stats
			
			// calculate the mer
			float mer = getMer(history);

			// calculate rate - need to get this from history.
			int rate = getRate(history);
			
			// calculate latency
			int latency = getLatency(latencies);
			
			// calculate jitter
			int jitter = getJitter(history);
						
			// A list of our non-dependent adaptive actions.
			ArrayList adaptiveActionList = new ArrayList();

			boolean increaseFEC = false;
			boolean decreaseFEC = false;

			boolean increaseRATE = false;
			boolean decreaseRATE = false;
			
			// get adaptive actions that help with relilability
			if (mer < 100-qosProperties.MAX_RELIABILITY) {
				// we have too little loss - need to back off redundancy, as it is wasting bandwidth
				decreaseFEC = true;
			}
			else if (mer > 100-qosProperties.MIN_RELIABILITY) {
				// too much loss - need more redundancy
				increaseFEC = true;
				System.out.println("Scheduling FEC increase");
			}
			else {
				// we are in the target range - can back off FEC a tad if we need to
				// we'll do this later when we consider latency and jitter
			}
			
			// get adaptive actions that help with rate
			if (rate > qosProperties.MAX_RATE) {
				// rate > MAX_RATE 
				// we need to throttle back rate
				decreaseRATE = true;
			}
			else if (rate < qosProperties.MIN_RATE) {
				// MIN_RATE > rate
				// we need to increase rate
				increaseRATE = true;
			}
			else {
				// MAX_RATE > rate > MIN_RATE
				// we are in the target range, and can increase rate if we want to to approach the MAX
				// we'll do this later when we consider latency and jitter
			}
			
												// get adaptive actions that help with latency
			if (latency > qosProperties.MAX_LATENCY) {
				// throttle back the rate or reduce FEC size to decrease latency

				System.out.println("latency is: " + latency);
				System.out.println("MAX_LATENCY is: " + qosProperties.MAX_LATENCY);
				
				// Remove increases, leave decreases, create decreases if there are no increases.
				// This will not effectively deal with the situation where we are below QOS for latency, rate, and FEC
				// To fix this, we could consider which is closest to good and decrease it in favor of the others
				if (increaseFEC) {
					increaseFEC = false;
					System.out.println("Overrode FEC increase in favor of latency");
				}
				else {
					decreaseFEC = true;
				}

				if (increaseRATE) {
					increaseRATE = false;
				}
				else {
					decreaseRATE = true;
				}
			}
			else if (latency < qosProperties.MIN_LATENCY) {
				// we should do stuff that increases latency - like increase rate or FEC size

				// leave all increases and add increases where we are not already trying to decrease
				if (!decreaseFEC) {
					increaseFEC = true;
				}
				if (!decreaseRATE) {
					increaseRATE = true;
				}
			}
			else {
				// do nothing to existing increase / decrease messages for the purpose of latency
				
				// However, since latency is OK, consider jitter
				// We don't consider jitter if latency is out of target range since
				// we don't want them fighting with one antoher.
				// Idea is to reach equilibrium between reliability, rate, and latency before tweaking jitter.

				// We can improve on this by saying that if latency is closer than jitter, then
				// then consider jitter, and vice versa. For now, latency is preferred over jitter, 
				// which makes sense since it is more tightly coupled with rate and FEC that jitter is.
				
				// get adaptive actions that help with jitter
/*
				if (jitter > qosProperties.MAX_JITTER) {
					// Remove increases, leave decreases, create decreases if there are no increases.
					// This will not effectively deal with the situation where we are below QOS for latency, rate, and FEC
					// To fix this, we could consider which is closest to good and decrease it in favor of the others
					if (increaseFEC) {
						increaseFEC = false;
					}
					else {
						decreaseFEC = true;
					}

					if (increaseRATE) {
						increaseRATE = false;
					}
					else {
						decreaseRATE = true;
					}
				}
				else if (jitter < qosProperties.MIN_JITTER) {
					// we should do stuff that increases latency - like increase rate or FEC size

					// leave all increases and add increases where we are not already trying to decrease
					if (!decreaseFEC) {
						increaseFEC = true;
					}
					if (!decreaseRATE) {
						increaseRATE = true;
					}
				}
				else {
					// jitter is in target range
					// do nothing to existing increase / decrease messages
				}
*/
			}

			if (useAFEC && increaseFEC) {
				GTAdaptiveAction action = new GTAdaptiveAction(clientID, GTAdaptiveAction.INCREASE_FEC);
				adaptiveActionList.add(action);
				System.out.println("Added increase FEC to adaptive action list");
			}
			
			if (useAFEC && decreaseFEC) {
				GTAdaptiveAction action = new GTAdaptiveAction(clientID, GTAdaptiveAction.DECREASE_FEC);
				adaptiveActionList.add(action);
			}
			
			if (increaseRATE) {
				GTAdaptiveAction action = new GTAdaptiveAction(clientID, GTAdaptiveAction.INCREASE_RATE);
				adaptiveActionList.add(action);
			}
			
			if (decreaseRATE) {
				GTAdaptiveAction action = new GTAdaptiveAction(clientID, GTAdaptiveAction.DECREASE_RATE);
				adaptiveActionList.add(action);
			}
			
			// TODO: Send the actions
			for (int i=0; i<adaptiveActionList.size(); i++) {
				GTAdaptiveAction action = (GTAdaptiveAction) adaptiveActionList.get(i);
				System.out.println("sending GT_TELEPOINTER_CONTROL message: " + action.getMessageName() + " to " +  action.getToUserID());
				adaptiveReceiverLog.logLine(System.currentTimeMillis() + "\tsending GT_TELEPOINTER_CONTROL message: " + action.getMessageName() + " to " +  action.getToUserID());
				GTController.getInstance().sendToUser(action, "GT_TELEPOINTER_CONTROL");
			}
		}
	}

	public int getMer(List history) {
		int mer = 0;

		// get the message error rate (mer) over the last FEC_HISTORY_LENGTH messages
		int lostMessages = 0;
		int nullMessages = 0;
		int lastOrderedPointOrder = ((OrderedPoint) history.get(0)).getOrder();
		
		for (int i=1; i< FEC_HISTORY_LENGTH; i++) {
			OrderedPoint p = (OrderedPoint) history.get(i);

//			System.out.println("Last ordered point order: " + lastOrderedPointOrder);

			if (p != null)
//				System.out.println("Current point order: " + p.getOrder());
			
			if (p == null) {
				lostMessages ++;
				lastOrderedPointOrder ++;
				System.out.println(">>>>>>>>>>>>>>> Detected : a null point - counting it as lost");
				nullMessages++;
			}
		
			else if (p.getOrder() < lastOrderedPointOrder - 1) {
				lostMessages += lastOrderedPointOrder - p.getOrder() -1 ;
				System.out.println(">>>>>>>>>>>>>>> Detected : " + (lastOrderedPointOrder - p.getOrder() -1 ) + " lost messages");
				lastOrderedPointOrder = p.getOrder();				
			}
			else if (p.getOrder() > lastOrderedPointOrder && p.getOrder() !=127 && lastOrderedPointOrder != 0) {
				lostMessages += lastOrderedPointOrder + 127 - p.getOrder() -1;
				System.out.println(">>>>>>>>>>>> Detected : " + (lastOrderedPointOrder + 127 - p.getOrder() -1) + " lost messages");
				lastOrderedPointOrder = p.getOrder();
			}
			else {
				// no loss occurred
				lastOrderedPointOrder = p.getOrder();
			}
		}

		System.out.println("Total lost messages identified: " + lostMessages + " out of " + (FEC_HISTORY_LENGTH + lostMessages - nullMessages));
		
		mer = (int) (((float) lostMessages) / ((float) FEC_HISTORY_LENGTH + lostMessages - nullMessages) * 100.0f);		

		System.out.println("Current MER: " + mer);
		adaptiveReceiverLog.logLine(System.currentTimeMillis() + "\tCurrent MER: " + mer);
		return mer;
	}

	/**
	 * Returns rate in messages / second
	 * @param history
	 * @return
	 */
	public int getRate(List history) {
		// TODO: Doesn't really work since rate depends on stops in message flow
		// TODO: Need to detect bursts within the history and use them, excluding breaks.
		
		int rate = -1;

		OrderedPoint p1 = (OrderedPoint)history.get(0);

		OrderedPoint p2 = (OrderedPoint)history.get(100);
		if (p1 != null && p2 != null) {
			long t1 = p1.getTimestamp();
			long t2 = p2.getTimestamp();
			
			rate = (int) (1000L/((t1-t2)/100L));
			System.out.println("Current Rate: " + rate);
			adaptiveReceiverLog.logLine(System.currentTimeMillis() + "\tCurrent Rate: " + rate);
		}
		return rate;
	}

	/**
	 * Calultes the latency for the client.
	 * @return The latency for the last n pings
	 */
	public int getLatency(List pingHistory) {
		int latency = -1;
		
		int numPingsToConsider = 50;

		if (pingHistory == null) {
			System.out.println("Ping history for " + clientID + " is null");	
			return latency;
		}
		
		if (pingHistory.size() < 50) {
			numPingsToConsider = pingHistory.size();
		}
		
		int pingSum = 0;
		
		for (int i=0; i<numPingsToConsider; i++) {
			pingSum += ((Long) pingHistory.get(i)).intValue();
		}

		latency = pingSum/numPingsToConsider;
		System.out.println("Current Latency: " + latency);
		adaptiveReceiverLog.logLine(System.currentTimeMillis() + "\tCurrent Latency: " + latency);
		return latency;
	}	

	/**
	 * Calultes the jitter for the client.
	 * @param clientID
	 * @return The jitter based on the history - just an approximation
	 */
	public int getJitter(List history) {
		// TODO: Doesn't really work due to stops in message flow
		// TODO: Need to detect bursts within the history and use them, excluding breaks due to stops.
		
		int jitter = -1;

		long[] intervals = new long[100];
		long intervalSum = 0;
		
		long prevt = ((OrderedPoint) history.get(0)).getTimestamp();
		for (int i=1; i<101; i++) {
			OrderedPoint p = (OrderedPoint) history.get(i);
			if (p != null) {
				long t = p.getTimestamp();
				intervals[i-1] = prevt - t;
				prevt = t;
				intervalSum += prevt - t;
			}
		}

		long avgInterval = intervalSum/100;

		long jitterSum = 0;

		for (int i=0; i<intervals.length; i++) {
			jitterSum += Math.abs(intervals[i] - avgInterval);
		}
		
		jitter = (int) (jitterSum/100);
		System.out.println("Current Jitter: " + jitter);
		adaptiveReceiverLog.logLine(System.currentTimeMillis() + "\tCurrent Jitter: " + jitter);
		return jitter;
	}
}
