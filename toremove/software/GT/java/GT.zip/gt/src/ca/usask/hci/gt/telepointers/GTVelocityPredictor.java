/*
 * Created on Jan 22, 2004
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package ca.usask.hci.gt.telepointers;

import java.awt.Point;
import java.util.List;

/**
 * @author Chris Fedak
 *
 */
public class GTVelocityPredictor implements GTTelepointerPredictor {

	/**
	 * 
	 */
	public GTVelocityPredictor() {
		super();
		// TODO Auto-generated constructor stub
	}

	/* (non-Javadoc)
	 * @see ca.usask.hci.gt.telepointers.GTTelepointerPredictor#predict(ca.usask.hci.gt.telepointers.ClientTelepointerHistory, long)
	 */
	public PredictedPoint predict(ClientTelepointerHistory cth, long time) {
		OrderedPoint op1 = null, op2 = null;
		PredictedPoint val = null;
		double vx,vy;
		long dtime;
		int period;
		
		//
		
		
		List history = cth.history();
		if(history.size() == 0) return new PredictedPoint(0,0);
		if(history.size() <= 10) {
			 op1 = (OrderedPoint)history.get(0);
			 val = new PredictedPoint(op1.getX(), op1.getY());
		} else {
			//period detector
			op2 = (OrderedPoint)history.get(0);
			op1 = (OrderedPoint)history.get(history.size()-1);
			
			period = (int) ((op2.getTimestamp()-op1.getTimestamp())/history.size());
			
			op2 = (OrderedPoint)history.get(0);
			op1 = (OrderedPoint)history.get(9);
			vx = ((double)op2.getX()-(double)op1.getX())/(double)(period*9);
			vy = ((double)op2.getY()-(double)op1.getY())/(double)(period*9);
			
			//set maximum velocity to 250px/second
			if(vx > 0.250) vx = 0.250;
			if(vy > 0.250) vy = 0.250;
			
			dtime = time - op2.getTimestamp();
			
			val = new PredictedPoint((int) ((double)op2.getX()+vx*dtime), 
					(int) ((double)op2.getY()+vy*dtime),
					dtime);	
		}
		return val;
	}

	/* (non-Javadoc)
	 * @see ca.usask.hci.gt.telepointers.GTTelepointerPredictor#latencyAdjustment()
	 */
	public int latencyAdjustment() {
		// TODO Auto-generated method stub
		return 0;
	}

	/* (non-Javadoc)
	 * @see ca.usask.hci.gt.telepointers.GTTelepointerPredictor#correct(java.awt.Point)
	 */
	public void correct(Point p) {
		// TODO Auto-generated method stub
		
	}
}
