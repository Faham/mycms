/*
 * Created on Dec 1, 2003
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package ca.usask.hci.network.qos;

import java.net.Socket;

import ca.usask.hci.gt.GTEvent;
/**
 * Singleton
 * 
 * @author Chris Fedak
 *
 */
public class GTQoSScheduler {
	private static GTQoSScheduler skedj = new GTQoSScheduler();
	private Socket TCPSocket;
	
	/**
	 * 
	 */
	private GTQoSScheduler() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public static GTQoSScheduler getInstance() {
		return skedj;
	}
	
	public void setTCPSocket(Socket s) {
		TCPSocket = s;
	}
	
	public void send(GTEvent gte, GTQoSProperties gtp) {
		if(gtp.getLatency() >= 0.5 && gtp.getReliability() <= 0.5) {
			sendViaUDP(gte);
		} else {
			sendViaTCP(gte);
		}
		
	}

	/**
	 * @param gte
	 */
	private void sendViaTCP(GTEvent gte) {
		// TODO Auto-generated method stub
		
	}

	/**
	 * @param gte
	 */
	private void sendViaUDP(GTEvent gte) {
		// TODO Auto-generated method stub
		
	}	
}
