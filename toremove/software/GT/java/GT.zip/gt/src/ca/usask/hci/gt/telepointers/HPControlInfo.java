/*
 * Created on Dec 15, 2003
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package ca.usask.hci.gt.telepointers;

/**
 * @author Chris Fedak
 *
 */
public class HPControlInfo {
	int fec;
	
	/**
	 * 
	 */
	public HPControlInfo() {
		super();
		fec = 3;
		// TODO Auto-generated constructor stub
	}

	/**
	 * @return
	 */
	public int getFec() {
		return fec;
	}

	/**
	 * @param fec
	 */
	public void setFec(int fec) {
		this.fec = fec;
	}

}
