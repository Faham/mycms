package ca.usask.hci.gt.ypserver;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

import ca.usask.hci.utils.Messenger;

/**
 * @author Chris Fedak
 *
 */
public class TCPServerThread extends Thread {
	GTYellowPagesServer server;
	boolean listening;
	ServerSocket serverSock;
	int port = 4499;
	
	/**
	 * 
	 */
	public TCPServerThread(GTYellowPagesServer server) {
		super();
		this.server=server;
		setup();
		listening = true;
	}
	
	private void setup () {
		try {
			serverSock = new ServerSocket(port);
			Messenger.getInstance().message("connected", this);
		} catch (IOException e) {
			Messenger.getInstance().error("Could not listen on port: "+ String.valueOf(port), this);
			Messenger.getInstance().error("Correct ths problem and start the server again. Exiting...", this);
			System.exit(-1);
		}
	}
	
	public void run() {
		Socket clientSocket = null;
		while (listening) {
			try {
				clientSocket = serverSock.accept();
					clientSocket.setTcpNoDelay(true);
			} catch (IOException e) {
				Messenger.getInstance().error("Accept failed on port" + String.valueOf(port), this);
				return;
			}
			// got a connection so spawn a new worker to handle it
			Messenger.getInstance().message("got a connection", this);
			GTYellowPagesTCPWorker worker = new GTYellowPagesTCPWorker(server,clientSocket);
			server.addWorker(worker);
			new Thread(worker).start();
		}
	}
	


}
