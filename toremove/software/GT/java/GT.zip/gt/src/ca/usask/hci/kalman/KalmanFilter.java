/*
 * Created on Dec 12, 2003
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package ca.usask.hci.kalman;

import Jama.Matrix;

/**
 * @author Chris Fedak
 *
 */
public class KalmanFilter {
	int 		measurementVectorDimensions;
	int 		stateVectorDimensions;
	int 		controlVectorDimensions;
	
	
	/**
	 * predicted state (x'(k)):  x(k)=A*x(k-1)+B*u(k) 
	 */
	Matrix		predictedState;
	/**
	 * corrected state (x(k)):  x(k)=x'(k)+K(k)*(z(k)-H*x'(k))
	 */
	Matrix 		correctedState;	
	/**
	 * state transition matrix (A)
	 */
	Matrix		transitionMatrix;
	/**
	 * control matrix (B)
	 * 
	 */
	Matrix		controlMatrix;
	/**
	 * measurement matrix (H)
	 */
	Matrix		measurementMatrix;
	/**
	 * process noise covariance matrix (Q)
	 */
	Matrix 		processNoiseCovarianceMatrix;
	/**
	 * measurement noise covariance matrix (R)
	 */
	Matrix 		measurementNoiseCovarianceMatrix;
	/**
	 * priori error estimate covariance matrix (P'(k)): P'(k)=A*P(k-1)*At + Q)
	 */
	Matrix 		prioriErrorEstimateCovarianceMatrix;
	/**
	 * Kalman gain matrix (K(k)):  K(k)=P'(k)*Ht*inv(H*P'(k)*Ht+R)
	 *
	 */			
	Matrix 		kalmanGainMatrix;
	/**
	 * posteriori error estimate covariance matrix {P(k)): P(k)=(I-K(k)*H)*P'(k)
	 *
	 */
	Matrix		posterioriErrorEstimateCovarianceMatrix;
	

	public KalmanFilter(int measurementVectorDimensions, 
			int stateVectorDimensions,
			int controlVectorDimensions) {
		super();
		this.measurementVectorDimensions = measurementVectorDimensions;
		this.stateVectorDimensions = stateVectorDimensions;
		this.controlVectorDimensions = controlVectorDimensions;
		
		predictedState = new Matrix(stateVectorDimensions, 1);
		correctedState = new Matrix(stateVectorDimensions, 1);
		transitionMatrix = Matrix.identity(stateVectorDimensions, stateVectorDimensions);
		measurementMatrix = new Matrix(measurementVectorDimensions,stateVectorDimensions);
		processNoiseCovarianceMatrix = Matrix.identity(stateVectorDimensions, stateVectorDimensions);
		measurementNoiseCovarianceMatrix = Matrix.identity(measurementVectorDimensions, measurementVectorDimensions);
		prioriErrorEstimateCovarianceMatrix = new Matrix(stateVectorDimensions, stateVectorDimensions);
		kalmanGainMatrix = new Matrix(stateVectorDimensions, measurementVectorDimensions);
		posterioriErrorEstimateCovarianceMatrix = new Matrix(stateVectorDimensions, stateVectorDimensions);
		
		if(controlVectorDimensions >0) {
			controlMatrix = new Matrix(stateVectorDimensions, controlVectorDimensions);
		}
	}
	
	public Matrix predict(Matrix control) {
		Matrix result = null;
		Matrix temp;
		
		//update the state x'(k) = A*x(k)
		predictedState = transitionMatrix.times(correctedState);
		
		//predictedState.print(20,2);
		
		//optional control point update
		if(control!=null && controlVectorDimensions>0) {
			//update the state via control x'(k) = x'(k) + B*u(k)
			//predictedState = predictedState.plus(controlMatrix.times(control));
		}
		
		//System.out.println("process:predict");
		//processNoiseCovarianceMatrix.print(20,2); 
		
		//transitionMatrix.print(20,2);
		//posterioriErrorEstimateCovarianceMatrix.print(20,2);
		
		//temp = A*P(k)
		temp = transitionMatrix.times(posterioriErrorEstimateCovarianceMatrix);
		
		//System.out.println("temp:predict");
		//temp.print(20,2); 
		
		//P'(k) = temp*At + Q
		prioriErrorEstimateCovarianceMatrix = 
			(temp.times(transitionMatrix.transpose())).plus(processNoiseCovarianceMatrix);
		
		//System.out.println("priori:predict");
		//prioriErrorEstimateCovarianceMatrix.print(20,2); 
		
		result = predictedState;
		//predictedState.print(20,2);
		
		return result;
	}
	
	public Matrix correct(Matrix measurement) {
		Matrix result = null;
		Matrix temp1, temp2, temp3, temp4;
		
		//temp1 = H*P'(k)
		temp1 = measurementMatrix.times(prioriErrorEstimateCovarianceMatrix);
		
		//System.out.println("prioriErrorEstimateCovarianceMatrix");
		//rioriErrorEstimateCovarianceMatrix.print(20,2);
		
		//System.out.println("temp");
		//temp1.print(20,2);
		
		//temp2 = temp1*Ht +R
		temp2 = temp1.times(measurementMatrix.transpose());
		temp2 = temp2.plus(measurementNoiseCovarianceMatrix);
		
		//temp1.print(20,2);
		//temp2.print(20,2);
		
		//temp3 = inv(temp2)*temp1 = Kt(k)
		//temp3 = (temp2.inverse()).times(temp1);
		//System.out.println("Starting Inverse");
		temp3 = temp2.inverse();
		//System.out.println("Finished Inverse");
		//(temp2.times(temp3)).print(20,2);
		
		temp3 = temp3.times(temp1);
		
		// K(k)
		kalmanGainMatrix = temp3.transpose();
		
		//temp4 = z(k) - H*x'(k)
		temp4 = (measurementMatrix.times(predictedState));
		temp4 = measurement.minus(temp4);
		
		//kalmanGainMatrix.print(20,2);
		//temp4.print(20,2);
		
		//x(k) = x'(k) + K(k)*temp4
		correctedState = (kalmanGainMatrix.times(temp4));
		correctedState = predictedState.plus(correctedState);
		
		//temp4.print(20,2);
		
		//kalmanGainMatrix.times(temp4).print(20,2);
		
		//P(k) = P'(k) - K(k)*temp2
		posterioriErrorEstimateCovarianceMatrix = 
			prioriErrorEstimateCovarianceMatrix.minus((kalmanGainMatrix.times(temp2)));
		
		result = correctedState;		

		return result;
	}

	/**
	 * @return
	 */
	public Matrix getControlMatrix() {
		return controlMatrix;
	}

	/**
	 * @return
	 */
	public int getControlVectorDimensions() {
		return controlVectorDimensions;
	}

	/**
	 * @return
	 */
	public Matrix getCorrectedState() {
		return correctedState;
	}

	/**
	 * @return
	 */
	public Matrix getKalmanGainMatrix() {
		return kalmanGainMatrix;
	}

	/**
	 * @return
	 */
	public Matrix getMeasurementMatrix() {
		return measurementMatrix;
	}

	/**
	 * @return
	 */
	public Matrix getMeasurementNoiseCovarianceMatrix() {
		return measurementNoiseCovarianceMatrix;
	}

	/**
	 * @return
	 */
	public int getMeasurementVectorDimensions() {
		return measurementVectorDimensions;
	}

	/**
	 * @return
	 */
	public Matrix getPosterioriErrorEstimateCovarianceMatrix() {
		return posterioriErrorEstimateCovarianceMatrix;
	}

	/**
	 * @return
	 */
	public Matrix getPredictedState() {
		return predictedState;
	}

	/**
	 * @return
	 */
	public Matrix getPrioriErrorEstimateCovarianceMatrix() {
		return prioriErrorEstimateCovarianceMatrix;
	}

	/**
	 * @return
	 */
	public Matrix getProcessNoiseCovarianceMatrix() {
		return processNoiseCovarianceMatrix;
	}

	/**
	 * @return
	 */
	public int getStateVectorDimensions() {
		return stateVectorDimensions;
	}

	/**
	 * @return
	 */
	public Matrix getTransitionMatrix() {
		return transitionMatrix;
	}

	/**
	 * @param controlMatrix
	 */
	public void setControlMatrix(Matrix controlMatrix) {
		this.controlMatrix = controlMatrix;
	}

	/**
	 * @param controlVectorDimensions
	 */
	public void setControlVectorDimensions(int controlVectorDimensions) {
		this.controlVectorDimensions = controlVectorDimensions;
	}

	/**
	 * @param correctedState
	 */
	public void setCorrectedState(Matrix correctedState) {
		this.correctedState = correctedState;
	}

	/**
	 * @param kalmanGainMatrix
	 */
	public void setKalmanGainMatrix(Matrix kalmanGainMatrix) {
		this.kalmanGainMatrix = kalmanGainMatrix;
	}

	/**
	 * @param measurementMatrix
	 */
	public void setMeasurementMatrix(Matrix measurementMatrix) {
		this.measurementMatrix = measurementMatrix;
	}

	/**
	 * @param measurementNoiseCovarianceMatrix
	 */
	public void setMeasurementNoiseCovarianceMatrix(Matrix measurementNoiseCovarianceMatrix) {
		this.measurementNoiseCovarianceMatrix = measurementNoiseCovarianceMatrix;
	}

	/**
	 * @param measurementVectorDimensions
	 */
	public void setMeasurementVectorDimensions(int measurementVectorDimensions) {
		this.measurementVectorDimensions = measurementVectorDimensions;
	}

	/**
	 * @param posterioriErrorEstimateCovarianceMatrix
	 */
	public void setPosterioriErrorEstimateCovarianceMatrix(Matrix posterioriErrorEstimateCovarianceMatrix) {
		this.posterioriErrorEstimateCovarianceMatrix =
			posterioriErrorEstimateCovarianceMatrix;
	}

	/**
	 * @param predictedState
	 */
	public void setPredictedState(Matrix predictedState) {
		this.predictedState = predictedState;
	}

	/**
	 * @param prioriErrorEstimateCovarianceMatrix
	 */
	public void setPrioriErrorEstimateCovarianceMatrix(Matrix prioriErrorEstimateCovarianceMatrix) {
		this.prioriErrorEstimateCovarianceMatrix =
			prioriErrorEstimateCovarianceMatrix;
	}

	/**
	 * @param processNoiseCovarianceMatrix
	 */
	public void setProcessNoiseCovarianceMatrix(Matrix processNoiseCovarianceMatrix) {
		this.processNoiseCovarianceMatrix = processNoiseCovarianceMatrix;
	}

	/**
	 * @param stateVectorDimensions
	 */
	public void setStateVectorDimensions(int stateVectorDimensions) {
		this.stateVectorDimensions = stateVectorDimensions;
	}

	/**
	 * @param transitionMatrix
	 */
	public void setTransitionMatrix(Matrix transitionMatrix) {
		this.transitionMatrix = transitionMatrix;
	}

}
