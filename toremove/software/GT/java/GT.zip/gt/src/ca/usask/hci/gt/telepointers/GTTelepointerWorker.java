/*
 * Created on Oct 9, 2003
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package ca.usask.hci.gt.telepointers;

import java.awt.Point;
import java.io.IOException;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import ca.usask.hci.gt.GTChannel;
import ca.usask.hci.gt.GTController;
import ca.usask.hci.utils.GTLogger;
//import ca.usask.hci.gt.GTController;

/**
 * @author Chris Fedak
 *
 * To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
class GTTelepointerWorker implements Runnable {
	Point location;
	Point lastLocation;
	List locations;
	int notMovingTotal;
	int notMovingThreshhold;
	GTTelepointerEvent gte;
	long delay = 50;
	boolean run;
	GTChannel channel;
	GTTelepointerSender sender;
	GTLogger actualSendLog;
	double actualMeanUpdatePeriod;
	
	
	/**
	 * 
	 */
	protected GTTelepointerWorker(GTChannel channel, GTTelepointerSender sender) {
		super();
		this.channel = channel;
		run = false;
		this.sender = sender;
		
		lastLocation = null;
		notMovingTotal = 0;
		notMovingThreshhold = 10;
		String name = GTController.getInstance().getMyID();
		name = name.replaceAll(":","-");
		name = name.replaceAll("/","");
		actualSendLog = new GTLogger("actualSend-"+name+".txt");
		locations = new LinkedList();
		
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Runnable#run()
	 */
	public void run() {
		while(run) {
			if(location != null) {
				sendTelepointerEvent();
			}
			try {		
				Thread.sleep(delay);
			} catch(InterruptedException e) {
				
			}
		}
	}
	
	private void sendTelepointerEvent() {
		// check for nonmoving pointer and inform if needed
		if (location != null && lastLocation != null) {
			if (location.equals(lastLocation)) {
				try {
					notMovingTotal++;
				} catch (RuntimeException e) {
					notMovingTotal = notMovingThreshhold+1;
				}
				// need an overflow check? how long would overflow take?
			} else {
				notMovingTotal = 0;
			}
		}
		lastLocation = location;

		// JD: Currently disabled to make adaptation easier
		
//		if (notMovingTotal == notMovingThreshhold) {
			// TODO inform others that my pointer is no longer moving
			//System.out.println("pointer no longer moving");
//		}
//		if (notMovingTotal >= notMovingThreshhold) {
			// do not send if the pointer is not moving
//		} else {
			// send event
			//GTController.getInstance().getTelepointerController().showSendLoop();

			gte = new GTTelepointerEvent();
			gte.setPoint(location);
			gte.setChannel(channel);
			Iterator im;
			Point point;
			synchronized (locations) {
				im = locations.iterator();
				while(im.hasNext()) {
					point = (Point)im.next();
					gte.addIntermediatePoint(new OrderedPoint(point,0));
				}
			}
			try {
				//GTController.getInstance().sendToOthers(gte,channel);
				sender.send(gte);
				actualSendLog.logLine(String.valueOf(System.currentTimeMillis())+ "\t" +
					String.valueOf(location.getX())+ "\t" + String.valueOf(location.getY()));
				locations.clear();
				//System.out.println(System.currentTimeMillis());
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
//		}
	}
	/**
	 * @return
	 */
	public GTChannel getChannel() {
		return channel;
	}
	
	public Point[] getIntermediates() {
		return (Point[])locations.toArray();
	}

	/**
	 * @param channel
	 */
	public void setChannel(GTChannel channel) {
		this.channel = channel;
	}

	/**
	 * @return
	 */
	public long getDelay() {
		return delay;
	}

	/**
	 * @param delay
	 */
	public void setDelay(long ms) {
		this.delay = ms;
	}

	/**
	 * @return
	 */
	public Point getLocation() {
		return location;
	}

	/**
	 * @param location
	 */
	public void setLocation(Point newLocation) {
		this.location = newLocation;
		synchronized(locations) {
			this.locations.add(newLocation);
		}
	}
	
	protected void setRun(boolean run) {
		this.run = run;
	}
	
	protected boolean getRun(){
		return run;
	}

}
