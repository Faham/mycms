/*
 * Created on Dec 2, 2003
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package ca.usask.hci.network;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InvalidClassException;
import java.io.NotSerializableException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.StreamCorruptedException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.Socket;
import java.net.SocketException;
import java.net.UnknownHostException;

import javax.swing.event.EventListenerList;

import ca.usask.hci.gt.GTController;
import ca.usask.hci.gt.GTEvent;
import ca.usask.hci.gt.telepointers.GTHighPerformanceTelepointerController;
import ca.usask.hci.network.qos.GTQoSProperties;
import ca.usask.hci.utils.Messenger;

/**
 * @author Chris Fedak
 *
 */
public class GTNetwork {
	Socket TCPSocketToServer;
	DatagramSocket UDPsocket;
	boolean connectedToServer = false;
	EventListenerList listenerList;
	ObjectOutputStream out;
	TCPNetworkReceiver tcpReceiver;
	UDPNetworkReceiver udpReceiver;
	GTNetworkEvent netEvent;
	
	
	/**
	 * 
	 */
	public GTNetwork() {
		super();
		netEvent = new GTNetworkEvent();
		listenerList = new EventListenerList();
	}
	
	public InetAddress getLocalAddress() {
		return TCPSocketToServer.getLocalAddress();
	}
	
	public InetAddress getHostAddress() {
		return TCPSocketToServer.getInetAddress();
	}
	
	public int getLocalTCPPort() {
		return TCPSocketToServer.getLocalPort();
	}
	
	public int getLocalUDPPort() {
		return UDPsocket.getLocalPort();
	}
	
	public boolean connect(String host, int port) {
		TCPSocketToServer = null;
		connectedToServer = true;
		try {
			TCPSocketToServer = new Socket(host, port);
		} catch (UnknownHostException e2) {
			Messenger.getInstance().error("Unknown Host:" + host, this);
			Messenger.getInstance().error(e2.getMessage());
			e2.printStackTrace();
			connectedToServer = false;
		} catch (IOException e2) {
			Messenger.getInstance().error("IOException connection to " + host, this);
			Messenger.getInstance().error(e2.getMessage());
			e2.printStackTrace();
			connectedToServer = false;
		}
		if (TCPSocketToServer != null) {
			try {
				TCPSocketToServer.setTcpNoDelay(true);
			} catch (SocketException e2) {
				Messenger.getInstance().error("Could not set TCPNoDelay");
				Messenger.getInstance().error(e2.getMessage());
				e2.printStackTrace();
				connectedToServer = false;
			}
			try {
				out = new ObjectOutputStream(TCPSocketToServer.getOutputStream());
			} catch (IOException e2) {
				Messenger.getInstance().error("Could not get output stream");
				Messenger.getInstance().error(e2.getMessage());
				e2.printStackTrace();
				connectedToServer = false;
			}
			tcpReceiver = new TCPNetworkReceiver(TCPSocketToServer);
			udpReceiver = new UDPNetworkReceiver();
			new Thread(tcpReceiver).start();
			new Thread(udpReceiver).start();
			fireConnected(
				TCPSocketToServer.getInetAddress().getHostAddress(),
				TCPSocketToServer.getPort());
		}
		return connectedToServer;
	}

	public void disconnect() throws IOException {
		fireDisconnected(
				TCPSocketToServer.getInetAddress().getHostAddress(),
				TCPSocketToServer.getPort()
				);
		TCPSocketToServer.close();
		connectedToServer = false; 
	}
	
	

	private synchronized void sendViaTCP(GTEvent gte) {
		//sends via TCP
		if(!connectedToServer) return;
			//	send to server
			try {
				out.writeObject(gte);
				out.flush();
				fireObjectSent(gte,
					TCPSocketToServer.getInetAddress().getHostAddress(),
					TCPSocketToServer.getPort()
				);
			} catch (InvalidClassException e) {
				Messenger.getInstance().error(e.toString(), this);
			} catch (NotSerializableException e) {
				Messenger.getInstance().error(e.toString(), this);
			} catch (IOException e) {
				Messenger.getInstance().error("GTController couldn't write to socket",this);
				e.printStackTrace();
			}
	}
	
	private synchronized void sendViaUDP(GTEvent gte) throws IOException {
		if(!connectedToServer) return;
		DatagramPacket outgoing;
		byte[] outBuf;
		outBuf =  getBytes(gte);
		outgoing = new DatagramPacket(outBuf, outBuf.length, TCPSocketToServer.getInetAddress(), 4499);
		UDPsocket.send(outgoing);
	}
	
	public void send(GTEvent gte, GTQoSProperties gtp) throws IOException {
		//sends according to method determined via QoS Scheduler
		if(!connectedToServer) return;
		if(gtp.getReliability() < .5 && gtp.getLatency() >.5) {
			sendViaUDP(gte);
		} else {
			sendViaTCP(gte);
		}
		
		
	}
	
	public void addNetworkListener(GTNetworkListener l) {
		 listenerList.add(GTNetworkListener.class, l);
	}

	public void removeNetworkListener(GTNetworkListener l) {
		listenerList.remove(GTNetworkListener.class, l);
	}

	/**
	 * @param ge
	 */
	private void fireObjectReceived(GTEvent ge, String host, int port) {
		Object[] listeners = listenerList.getListenerList();
		// Process the listeners last to first, notifying
		// those that are interested in this event
		for (int i = listeners.length-2; i>=0; i-=2) {
			if (listeners[i]==GTNetworkListener.class) {
				netEvent.data = ge;
				netEvent.host = host;
				netEvent.port = port;
				((GTNetworkListener)listeners[i+1]).objectReceived(netEvent);
			}
		}
	}

	/**
	 * @param gte
	 * @param string
	 * @param i
	 */
	private void fireObjectSent(GTEvent gte, String host, int port) {
		Object[] listeners = listenerList.getListenerList();
		// Process the listeners last to first, notifying
		// those that are interested in this event
		for (int i = listeners.length-2; i>=0; i-=2) {
			if (listeners[i]==GTNetworkListener.class) {
				netEvent.data = gte;
				netEvent.host = host;
				netEvent.port = port;
				((GTNetworkListener)listeners[i+1]).objectSent(netEvent);
			}
		}
	}
	
	/**
	 * @param string
	 * @param i
	 */
	private void fireConnected(String host, int port) {
		Object[] listeners = listenerList.getListenerList();
		// Process the listeners last to first, notifying
		// those that are interested in this event
		for (int i = listeners.length-2; i>=0; i-=2) {
			if (listeners[i]==GTNetworkListener.class) {
				netEvent.data = null;
				netEvent.host = host;
				netEvent.port = port;
				((GTNetworkListener)listeners[i+1]).networkConnected(netEvent);
			}
		}
		
	}
	
	/**
	 * @param string
	 * @param i
	 */
	private void fireDisconnected(String host, int port) {
		Object[] listeners = listenerList.getListenerList();
		// Process the listeners last to first, notifying
		// those that are interested in this event
		for (int i = listeners.length-2; i>=0; i-=2) {
			if (listeners[i]==GTNetworkListener.class) {
				netEvent.data = null;
				netEvent.host = host;
				netEvent.port = port;
				((GTNetworkListener)listeners[i+1]).networkDisconnected(netEvent);
			}
		}
		
	}
	
	public static byte[] getBytes(Object obj) {
		byte[] data = null;
		try {
			ByteArrayOutputStream bos = new ByteArrayOutputStream();
			ObjectOutputStream oos = new ObjectOutputStream(bos);
			oos.writeObject(obj);
			oos.flush();
			oos.close();
			bos.close();
			data = bos.toByteArray();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return data;
	}
	
	public static Object getObject(byte[] bytes) throws StreamCorruptedException, IOException {
		Object extracted= null;
		//ByteArrayOutputStream bos = new ByteArrayOutputStream();
			
		ObjectInputStream ois;
		try {
			ois = new ObjectInputStream(new ByteArrayInputStream(bytes));
			extracted = ois.readObject();
		} catch (StreamCorruptedException se) {
			throw se;
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return extracted;
	}

	
	private class TCPNetworkReceiver implements Runnable {
		private Socket sock;
		private ObjectInputStream in;
		
		//Constructor
		public TCPNetworkReceiver(Socket s) {
			sock = s;
			Messenger.getInstance().message(
				"reciever socket connected to: " + sock.getInetAddress().toString(), 
				this);
			Messenger.getInstance().message(
				"reciever socket connected on: " + sock.getPort(), 
				this);
			Messenger.getInstance().message(
				"reciever socket local on: " + sock.getLocalPort(), 
				this);
			try {
				in = new ObjectInputStream(sock.getInputStream());
			} catch (IOException e) {
				Messenger.getInstance().message(
					"Couldn't get I/O for the connection to the server", 
					this);
				System.exit(1);
			}
		}
		 
		/* (non-Javadoc)
				 * @see java.lang.Runnable#run()
		*/
		public void run() {
			GTEvent ge = null;
			while (connectedToServer) {
				try {
					ge = (GTEvent)in.readObject();
				} catch (IOException e) {
					System.err.println("I/O error reading from server");
					System.err.println(e.getMessage());
					System.exit(0);
				} catch (ClassNotFoundException e) {
					System.err.println("could not find class GTEvent");
					System.exit(0);
				}
				// got an event, relay it
				if (ge != null) {
					fireObjectReceived(ge, 
						TCPSocketToServer.getInetAddress().getHostAddress(),
						TCPSocketToServer.getPort());
				}
			}
		}
	}
	
	private class UDPNetworkReceiver implements Runnable {
		
		byte[] buf;
		int buffersize = 1024*100;
		DatagramPacket incomingPacket;
		Object incomingObject;
		/* (non-Javadoc)
		 * @see java.lang.Runnable#run()
		 */
		public UDPNetworkReceiver() {
			try {
				UDPsocket = new DatagramSocket();
				buf = new byte[buffersize];
			} catch (SocketException e) {
				e.printStackTrace();
			}
		}
		 
		public void run() {
			while(connectedToServer){
				incomingPacket = new DatagramPacket(buf, buf.length);
				try {
					UDPsocket.receive(incomingPacket);
					incomingObject = getObject(incomingPacket.getData());
					fireObjectReceived((GTEvent)incomingObject,
						incomingPacket.getAddress().getHostAddress(),
						incomingPacket.getPort()
						);
				} catch (StreamCorruptedException scee) {
					//got a Non-standard packet
					
					try {
						((GTHighPerformanceTelepointerController)GTController.getInstance().getTelepointerController()).receiveTelepointer(
							incomingPacket.getData(),incomingPacket.getLength()
							);
					} catch (Exception e) {
						
					}

				} catch (IOException e) {
 					e.printStackTrace();
				} catch (ClassCastException cce) {
				
				}
			} 			
		}
		
		
	}

}
