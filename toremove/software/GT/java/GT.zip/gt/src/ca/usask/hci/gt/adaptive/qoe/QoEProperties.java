/*
 * Created on Mar 15, 2004
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package ca.usask.hci.gt.adaptive.qoe;

import ca.usask.hci.utils.Range;

/**
 * @author Chris Fedak
 *
 */
public class QoEProperties {
	Range smoothness;
	
	Range accuracy;
	
	Range timeliness;
	
	
	/**
	 * 
	 */
	public QoEProperties() {
		super();
		smoothness = new Range(0, 50);
		accuracy = new Range(5, 30);
		timeliness = new Range(100,600);
		// TODO Auto-generated constructor stub
	}
	/**
	 * @return Returns the accuracy.
	 */
	public Range getAccuracy() {
		return accuracy;
	}
	/**
	 * @param accuracy The accuracy to set.
	 */
	public void setAccuracy(Range accuracy) {
		this.accuracy = accuracy;
	}
	/**
	 * @return Returns the smoothness.
	 */
	public Range getSmoothness() {
		return smoothness;
	}
	/**
	 * @param smoothness The smoothness to set.
	 */
	public void setSmoothness(Range smoothness) {
		this.smoothness = smoothness;
	}
	/**
	 * @return Returns the timeliness.
	 */
	public Range getTimeliness() {
		return timeliness;
	}
	/**
	 * @param timeliness The timeliness to set.
	 */
	public void setTimeliness(Range timeliness) {
		this.timeliness = timeliness;
	}
}
