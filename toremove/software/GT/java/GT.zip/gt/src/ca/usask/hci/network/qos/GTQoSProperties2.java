/*
 * Created on Dec 1, 2003
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package ca.usask.hci.network.qos;

import java.io.Serializable;

/**
 * @author Jeff Dyck
 *
 */
public class GTQoSProperties2 implements Serializable {

	/**
	 * In milliseconds - the statistical min and max
	 */
	public static final int MIN_LATENCY = 100;
	public static final int MAX_LATENCY = 500;

	/**
	 * In % messages received.
	 */
	public static final int MIN_RELIABILITY = 94;
	public static final int MAX_RELIABILITY = 96;

	/**
	 * In milliseconds.
	 */
	public static final int MIN_JITTER = 50;
	public static final int MAX_JITTER = 500;

	/**
	 * In messages/second.
	 */
	public static final int MIN_RATE= 10;
	public static final int MAX_RATE= 30;
	
	
	/**
	 * 
	 */
	public GTQoSProperties2() {
		super();
	}

}
