/*
 * Created on Jan 20, 2004
 */
package ca.usask.hci.gt.adaptive;

import ca.usask.hci.gt.GTEvent;

/**
 * @author jdd118
 *
 */
public class GTAdaptiveAction extends GTEvent {

	public static final int DECREASE_FEC = 0;
	public static final int INCREASE_FEC = 1;
	public static final int DECREASE_RATE = 2;
	public static final int INCREASE_RATE = 3;
	
	private int action;
	private String clientID;
	
	public GTAdaptiveAction(String clientID, int action) {		
		this.action = action;
		
		setMessageName(String.valueOf(action));
		this.setToUserID(clientID);
	}	

	public int getAction() {
		return action;
	}

	public String toString() {
		String message = "clientID=" + clientID + "\ttype=" + action;
		return message;
	}
}
