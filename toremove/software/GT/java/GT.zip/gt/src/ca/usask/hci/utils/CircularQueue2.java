/*
 * Created on Mar 1, 2004
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package ca.usask.hci.utils;

/**
 * @author Chris Fedak
 *
 */
public class CircularQueue2 {
	Object[] queue;
	int start;
	int end;
	int capacity;
	int size;
	/**
	 * 
	 */
	public CircularQueue2() {
		super();
		capacity = 100;
		queue = new Object[capacity];
		start = 0; end = 0;
		// TODO Auto-generated constructor stub
	}
	
	public CircularQueue2(int capacity) {
		super();
		this.capacity = capacity;
		queue = new Object[capacity];
		start = 0; end = 0;
		// TODO Auto-generated constructor stub
	}
	
	private int increment(int index) {
		int ret = index;
		ret++;
		if(ret > capacity-1) ret = 0;
		return ret;
	}
	
	public void push(Object o) {
		queue[start] = o;
		start = increment(start);
		if(size < capacity) size++;
		if(size == capacity) end++;
	}
	
	public Object get(int index) {
		if(index < 0 || index > capacity-1) return null;
		return queue[index];
	}
	
	public void put(int index, Object o) {
		if(index < 0 || index > capacity-1) return;
		if(size < capacity) size++;
		queue[index] = o;
	}
	
	public int size() {
		return size;
	}
}
