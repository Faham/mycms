/*
 * Created on Dec 4, 2003
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package ca.usask.hci.network;


/**
 * @author Chris Fedak
 *
 */
public class GTNetworkEvent {
	String host;
	int port;
	Object data;
	
	public GTNetworkEvent() {}
	/**
	 * @return
	 */
	public Object getData() {
		return data;
	}

	/**
	 * @return
	 */
	public String getHost() {
		return host;
	}

	/**
	 * @return
	 */
	public int getPort() {
		return port;
	}

}
