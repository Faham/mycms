/*
 * Created on Jan 12, 2004
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package ca.usask.hci.gt.telepointers;

import java.io.IOException;
import java.io.Serializable;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import ca.usask.hci.gt.GTChannel;
import ca.usask.hci.gt.GTController;
import ca.usask.hci.gt.GTEvent;
import ca.usask.hci.gt.Person;
import ca.usask.hci.gt.adaptive.GTHighPerformanceTelepointerAdaptiveControl;
import ca.usask.hci.gt.adaptive.qoe.GTQoEAdaptiveControl;
import ca.usask.hci.gt.adaptive.qoe.QoEProperties;
import ca.usask.hci.utils.Messenger;

/**
 * @author Chris Fedak
 *
 */
public class GTHighPerformanceTelepointerController extends GTTelepointerController {
	private HPControlInfo hpci;
	DatagramSocket socket;
	private Map adaptiveControls;
	int testI = 0;
	boolean adaptToNetwork;
	boolean useAFEC = true;
	private QoEProperties qoeProps;
	private boolean adaptToExperience;
	private GTQoEAdaptiveControl qecontrol;
	
	/**
	 * 
	 */
	public GTHighPerformanceTelepointerController(GTChannel gtc) throws SocketException {
		super();
		System.out.println("*********** GTHighPerformanceTelepointerController being created: " + this.toString());
		adaptiveControls = Collections.synchronizedMap(new HashMap());
		GTEvent e;
		Serializable[] updateData;
		
		adaptToNetwork = true;
		adaptToExperience = true;
		
		qoeProps = new QoEProperties();
		qecontrol = new GTQoEAdaptiveControl();
		
		hpci = new HPControlInfo();
		setFECLevel(3);
		socket = new DatagramSocket();
		gtw = new GTTelepointerWorker(gtc, new GTHighPerformanceTelepointerSender(hpci, socket));
		
		e = new GTEvent();
		e.sendTarget = GTEvent.TO_SERVER;
		e.setMessageName("GT_HP_PORT");
		updateData = new Serializable[] { new Integer(socket.getLocalPort()) };
		e.setData(updateData);
		GTController.getInstance().sendToServer(e, "GT_SESSION");
		
		new Thread(new HPDatagramWorker()).start();
		new Thread(new AdaptiveControlUpdater()).start();
		

	}
	/**
	 * Sets number of redundant points that will be sent to
	 * maintain reliability
	 * 
	 * @param fec
	 */
	public void setFECLevel(int fec) {
		hpci.fec = fec;
	}
	
	/**
	 * 
	 * @return number of redundant points currently being sent in each telepointer message
	 */
	public int getFECLevel() {
		return hpci.fec;
	}
	
	/**
	 * 
	 * @return the UDP point used for HPTelepointers locally
	 */
	
	public int getUDPPort() {
		return socket.getLocalPort();
	}
	/**
	 * 
	 * @param telepointerPacket
	 * @param length
	 */
	public void receiveTelepointer(byte[] telepointerPacket, int length) {
		try {
			GTTelepointerEvent gte = null;
			if(GTHighPerformanceTelepointerSender.USE_MULTIPLEXING) 
				gte = GTHighPerformanceTelepointerSender.unpackWithIntermediates(telepointerPacket);
			else
				gte = GTHighPerformanceTelepointerSender.unpack(telepointerPacket);
			
			
			if(gte != null && gte.getSenderID() != null) {
				//add to History
				if(testI ==50) {

						
					testI = 0;
				} else {
					testI++;
				}
				addToHistory(gte);
				//add adaptive controller if neccessary
				if(adaptiveControls.get(gte.getSenderID())==null) {
					synchronized (adaptiveControls) {
						adaptiveControls.put(gte.getSenderID(), new GTHighPerformanceTelepointerAdaptiveControl(gte.getSenderID()));
					}
				}
			}
		} catch (IOException e) {
			Messenger.getInstance().error("bad packet: " + e.getMessage());
			Person[] peep = GTController.getInstance().getPeople();
			for(int test=0;test<peep.length;test++) {
				Messenger.getInstance().message(peep[test].getClientID() + ","+ String.valueOf(peep[test].getShortID()));
			}
		}
	}
	/**
	 * @return Returns the adaptToNetwork.
	 */
	public boolean isAdaptToNetwork() {
		return adaptToNetwork;
	}
	/**
	 * @param adaptToNetwork The adaptToNetwork to set.
	 */
	public void setAdaptToNetwork(boolean adaptToNetwork) {
		this.adaptToNetwork = adaptToNetwork;
	}
	
	public void setUseAFEC(boolean useAFEC) {
		this.useAFEC = useAFEC;
	}

	
	private class HPDatagramWorker implements Runnable {
		DatagramPacket packet;
		byte[] buf;
		/* (non-Javadoc)
		 * @see java.lang.Runnable#run()
		 */
		public void run() {
			// TODO Auto-generated method stub	
			while(true) {
				buf = new byte[300];
				packet = new DatagramPacket(buf, buf.length);
				try {
					socket.receive(packet);
					receiveTelepointer(packet.getData(), packet.getLength());
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	} 
	
	private class AdaptiveControlUpdater implements Runnable {



		/* (non-Javadoc)
		 * @see java.lang.Runnable#run()
		 */
		public void run() {
			Iterator i;
			Map.Entry entry;
			GTHighPerformanceTelepointerAdaptiveControl control;
			ClientTelepointerHistory cth;
			// TODO Auto-generated method stub
			while(true) {
				if(adaptToNetwork) {
					i = adaptiveControls.entrySet().iterator();
					synchronized (adaptiveControls) {
						while(i.hasNext()) {
							entry = (Map.Entry)i.next();
							control = (GTHighPerformanceTelepointerAdaptiveControl)entry.getValue();
							cth = (ClientTelepointerHistory)telepointers.get((String)entry.getKey());
							if(cth.id != GTController.getInstance().getMyID()) {
								control.adaptiveUpdate(
										cth.extendedHistory(), //telepointer history
										(GTController.getInstance().getPingManager().getPingHistory((String)entry.getKey())), 
										useAFEC
								);
							}
						}
					}
				}
				if(adaptToExperience) {
					Collection tcl = telepointers.values();
					synchronized(telepointers) {
						if(tcl!=null)
							qecontrol.adaptiveUpdate(tcl, qoeProps);
					}
				}
				try {
					Thread.sleep(15000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		
	}
	
	

	/**
	 * @return Returns the qoeProps.
	 */
	public QoEProperties getQoeProps() {
		return qoeProps;
	}
	/**
	 * @param qoeProps The qoeProps to set.
	 */
	public void setQoeProps(QoEProperties qoeProps) {
		this.qoeProps = qoeProps;
	}
	/**
	 * @return Returns the adaptToExperience.
	 */
	public boolean isAdaptToExperience() {
		return adaptToExperience;
	}
	/**
	 * @param adaptToExperience The adaptToExperience to set.
	 */
	public void setAdaptToExperience(boolean adaptToExperience) {
		this.adaptToExperience = adaptToExperience;
	}
}
