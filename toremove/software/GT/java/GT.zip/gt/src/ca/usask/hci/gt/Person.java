package ca.usask.hci.gt;

import java.awt.Color;
import java.io.Serializable;

/**
	Person:  A data class that represents a Person in the current
		GT application
	
	@author Carl Gutwin
	@author Chris Fedak
	
	@see GTController
*/
public class Person  implements Serializable {
  String name;
  Color color;
  short shortID;
  String clientID;

  /**
  	*	Constructor
  	*
  	* @param	n	The Name of this Person
  	* @param	c	The Color to represent this person
  	*
  */
  public Person (String n, Color c) {
    name = n;
    color = c;
    shortID = -1;
  }
	/**
	 * @return
	 */
	public Color getColor() {
		return color;
	}

	/**
	 * @return
	 */
	public String getName() {
		return name;
	}
	
	public boolean equals (Person p) {
		if (this.name.equals(p.getName()) && this.color.equals(p.getColor())) {
			return true;
		} else {
			return false;
		}	
	}
	
	public String toString() {
		return name+"|"+String.valueOf(shortID);
	}

	/**
	 * @return
	 */
	public short getShortID() {
		return shortID;
	}

	/**
	 * @param shortID
	 */
	public void setShortID(short shortID) {
		this.shortID = shortID;
	}

	/**
	 * @return
	 */
	public String getClientID() {
		return clientID;
	}

	/**
	 * @param clientID
	 */
	public void setClientID(String clientID) {
		this.clientID = clientID;
	}

}
