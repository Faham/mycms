/*
 * Created on Mar 15, 2004
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package ca.usask.hci.gt.adaptive.qoe;

import java.util.Collection;
import java.util.Iterator;

import ca.usask.hci.gt.GTController;
import ca.usask.hci.gt.telepointers.ClientTelepointerHistory;

/**
 * @author Chris Fedak
 *
 */
public class GTQoEAdaptiveControl {
	/**
	 * 
	 */
	public GTQoEAdaptiveControl() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public void adaptiveUpdate(Collection clients, QoEProperties qoeProps) {
		double smoothness = 0;
		double accuracy= 0;
		double timeliness =0;
		double totalSmoothness =0;
		
		ClientTelepointerHistory cth;
		Iterator i;
		i = clients.iterator();
		
		while (i.hasNext()) {
			cth = (ClientTelepointerHistory)i.next();
			totalSmoothness+= cth.getSmoothness();
			accuracy = cth.getAccuracy();
			timeliness = cth.getTimeliness();
			if(accuracy < qoeProps.getAccuracy().getMin()) {
				if(timeliness > qoeProps.getTimeliness().getMax() ) {
					cth.setPredictAhead(cth.getPredictAhead()+10);
					System.out.println("QOE adapter too accurate reclaiming latency\n" +
							"  Setting predict ahead to " + String.valueOf(cth.getPredictAhead()) +"ms");
				}
			} else if(accuracy > qoeProps.getSmoothness().getMax()){
				cth.setPredictAhead(cth.getPredictAhead()-10);
				System.out.println("QOE adapter not accurate enough \n" +
						"  Setting predict ahead to " + String.valueOf(cth.getPredictAhead()) +"ms");
			}  
			
			if(timeliness < qoeProps.getTimeliness().getMin() ) {
				cth.setPredictAhead(cth.getPredictAhead()-10);
				System.out.println("QOE adapter too timely\n" +
						"  Setting predict ahead to " + String.valueOf(cth.getPredictAhead()) +"ms");
			} else if(timeliness > qoeProps.getTimeliness().getMax() ) {
				cth.setPredictAhead(cth.getPredictAhead()+10);
				System.out.println("QOE adapter not timely enough\n" +
					"  Setting predict ahead to " + String.valueOf(cth.getPredictAhead()) +"ms");
			}
		}
		
		smoothness = totalSmoothness/clients.size();
		
		if(smoothness < qoeProps.getSmoothness().getMin()) {
			GTController.getInstance().getTelepointerController().setDistributionPeriod(Math.max(
					GTController.getInstance().getTelepointerController().getDistributionPeriod()+5, 10));
			System.out.println("QOE adapter too smooth\n" +
					"  Setting refresh period to " + String.valueOf(
						GTController.getInstance().getTelepointerController().getDistributionPeriod()) +"ms");
		} else if(smoothness > qoeProps.getSmoothness().getMax()){
					GTController.getInstance().getTelepointerController().setDistributionPeriod(
					 GTController.getInstance().getTelepointerController().getDistributionPeriod()-5);
					System.out.println("QOE adapter not smooth enough\n" +
							"  Setting refresh period to " + String.valueOf(
								GTController.getInstance().getTelepointerController().getDistributionPeriod()) +"ms");
		}
	}
}
