package ca.usask.hci.gt;

import java.io.*;
import ca.usask.hci.network.GTNetwork;
import ca.usask.hci.network.GTNetworkEvent;
import ca.usask.hci.network.GTNetworkListener;
/**
	GTReciever:  Thread that recieves and dispatches GTEvents.
	
	@author Carl Gutwin
	@author Chris Fedak
*/
public class GTReceiver implements GTNetworkListener {
	private GTController gtc;
	private GTNetwork net;
	private ObjectInputStream in;

	/**
		Constructor.
	
		@param	g	The GTController instance that this receiver should work with.
		@param	s	The socket to monitor for GTController Events
		@see Socket
		@see GTController
	*/
	public GTReceiver(GTController g, GTNetwork net) {
		gtc = g;
		this.net = net;
		net.addNetworkListener(this);
    
	}

	/* (non-Javadoc)
	 * @see ca.usask.hci.network.GTNetworkListener#objectReceived(ca.usask.hci.network.GTNetworkEvent)
	 */
	public void objectReceived(GTNetworkEvent e) {
		// TODO Auto-generated method stub
		gtc.dispatchEvent((GTEvent)e.getData());
	}

	/* (non-Javadoc)
	 * @see ca.usask.hci.network.GTNetworkListener#networkConnected(ca.usask.hci.network.GTNetworkEvent)
	 */
	public void networkConnected(GTNetworkEvent e) {
		// TODO Auto-generated method stub
		
	}

	/* (non-Javadoc)
	 * @see ca.usask.hci.network.GTNetworkListener#networkDisconnected(ca.usask.hci.network.GTNetworkEvent)
	 */
	public void networkDisconnected(GTNetworkEvent e) {
		// TODO Auto-generated method stub
		
	}

	/* (non-Javadoc)
	 * @see ca.usask.hci.network.GTNetworkListener#objectSent(ca.usask.hci.network.GTNetworkEvent)
	 */
	public void objectSent(GTNetworkEvent e) {
		// TODO Auto-generated method stub
		
	}
}
