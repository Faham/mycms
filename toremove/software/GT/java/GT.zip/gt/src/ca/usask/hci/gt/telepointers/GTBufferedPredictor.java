/*
 * Created on Jan 27, 2004
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package ca.usask.hci.gt.telepointers;

import java.awt.Point;
import java.util.Iterator;
import java.util.List;

/**
 * Simulates Buffering by taking telepointers from a specified time in the past rather than
 * predicting.
 * 
 * @author Chris Fedak
 *
 * To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
public class GTBufferedPredictor implements GTTelepointerPredictor {
	private long bufferTime;
		
	/**
	 * 
	 * @param bufferTime how many ms should be buffered before display
	 */
	public GTBufferedPredictor (long bufferTime) {
		this.bufferTime = bufferTime;
	}
	
	/* (non-Javadoc)
	 * @see ca.usask.hci.gt.telepointers.GTTelepointerPredictor#predict(ca.usask.hci.gt.telepointers.ClientTelepointerHistory, long)
	 */
	public PredictedPoint predict(ClientTelepointerHistory cth, long time) {
		// TODO Auto-generated method stub
		List history = cth.history();
		long targetTime = time - bufferTime;
		Iterator i = history.iterator();
		OrderedPoint candidate = null;
		while(i.hasNext()) {
			candidate = (OrderedPoint)i.next();
			if(targetTime < candidate.getTimestamp()) {
				break;
			}
		}
		if(candidate == null)
			return new PredictedPoint(0,0);
		
		return new PredictedPoint(candidate.getX(), candidate.getY(), targetTime * -1);
	}

	/* (non-Javadoc)
	 * @see ca.usask.hci.gt.telepointers.GTTelepointerPredictor#latencyAdjustment()
	 */
	public int latencyAdjustment() {
		// TODO Auto-generated method stub
		return (int)(-1*bufferTime);
	}

	/* (non-Javadoc)
	 * @see ca.usask.hci.gt.telepointers.GTTelepointerPredictor#correct(java.awt.Point)
	 */
	public void correct(Point p) {
		// TODO Auto-generated method stub
		
	}

}
