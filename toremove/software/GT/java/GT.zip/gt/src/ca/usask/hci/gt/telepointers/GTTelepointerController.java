/*
 * Created on Oct 10, 2003
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package ca.usask.hci.gt.telepointers;

import java.awt.Point;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import ca.usask.hci.gt.GTController;
import ca.usask.hci.gt.GTPersonEvent;
import ca.usask.hci.gt.GTSessionListener;
import ca.usask.hci.gt.Person;
import ca.usask.hci.utils.Messenger;
//import ca.usask.hci.utils.Messenger;

/**
 * A Controller class for telepointer events.  Allows the system to 
 * change the telepointer location, and provides event notifications
 * about remote telepointer changes.
 * 
 * You must get the current instance of this object by calling
 * GTTelepointerController gtc = GTController.getInstance().getTelepointerController();
 * 
 * @author Chris Fedak
 *
 * 
 */
public abstract class GTTelepointerController implements GTSessionListener {
	protected GTTelepointerWorker gtw;
	protected List telepointerListeners;
	protected Map telepointers;
	private GTDefaultTelepointerHandler gtdth;
//	protected long distributionPeriod = 40;
	protected long distributionPeriod = 10;
	//protected Thread  distThread = null;
	int testI = 0;
	GTTelepointerPredictor defaultPredictor = new GTDefaultPredictor();
	boolean run = true;
	double meanRelayRate;
	
	
	/**
	 *	
	 */
	public GTTelepointerController() {
		telepointerListeners = Collections.synchronizedList(new LinkedList());
		telepointers = Collections.synchronizedMap(new HashMap());
		//telepointers = new HashMap();
		//Messenger.getInstance().message("test: " + GTController.getInstance().getMyID());
		telepointers.put(GTController.getInstance().getMyID(), new ClientTelepointerHistory(GTController.getInstance().getMyID(), (short)128, defaultPredictor));
		new Thread(new TelepointerEventDistributor()).start();
	}
	
	public GTTelepointerSender getSender() {
		return gtw.sender;
	}
	
	/**
	 * Allows the controller to send Telepointer events to the groupware system.
	 */
	public void startSendingTelepointers() {
		if(!gtw.getRun()) {
			gtw.setRun(true);
			new Thread(gtw).start();
		}
	}
	public void setDistributionPeriod(int newP) {
	    distributionPeriod = newP;
	}
	//gets the telepointerHistory for this cleint
	public List getLocalTelepointerHistory() {
		ArrayList result = null;
		ClientTelepointerHistory cth = (ClientTelepointerHistory)telepointers.get(GTController.getInstance().getMyID());
		result.addAll(cth.history());
		return (List)result;
	}
	
//	public void showSend(int x, int y) {
//		if (gtdth != null) {
//			gtdth.setSendLocation(x,y);
//		}
//	}
//	
	public void showSendLoop() {
		if (gtdth != null) {
			gtdth.setSendLoop();
			//System.out.println("in showSendLoop, gtdth is " + gtdth.toString());
		} else {
			System.out.println("\tin showSendLoop, gtdth is null");
		}
	}
	
	synchronized public void addToHistory(GTTelepointerEvent e) {
		ClientTelepointerHistory cth =null;
		synchronized (telepointers) {
			if (telepointers.get(e.getSenderID()) == null
				&& e.getSenderID() != null) {
				telepointers.put(
					e.getSenderID(),
					new ClientTelepointerHistory(e.getSenderID(), (short) 128, defaultPredictor));
				System.out.println("\tadding new telepointer: " + e.getSenderID());
			}

			if (e.getSenderID() == null) {
				System.err.println("null sender ID in addToHistory");
			} else {
				cth =
					(ClientTelepointerHistory) telepointers.get(
						e.getSenderID());
				synchronized (cth) {
					if (cth != null) {
						cth.setLastFec(e.getFECList().size()-1);
						cth.addAll(e.getFECList());
					} else {
						System.out.println("cth is null");
					}
				}
			}
		}
	}
		
	protected ClientTelepointerHistory getClientTelepointerHistory(String clientID) {
		ClientTelepointerHistory cth = (ClientTelepointerHistory)telepointers.get(clientID);
		return cth;
	}
	
	public void setPredictor(String clientID, GTTelepointerPredictor p) {
		ClientTelepointerHistory cth = (ClientTelepointerHistory)telepointers.get(clientID);
		cth.setPredictor(p);
	}
	
	public void setPredictor(GTTelepointerPredictor p) {
		Person[] people = GTController.getInstance().getPeople();
		ClientTelepointerHistory cth;
		defaultPredictor = p;
		for(int i = 0; i < people.length;i++) {
			cth = (ClientTelepointerHistory)telepointers.get(people[i].getClientID());
			if(cth!=null) {
				cth.setPredictor(p);
			}
		}
	}
	
	
	public List getFecList(int fec, String clientID) {
		ClientTelepointerHistory cth = (ClientTelepointerHistory)telepointers.get(clientID);
		if(cth != null) {
			return cth.fecHistory(fec);
		} else if( clientID.equals(GTController.getInstance().getMyID())) {
			synchronized (telepointers) {
				telepointers.put(GTController.getInstance().getMyID(), new ClientTelepointerHistory(GTController.getInstance().getMyID(), (short)128, defaultPredictor));
			}	
		}
		return new LinkedList();
	}
	
	//adds a point to the Local History
	public void addHistoryPoint(Point p) {
		ClientTelepointerHistory cth = (ClientTelepointerHistory)telepointers.get(GTController.getInstance().getMyID());
		cth.addRecentPoint(p);
	}
	
	
	/**
	 * Adds a listener to the controller.  The listener will now be informed of telepointer events
	 * 
	 * @param gt	The listener that wishes to be notified.
	 */
	public void addTelepointerListener(GTTelepointerListener gt) {

		synchronized (telepointerListeners) {
			telepointerListeners.add(gt);
		}
	}
	
	/**
	 * @param gt the Listener that no longer wishes to receive notification of remote telepointer 
	 * events. 
	 */
	public void removeTelepointerListener(GTTelepointerListener gt) {
		synchronized (telepointerListeners) {
			telepointerListeners.remove(gt);
		}
	}
	
	/**
	 * Stops sending telepointer events to the groupware system
	 */
	public void stopSendingTelepointers() {
		gtw.setRun(false);
	}

	/**
	 * @param p a point representing the local Telepointer position.
	 */
	public void setTelepointer(Point p) {
		gtw.setLocation(p);
	}
	
	/**
	 * @return A collection of GTTelepointerController.ClientPoint items that represents the
	 * current known position of remote telepointers by clientId.
	 */
	public Collection getCurrentPointers() {
		LinkedList list = new LinkedList();
		Iterator i = telepointers.values().iterator();
		synchronized (telepointers) {
			ClientPoint cp;
			ClientTelepointerHistory cth;
			while(i.hasNext()) {
				cth = (ClientTelepointerHistory)i.next();
				cp = new ClientPoint(cth.id, cth.getPredictedPoint(System.currentTimeMillis())); 
				list.add(cp);
			}
		}
		return list;
	}
	
	/**
	 * @param clientId the id of the client whose telepointer you wish to retrieve
	 * @return	a Point representing the last known position of this clients telepointer.
	 */
	public Point getPointerFromId(String clientId) {
		Point test;
		ClientPoint value;
		 
		test = ((ClientTelepointerHistory)telepointers.get(clientId)).getMostRecent();
		if(test == null) {
			System.err.println("No pointer for client");
			return null;
		}
		value = new ClientPoint(clientId, test);
		return value.p;
	}
	
	/**
	 * @param ms the delay in ms between sending telepointer events to the group.  Set this
	 * to an appropriate value for your network.  A QoS layer will eventually handle this, for now
	 * use this. 
	 */
	public void setBroadcastDelay(long ms) {
		gtw.setDelay(ms);
	}
	
	public long getBroadcastDelay() {
		return gtw.getDelay();
	}

	
	public void  relayTelepointerEvent(GTTelepointerEvent e, long timeGap) {
		//update local list
		//telepointers.remove(e.getSenderID());

		Iterator i = telepointerListeners.iterator();
		//Messenger.getInstance().message(String.valueOf(telepointers.size()));
		//fire listeners
		synchronized (telepointerListeners) {
			//System.out.println("\tin relay, telepointers size: " + telepointers.size());
		}
		synchronized (telepointerListeners) {
			//System.out.println("recv'd pointer");
				while(i.hasNext()){
				//about to Fire
				((GTTelepointerListener)i.next()).telepointerMoved(e,timeGap);
			}
		}
	}
	
	public GTDefaultTelepointerHandler getDefaultTelepointerHandler() {
		if (gtdth == null) {
			gtdth = new GTDefaultTelepointerHandler();
			System.out.println("in getDefaultTelepointer, gtdth is: " + gtdth.toString());
		}
		return gtdth;
	}

	
	/**
	 * @author Chris Fedak
	 *
	 * A simple dataclass for linking telepointer points to the client that sent them
	 */
	public class ClientPoint {
		/**
		 *	The id of the client whose telepoint this is
		 */
		public String id;
		/**
		 *	The current position of the telepointer
		 */
		public Point p;
		protected ClientPoint(String id, Point p) {
			this.id = id;
			this.p = p;
		}
	}
	
	
	/**
	 * @see ca.usask.hci.gt.GTSessionListener#personJoined(ca.usask.hci.gt.GTPersonEvent)
	 */
	public void personJoined(GTPersonEvent pje) {
		
		
	}

	/** 
	 * @see ca.usask.hci.gt.GTSessionListener#personLeft(ca.usask.hci.gt.GTPersonEvent)
	 */
	public void personLeft(GTPersonEvent pje) {
		
		telepointers.remove(pje.getPID());
	}

	/* (non-Javadoc)
	 * @see ca.usask.hci.gt.GTSessionListener#personChanged(ca.usask.hci.gt.GTPersonEvent)
	 */
	public void personChanged(GTPersonEvent pje) {
		
		
	}
	
	/**
	 * 
	 */
	public int getNextTelepointerSequence() {
		// TODO Auto-generated method stub
		int val = 0;
		ClientTelepointerHistory cth = (ClientTelepointerHistory)telepointers.get(GTController.getInstance().getMyID());
		if(cth == null) return 0;
		val = cth.lastSequence+1;
		if(val >= cth.capacity) val = 0;
		return val;
	}
	
	//Distributes Telepointers at a locally desirable period 
	protected class TelepointerEventDistributor implements Runnable {
		int testI =0;
		public TelepointerEventDistributor() {
		
		}

		/* (non-Javadoc)
		 * @see java.lang.Runnable#run()
		 */
		public synchronized void run() {
			// TODO Auto-generated method stub
			Iterator i;
			final GTTelepointerEvent gte = new GTTelepointerEvent();
			ClientTelepointerHistory cth = null;
			PredictedPoint pp = null;
			long lastTime=0;
			long[] times = new long[100];
			int count=0;
			int next= 0;
			long last =99;
			
			
			while(run) {
				//if(this.testI ==75) {
					//Messenger.getInstance().message(String.valueOf(telepointers.size()) + "members in telepointers Before");
				//}
				synchronized(telepointers) {
					i = telepointers.values().iterator(); 
					while(i.hasNext()) {
						cth = (ClientTelepointerHistory)i.next();	
						if(cth.id == null) System.err.println("cth.id null!");		
						if(!cth.id.equals(GTController.getInstance().getMyID())) {
							pp = cth.getPredictedPoint(System.currentTimeMillis());							
							gte.setPoint(pp);
							gte.setSender(cth.id);
							gte.setSenderID(cth.id);
							relayTelepointerEvent(gte,pp.timeGap);

							//determinies approximate refresh rate.
							if(lastTime == 0) {
								lastTime = System.currentTimeMillis(); 
							} else {
								if(count <(times.length)) {
									times[count] = System.currentTimeMillis()-lastTime;
									lastTime = System.currentTimeMillis();
									meanRelayRate = (meanRelayRate*(count) + times[count])/(count+1);
									count++;
								} else {
									last = times[next];
									times[next] = System.currentTimeMillis()-lastTime;
									lastTime = System.currentTimeMillis();
									meanRelayRate = meanRelayRate-(last/count)+(times[next]/count);
									next++;
									if(next>=times.length) next = 0;		
								}
							}
						}
					}
				}

				try {
					Thread.sleep(distributionPeriod);
				} catch (InterruptedException e) {
					 
				}
			}
		}
	
	}

	/**
	 * 
	 */
	public void kill() {
		// TODO Auto-generated method stub
		run = false;
		gtw.setRun(false);
	}
	
	/**
	 * @return Returns the meanRelayRate.
	 */
	public double getMeanRelayRate() {
		return meanRelayRate;
	}
/**
 * @return Returns the distributionPeriod.
 */
public long getDistributionPeriod() {
	return distributionPeriod;
}
/**
 * @param distributionPeriod The distributionPeriod to set.
 */
public void setDistributionPeriod(long distributionPeriod) {
	this.distributionPeriod = distributionPeriod;
}
}
