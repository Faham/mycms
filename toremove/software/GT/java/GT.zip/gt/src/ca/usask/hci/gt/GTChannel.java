/*
 * Created on Oct 8, 2003
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package ca.usask.hci.gt;

import java.io.Serializable;

import ca.usask.hci.network.qos.*;

/**
 * A GTChannel represents a channel of related data events, with the same 
 * set of QoS Requirements.  The system defines
 * 4 of these, only one of which is useful to a user of the library, "GT_DEFAULT"
 * GT_DEFAULT is the default channel to send events down if your system is sufficiently 
 * simple enough to keep all data unsorted.
 * 
 * The intent of channels as represented by GTChannel is to allow no-homogenous clients
 * to interact using the channels they do mutually understand.  Security and access control
 * may also be handled using the Channel abstraction.
 * 
 * @author Chris Fedak
 *
 * 
 */
public class GTChannel implements Serializable {
	
	
	/**
	 *	The string uniquely identifying this channel, usually a name
	 */
	private String identifier;

	/**
	 *	The Quality of service requirements for this channel.
	 */
	private GTQoSProperties qosProps;

	/**
	 *	The Quality of service requirements for this channel.
	 */
	private GTQoSProperties2 qosProps2;	
	
	/**
	 * Constructs an unnamed (and thus unusable) channel with QoS
	 * proprties for a Trasnactional data channel.
	 */
	public GTChannel() {
		super();
		qosProps = new GTQoSProperties();
		//default to setting guaranteed to require TCP.
		qosProps.setLatency(0.0);
		qosProps.setReliability(1.0);
		
		// TODO Auto-generated constructor stub
	}
	
	/**
	 * constructs a new GT channel with an identifier
	 * 
	 * @param identifier The unique id of the channel
	 */
	public GTChannel(String identifier) {
		this.identifier = identifier;
	}

	/**
	 * @return Identifier of the Channel.  In time these will be unique ID's for now they
	 * 	are simply strings
	 */
	public String getIdentifier() {
		return identifier;
	}

	/**
	 * @param identifier see getIdentifier
	 */
	public void setIdentifier(String identifier) {
		this.identifier = identifier;
	}

	/** 
	 * A channel is equal to another channel if their identifiers match.
	 * 
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	public boolean equals(Object o) {
		//if(o.getClass().equals(this.getClass()) == false) return false;
		GTChannel gc = (GTChannel)o;
		if(gc.getIdentifier().equals(identifier)) return true;
		return false;	
	}
	/**
	 * @return a class representing the QoS Requirements of this channel
	 */
	public GTQoSProperties getQosProps() {
		return qosProps;
	}

	/**
	 * @return a class representing the QoS Requirements of this channel
	 */
	public GTQoSProperties2 getQosProps2() {
		return qosProps2;
	}
	
	/**
	 * @param qosProps a representation of the QoS requirements of this channel
	 */
	public void setQosProps(GTQoSProperties qosProps) {
		this.qosProps = qosProps;
	}

	/**
	 * @param qosProps2 a representation of the QoS requirements of this channel
	 */
	public void setQosProps(GTQoSProperties2 qosProps2) {
		this.qosProps2 = qosProps2;
	}
	


}
