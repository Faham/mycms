/*
 * Created on Feb 25, 2004
 */
package ca.usask.hci.network.qos;

/**
 * @author jdd118
 */
public class GTHPTQOS extends GTQoSProperties2 {

	/**
	 * In milliseconds - the statistical min and max
	 */
	public static final int MIN_LATENCY = 50;
	public static final int MAX_LATENCY = 500;

	/**
	 * In % messages received.
	 */
	public static final int MIN_RELIABILITY = 94;
	public static final int MAX_RELIABILITY = 96;

	/**
	 * In milliseconds.
	 */
	public static final int MIN_JITTER = 50;
	public static final int MAX_JITTER = 500;
	
	/**
	 * In messages/second.
	 */
	public static final int MIN_RATE= 10;
	public static final int MAX_RATE= 30;
	
}
