/*
 * Created on Feb 4, 2004
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package ca.usask.hci.gt.telepointers;

import java.awt.Point;
import java.util.List;

import Jama.Matrix;

import ca.usask.hci.gt.GTController;
import ca.usask.hci.kalman.KalmanFilter;
import ca.usask.hci.utils.GTLogger;

/**
 * Predicts telepointer position using velocity, acceleration and time.
 * 
 * @author Chris Fedak
 *
 */
public class GTAccelerationPredictor implements GTTelepointerPredictor {
	GTLogger log;
	boolean print = false;
	int splineCounter = 0;
	Point lastPoint;
	Point referencePoint;
	KalmanFilter kf;
	double[][] A = { {1,0},{0,1}};  
	double[][] Q1 = { {86.0, 0.00}, {0.00, 126} }; // Process noise
	double [][] R = { {0.001, 0}, {0, 0.001 }}; // measurement noise
	double [][] C = { {1,0},{0,1}};
	/**
	 * 
	 */
	public GTAccelerationPredictor(String name) {
		super();
		String me;
		me = GTController.getInstance().getMyID();
		me = me.replaceAll(":","");
		me = me.replaceAll("/","");
			
		log = new GTLogger("accel-"+name+"-on"+me+".txt");
		lastPoint = new Point();
		referencePoint = new Point();
		kf= new KalmanFilter(2,2,2);
		kf.setProcessNoiseCovarianceMatrix(new Matrix(Q1));
		kf.setMeasurementNoiseCovarianceMatrix(new Matrix(R));
		kf.setTransitionMatrix(new Matrix(A));
		kf.setMeasurementMatrix(new Matrix(C));
		kf.setControlMatrix(new Matrix(C));
	}

	/* (non-Javadoc)
	 * @see ca.usask.hci.gt.telepointers.GTTelepointerPredictor#predict(ca.usask.hci.gt.telepointers.ClientTelepointerHistory, long)
	 */
	public synchronized PredictedPoint predict(ClientTelepointerHistory cth, long time) {
		// TODO Auto-generated method stub
		//Get point acceleration 1
		OrderedPoint op1 = null, op2 = null;
		PredictedPoint val = null;
		PredictedPoint valKal = null;
		Point toPoint = null;
		Point[] sixFuturePoints = null;
		Matrix control, predicted;
		int period;
		
		double[] vx = new double[3],
						 vy = new double[3];
		long 		 t1=0,
						 t2=0;
		double ax=0, ay=0;
		long dtime;

		List history = cth.history();
		if(history.size() == 0) return new PredictedPoint(0,0);
		if(history.size() < 10) {
			 op1 = (OrderedPoint)history.get(0);
			 val = new PredictedPoint(op1.getX(), op1.getY());
			 valKal = new PredictedPoint(op1.getX(), op1.getY());
			 t1 = op1.getTimestamp();
		} else {
			//		period detector
			op2 = (OrderedPoint)history.get(0);
			op1 = (OrderedPoint)history.get(history.size()-1);
			
			period = (int) ((op2.getTimestamp()-op1.getTimestamp())/history.size());
			
			op2 = (OrderedPoint)history.get(0);
			op1 = (OrderedPoint)history.get(1);
			t2 = op2.getTimestamp();
			vx[0] = ((double)op2.getX()-(double)op1.getX())/(double)(period);
			vy[0] = ((double)op2.getY()-(double)op1.getY())/(double)(period);
	
			op2 = (OrderedPoint)history.get(8);
			op1 = (OrderedPoint)history.get(9);
			t1 = op1.getTimestamp();
			
			vx[1] = ((double)op2.getX()-(double)op1.getX())/(double)(period);
			vy[1] = ((double)op2.getY()-(double)op1.getY())/(double)(period);
			
			op2 = (OrderedPoint)history.get(0);
			//v using 10 points in history;
			vx[2] = ((double)op2.getX()-(double)op1.getX())/(double)(period*9);
			vy[2] = ((double)op2.getY()-(double)op1.getY())/(double)(period*9);
			
			//avg accel over 10 point period
			ax = (vx[0]-vx[1])/(double)(period*9);
			ay = (vy[0]-vy[1])/(double)(period*9);
	
			//set maximum velocity to 250px/second
			//if(vx[0] > 0.250) vx = 0.250;
			//if(vy[0] > 0.250) vy = 0.250;
	
			dtime = time - op2.getTimestamp();
			if(dtime <=5 && lastPoint !=null) {
				splineCounter = 2;
				referencePoint = new Point(((OrderedPoint)history.get(1)).getX(),
						((OrderedPoint)history.get(1)).getY());
			}
			
			//test
			//dtime = 0;
	
			//calculate displacement using dS = vt + 1/2at^2
			//val = new Point((int) ((double)op2.getX()+vx[2]*dtime+0.5*ax*dtime*dtime), (int) ((double)op2.getY()+(vy[2]*dtime)+(0.5*ay*dtime*dtime)));
			val = new PredictedPoint(cth.getMostRecent(),dtime);
			valKal = new PredictedPoint(cth.getMostRecent(),dtime);
			
			
			//val = cth.getMostRecent();
			if(splineCounter >0 ){
				double pos = 1.0-(0.25*splineCounter);
				control = new Matrix(2,1);
				control.set(0,0,(double)(vx[2]*dtime)+(double)(0.5*ax*dtime*dtime));
				control.set(1,0,(double)(vy[2]*dtime)+(double)(0.5*ay*dtime*dtime));
				
				predicted = kf.predict(control);
				toPoint = new Point((int)predicted.get(0,0), (int)predicted.get(1,0));
				valKal = new PredictedPoint(new Point(toPoint.x,toPoint.y), dtime);
				
				//toPoint = cth.getMostRecent();
				//toPoint.x = (int) (toPoint.x+vx[2]*dtime+0.5*ax*dtime*dtime);
				//toPoint.y = (int) (toPoint.y+vy[2]*dtime+0.5*ay*dtime*dtime);
										
				val = new PredictedPoint(referencePoint, dtime);
				val.x += (double)(toPoint.x-val.x) * pos;
				val.y += (double)(toPoint.y-val.y) * pos;
				splineCounter--;
			} else {
				control = new Matrix(2,1);
				control.set(0,0,(double)(vx[2]*dtime)+(double)(0.5*ax*dtime*dtime));
				control.set(1,0,(double)(vy[2]*dtime)+(double)(0.5*ay*dtime*dtime));
				
				predicted = kf.predict(control);
				valKal = new PredictedPoint(new Point((int)predicted.get(0,0), (int)predicted.get(1,0)));
				val.x = (int) (val.x+vx[2]*dtime+0.5*ax*dtime*dtime);
				val.y = (int) (val.y+vy[2]*dtime+0.5*ay*dtime*dtime);
			}
			
			sixFuturePoints = new Point[6];
			
			//System.out.println("pastError for " +String.valueOf(dtime) + "ms = " + String.valueOf(cth.getError(dtime)));
			
			//also calculate five future points each 50 ms(rec) from last received point
			for(int k = 1; k<=6;k++) {
				dtime = 50*k;
				sixFuturePoints[k-1] = new Point((int) ((double)op2.getX()+vx[2]*dtime+0.5*ax*dtime*dtime), (int) ((double)op2.getY()+vy[2]*dtime+0.5*ay*dtime*dtime));
			}	
		}
		if(print==true) {
			//System.out.println(System.currentTimeMillis());
			//printResult(val, time, t1, sixFuturePoints, ax, ay, vx[2], vy[2]);
			printKalmanComparison(time, valKal, val);
		}
		
		return valKal;
	}

	/**
	 * @param val
	 * @param time
	 * @param t1
	 * @param fiveFuturePoints
	 * @param ax
	 * @param ay
	 */
	private void printResult(Point val, long time, long t1, Point[] sixFuturePoints, double ax, double ay, double d, double e) {
		// TODO Auto-generated method stub
		String line ="";	
		if(sixFuturePoints == null) {
				line = "-\t-\t"+ String.valueOf(d) + "\t" + String.valueOf(e) +"\t";
				line += String.valueOf(t1)+"\t"+String.valueOf(time)+"\t"+String.valueOf(val.getX())+"\t"+String.valueOf(val.getY())+"\t";
				for(int j = 0;j<5;j++) {
					//pad future uninformative predictions
					line += String.valueOf(val.getX())+"\t"+String.valueOf(val.getY())+"\t";					
				}
		} else {
			line = String.valueOf(ax) + "\t" + String.valueOf(ay)+"\t"; //accel
			line += String.valueOf(d) + "\t" + String.valueOf(e) +"\t"; //velocity
			line += String.valueOf(t1)+ "\t" + String.valueOf(time)+"\t"; //time of last tp 
			line += String.valueOf(val.getX())+"\t"+String.valueOf(val.getY())+"\t";
			for(int j = 0;j<6;j++) {
				line+= String.valueOf(sixFuturePoints[j].getX())+"\t"+String.valueOf(sixFuturePoints[j].getY())+"\t";
			}
		}
		log.log(line+"\n");
		//out.println(line);
		//out.flush();
	}
	
	private void printKalmanComparison(long time, PredictedPoint valKal, PredictedPoint val) {
		if(valKal == null) return;
		String line="";
		line = String.valueOf(time)+"\t"; //time of prediction
		line += String.valueOf(valKal.x) + "\t" + String.valueOf(valKal.y)+"\t"; //valKal
		line += String.valueOf(val.x) + "\t" + String.valueOf(val.y) +"\t"; //velocity
	
		log.log(line+"\n");
	}

	/* (non-Javadoc)
	 * @see ca.usask.hci.gt.telepointers.GTTelepointerPredictor#latencyAdjustment()
	 */
	public int latencyAdjustment() {
		// TODO Auto-generated method stub
		return 0;
	}
	
	public void correct(Point p) {
		Matrix corr;
		corr = new Matrix(2,1);
		corr.set(0,0, p.x);		//1st point
		corr.set(1,0, p.y);
		kf.correct(corr);
	}
}
