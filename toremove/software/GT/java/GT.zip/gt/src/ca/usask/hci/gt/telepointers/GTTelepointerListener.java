/*
 * Created on Oct 10, 2003
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package ca.usask.hci.gt.telepointers;


/**
 * @author Chris Fedak
 *
 * Listener for objects wishing to receive telepointer events from GTTelepointerController
 */
public interface GTTelepointerListener {

	/**
	 * Notification that a remote telepointer has moved
	 * 
	 * @param gte
	 * @see GTTelepointerEvent
	 */
	public void telepointerMoved(GTTelepointerEvent gte, long timeGap);
}
