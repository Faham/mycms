/*
 * Created on Oct 31, 2003
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package ca.usask.hci.gt.ypserver;

import java.io.IOException;
import java.io.Serializable;
import java.util.HashMap;
import java.util.Iterator;

import ca.usask.hci.gt.GTChannel;

/**
 * @author Chris Fedak
 *
 */
public class GTServerProperties implements Serializable {
	String hostAddress;
	int hostPort;
	String name;
	String description;
	int clients;
	int maxclients;
	HashMap channels;
	private GTYellowPagesClient ypClient;
	private boolean isAlive;

	/**
	 * 
	 */
	public GTServerProperties() {
		super();
		channels = new HashMap();
		isAlive = false;
	}
	
	public GTServerProperties(String hostAddress,
		int hostPort,
		String name,
		String description,
		int clients,
		int maxclients) 
	{
			super();
			this.hostPort = hostPort;
			this.name = name;
			this.description = description;
			this.clients = clients;
			this.maxclients = maxclients;
	}

	/**
	 * @return
	 */
	public HashMap getChannels() {
		return channels;
	}

	/**
	 * @param channels
	 */
	public synchronized void setChannels(HashMap channels) {
		if(channels!=null) {
			this.channels = channels;
		}
		if(ypClient != null) {
			ypClient.sendAllChannels();
		}
	}
	
	public void addChannel(GTChannel channel) {
		channels.put(channel.getIdentifier(), channel);
		if(ypClient != null) {
			ypClient.sendNewChannel(channel);
		}
	}
	
	public void removeChannel(String id) {	
		if(ypClient != null) {
			ypClient.sendRemoveChannel((GTChannel)channels.get(id));
		}
		channels.remove(id);
	}

	/**
	 * @return
	 */
	public int getClients() {
		return clients;
	}

	/**
	 * @param clients
	 */
	public void setClients(int clients) {
		this.clients = clients;
		if(ypClient != null) {
			try {
				ypClient.sendServerProperties(this);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	/**
	 * @return
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @param description
	 */
	public void setDescription(String description) {
		this.description = description;
		if(ypClient != null) {
			try {
				ypClient.sendServerProperties(this);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	/**
	 * @return
	 */
	public String getHostAddress() {
		return hostAddress;
	}

	/**
	 * @param hostAddress
	 */
	public void setHostAddress(String hostAddress) {
		this.hostAddress = hostAddress;
		if(ypClient != null) {
			try {
				ypClient.sendServerProperties(this);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	/**
	 * @return
	 */
	public int getHostPort() {
		return hostPort;
	}

	/**
	 * @param hostPort
	 */
	public void setHostPort(int hostPort) {
		this.hostPort = hostPort;
		if(ypClient != null) {
			try {
				ypClient.sendServerProperties(this);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	/**
	 * @return
	 */
	public int getMaxclients() {
		return maxclients;
	}

	/**
	 * @param maxclients
	 */
	public void setMaxClients(int maxclients) {
		this.maxclients = maxclients;
		if(ypClient != null) {
			try {
				ypClient.sendServerProperties(this);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	/**
	 * @return
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name
	 */
	public void setName(String name) {
		this.name = name;
		if(ypClient != null) {
			try {
				ypClient.sendServerProperties(this);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	public String toString() {
		String rep;
		rep = "GTServerProperties: ";
		rep+=";";
		rep += name;
		rep+=";";
		rep += description;
		rep+=";";
		rep += hostAddress;
		rep+=";";
		rep += String.valueOf(hostPort);
		rep+=";";
		Iterator i = channels.values().iterator();
		rep+=";";
		while(i.hasNext()) {
			rep += i.next().toString();
			rep+=";";
		}
		return rep;
	}

	/**
	 * @param client
	 */
	protected void setYPClient(GTYellowPagesClient client) {
		// TODO Auto-generated method stub
		this.ypClient = client;
	}
	/**
	 * @return
	 */
	public boolean isAlive() {
		return isAlive;
	}

	/**
	 * @param isAlive
	 */
	public void setAlive(boolean isAlive) {
		this.isAlive = isAlive;
	}

}
