javac -d classes\ src\ca\usask\hci\*.java
cd classes
jar cvf GT.jar ca/usask/hci/gt/*.class
cd ..
